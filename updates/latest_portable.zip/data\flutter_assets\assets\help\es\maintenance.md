# Mantenimiento

TradeVision incluye varias herramientas de mantenimiento destinadas a:

- optimizar ciertos datos,
- corregir algunas incoherencias,
- reconstruir información,
- reparar problemas relacionados con la cartera o los títulos.

Estas herramientas se encuentran principalmente en los ajustes de la aplicación.

---

# Antes de cualquier mantenimiento

Antes de usar una herramienta importante, se recomienda encarecidamente:

- hacer una copia de seguridad de la cartera,
- cerrar aplicaciones innecesarias,
- comprobar que las importaciones recientes han terminado,
- no interrumpir la aplicación durante una operación importante.

> Consejo: haga siempre una copia de seguridad antes de un mantenimiento importante.

---

# Mantenimiento SQLite

TradeVision usa una base de datos local para guardar operaciones, títulos, historiales, datos de mercado y ajustes de cartera.

Con el tiempo, algunas operaciones pueden hacer que la base sea más pesada o menos optimizada.

El mantenimiento SQLite puede ayudar a optimizar consultas, reducir archivos temporales, limpiar datos internos y mejorar algunas prestaciones.

---

# Cuándo usar el mantenimiento SQLite

Puede ser útil:

- después de una gran importación CSV,
- después de muchas eliminaciones,
- tras pruebas importantes,
- si algunas pantallas se vuelven lentas,
- después de ciertos errores o interrupciones.

En la mayoría de los casos no hace falta ejecutarlo con frecuencia.

---

# Reconstrucción de títulos

TradeVision puede reconstruir cierta información vinculada a los títulos.

Esta operación puede corregir títulos incoherentes, nombres faltantes, metadatos incorrectos o problemas de asignación.

La reconstrucción puede usar operaciones existentes, historiales, datos locales y algunos proveedores externos.

---

# Cuándo reconstruir títulos

Esta operación puede ser útil después de varias importaciones CSV, pruebas de símbolos, modificaciones importantes, o si algunos títulos parecen incorrectos o dejan de mostrarse correctamente.

---

# Verificación OpenFIGI

TradeVision puede usar OpenFIGI para completar o verificar información de títulos.

Esta verificación puede ayudar a encontrar ISIN, tickers, plazas de cotización y metadatos.

Es especialmente útil cuando un ticker es ambiguo, un título está mal reconocido, algunos datos parecen incorrectos o las importaciones contienen símbolos complejos.

---

# Reparación de datos

Según la versión, algunas herramientas pueden intentar reparar automáticamente ciertas incoherencias.

Ejemplos:

- símbolos incorrectos,
- títulos incompletos,
- historiales incoherentes,
- datos faltantes,
- asignacións inválidos.

Algunas reparaciones pueden tardar según el tamaño de la cartera.

---

# Recálculo de datos

Después de operaciones importantes, TradeVision puede recalcular rentabilidad, posiciones, gráficos, historiales y estadísticas.

Estos recálculos suelen ser automáticos.

Según el tamaño de la cartera, pueden tardar unos instantes.

---

# Problemas que pueden requerir mantenimiento

Algunas situaciones pueden justificar un mantenimiento:

- rentabilidad incoherente,
- efectivo incorrecto,
- gráficos incompletos,
- títulos duplicados,
- datos faltantes,
- ralentizaciones importantes,
- problemas tras una importación CSV.

En muchos casos, una simple revisión de operaciones o símbolos es suficiente.

---

# Lo que el mantenimiento no hace

Las herramientas de mantenimiento no pueden corregir automáticamente todos los errores de importación, garantizar la calidad de los proveedores, recrear datos totalmente ausentes, sustituir una copia de seguridad ni corregir un historial erróneo suministrado por una fuente externa.

Algunos errores requieren comprobación manual.

---

# Copias de seguridad antes del mantenimiento

Antes de cualquier operación importante:

- cree una copia de seguridad,
- compruebe el archivo usado,
- conserve una copia reciente de la cartera.

Una copia permite volver atrás si aparece un resultado inesperado.

---

# Mantenimiento y rendimiento

El mantenimiento puede mejorar a veces el tiempo de carga, algunos cálculos, gráficos, búsquedas y operaciones de cartera.

Pero la velocidad también depende del tamaño de la base, los historiales almacenados, los proveedores usados y el rendimiento del equipo.

---

# Después del mantenimiento

Después de ciertas operaciones:

- deje unos instantes a TradeVision para recalcular datos,
- compruebe las posiciones importantes,
- controle el efectivo,
- revise los gráficos principales,
- revise las últimas importaciones.

Es normal que algunas pantallas tarden un poco en estabilizarse tras un recálculo grande.

---

# Consejos para limitar problemas

Para mantener una base limpia:

- evite importaciones duplicadas,
- revise los símbolos antes de importar,
- haga copias de seguridad regulares,
- importe grandes historiales progresivamente,
- evite cambios masivos innecesarios,
- mantenga datos coherentes.

Una base limpia reduce mucho el riesgo de errores futuros.

---

# Nota importante

Las herramientas de mantenimiento sirven sobre todo para optimizar, reconstruir, verificar y reparar ciertos datos.

Deben usarse con prudencia, especialmente después de grandes importaciones o cambios importantes.

Antes de cualquier operación sensible:

- haga una copia de seguridad,
- revise sus datos,
- controle los resultados después del mantenimiento.
