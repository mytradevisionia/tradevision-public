# FAQ

Cette section regroupe les questions et problèmes les plus fréquents rencontrés dans TradeVision AI Pro.

## Questions

- [Pourquoi certains titres n’ont-ils pas de cours ?](#cours-manquants)
- [Pourquoi mes valeurs diffèrent-elles de mon courtier ?](#ecart-courtier)
- [Pourquoi mon cash est-il incohérent ?](#cash-incoherent)
- [Pourquoi mes performances semblent incorrectes ?](#performances-incorrectes)
- [Pourquoi un ETF ou une action est-il “inconnu” ?](#titre-inconnu)
- [Pourquoi certains tickers sont-ils ambigus ?](#tickers-ambigus)
- [Pourquoi les graphiques sont-ils incomplets ?](#graphiques-incomplets)
- [Pourquoi certaines fonctions IA ne fonctionnent-elles pas ?](#ia-limitee)
- [Une clé API est-elle obligatoire ?](#cle-api-obligatoire)
- [Les APIs sont-elles gratuites ?](#apis-gratuites)
- [Pourquoi les cours changent-ils après la fermeture du marché ?](#cours-apres-fermeture)
- [TradeVision fonctionne-t-il en temps réel ?](#temps-reel)
- [Pourquoi les imports CSV créent-ils des doublons ?](#doublons-csv)
- [Pourquoi certains ETF européens fonctionnent mieux avec ABCBourse ?](#abcbourse)
- [Pourquoi la maintenance peut-elle être utile ?](#maintenance)
- [Dois-je faire des sauvegardes régulières ?](#sauvegardes)
- [Mes données sont-elles envoyées à un serveur externe ?](#donnees-serveur)
- [L’IA passe-t-elle des ordres automatiquement ?](#ia-ordres)
- [Puis-je utiliser plusieurs portefeuilles ?](#plusieurs-portefeuilles)
- [Que faire avant une grosse modification ?](#grosse-modification)

---

# cours-manquants

## Pourquoi certains titres n’ont-ils pas de cours ?

Plusieurs causes sont possibles :

- le ticker est incorrect,
- la place de cotation n’est pas précisée,
- le provider ne couvre pas ce marché,
- le titre est ambigu,
- le marché est fermé,
- la donnée n’est pas encore disponible.

Vérifiez notamment :

- le ticker,
- le suffixe éventuel,
- le code MIC,
- les providers configurés.

Consultez aussi :

- [Cours et marché](pricing.md)
- [Providers et APIs](providers.md)

[Retour aux questions](#questions)

---

# ecart-courtier

## Pourquoi mes valeurs diffèrent-elles de mon courtier ?

Il est normal que certaines valeurs soient légèrement différentes.

Les écarts peuvent venir :

- du provider utilisé,
- du délai des données,
- des devises,
- des arrondis,
- des clôtures utilisées,
- des horaires de mise à jour.

Deux plateformes différentes peuvent afficher des valeurs légèrement différentes au même moment.

[Retour aux questions](#questions)

---

# cash-incoherent

## Pourquoi mon cash est-il incohérent ?

Dans la majorité des cas, cela provient :

- d’un apport oublié,
- d’un retrait manquant,
- de frais non renseignés,
- d’un doublon d’import,
- d’une opération incorrecte.

Vérifiez :

- les apports,
- les retraits,
- les frais,
- les virements internes,
- les dernières opérations importées.

[Retour aux questions](#questions)

---

# performances-incorrectes

## Pourquoi mes performances semblent incorrectes ?

Les performances dépendent directement des opérations enregistrées.

Des résultats incohérents peuvent venir :

- d’un import incomplet,
- d’un doublon,
- d’un mauvais cash,
- de frais manquants,
- de titres mal identifiés,
- de dates incorrectes.

Vérifiez d’abord vos opérations avant de lancer une maintenance.

[Retour aux questions](#questions)

---

# titre-inconnu

## Pourquoi un ETF ou une action est-il “inconnu” ?

Cela peut arriver si :

- le ticker n’est pas reconnu,
- le symbole est ambigu,
- la place est incorrecte,
- l’ISIN est absent,
- le provider ne couvre pas ce titre.

Essayez de préciser :

- le suffixe du ticker,
- le code MIC,
- l’ISIN,
- la place de cotation.

[Retour aux questions](#questions)

---

# tickers-ambigus

## Pourquoi certains tickers sont-ils ambigus ?

Un même ticker peut exister sur plusieurs marchés.

Exemple :

- même symbole à Paris et Amsterdam,
- même ETF coté sur plusieurs places,
- plusieurs devises possibles.

Dans ce cas, utilisez :

- un suffixe,
- un code MIC,
- un ISIN.

[Retour aux questions](#questions)

---

# graphiques-incomplets

## Pourquoi les graphiques sont-ils incomplets ?

Cela peut arriver :

- après un gros import,
- lors d’une première synchronisation,
- si certains historiques manquent,
- si certaines données ne sont pas encore téléchargées.

Selon votre configuration, certains historiques peuvent nécessiter quelques instants avant stabilisation.

[Retour aux questions](#questions)

---

# ia-limitee

## Pourquoi certaines fonctions IA ne fonctionnent-elles pas ?

Certaines fonctions IA avancées nécessitent :

- des historiques suffisants,
- des données de marché compatibles,
- parfois une API compatible configurée.

Sans données suffisantes, certaines analyses peuvent être limitées.

Consultez :

- [IA TradeVision](ai.md)
- [Providers et APIs](providers.md)

[Retour aux questions](#questions)

---

# cle-api-obligatoire

## Une clé API est-elle obligatoire ?

Non, TradeVision peut fonctionner sans clé API.

Cependant, certaines fonctions avancées de l’édition Pro peuvent nécessiter :

- une API compatible,
- des historiques plus complets,
- des providers avancés.

Provider recommandé :

- EODHD

Providers compatibles selon votre configuration :

- EODHD
- Leeway
- Finnhub
- FMP

[Retour aux questions](#questions)

---

# apis-gratuites

## Les APIs sont-elles gratuites ?

Cela dépend du provider utilisé.

Selon les services :

- certaines APIs sont gratuites avec limites,
- certaines sont partiellement gratuites,
- certaines sont payantes.

Les offres gratuites permettent souvent :

- de tester l’application,
- de récupérer un volume limité de données,
- d’utiliser certains marchés principaux.

[Retour aux questions](#questions)

---

# cours-apres-fermeture

## Pourquoi les cours changent-ils après la fermeture du marché ?

Après la fermeture :

- certaines données peuvent être corrigées,
- certaines clôtures peuvent être consolidées,
- certains providers peuvent mettre à jour leurs historiques.

Il est donc normal que certaines valeurs évoluent légèrement avant stabilisation complète.

[Retour aux questions](#questions)

---

# temps-reel

## TradeVision fonctionne-t-il en temps réel ?

TradeVision n’est pas une plateforme de trading haute fréquence.

Selon les providers utilisés :

- certaines données peuvent être quasi temps réel,
- certaines peuvent être différées,
- certaines clôtures peuvent être validées après la fermeture.

Les données affichées dépendent toujours des providers utilisés.

[Retour aux questions](#questions)

---

# doublons-csv

## Pourquoi les imports CSV créent-ils des doublons ?

Les doublons apparaissent souvent lorsque :

- le même fichier est importé plusieurs fois,
- plusieurs exports se chevauchent,
- certaines opérations existent déjà.

Les doublons peuvent fausser :

- les performances,
- le cash,
- les quantités,
- les graphiques.

Faites toujours une sauvegarde avant un gros import.

[Retour aux questions](#questions)

---

# abcbourse

## Pourquoi certains ETF européens fonctionnent mieux avec ABCBourse ?

ABCBourse peut être utile pour :

- certains ETF européens,
- certains historiques quotidiens,
- certains marchés Euronext.

Selon les providers utilisés, certaines données peuvent être plus complètes via ABCBourse.

[Retour aux questions](#questions)

---

# maintenance

## Pourquoi la maintenance peut-elle être utile ?

La maintenance peut aider à :

- optimiser certaines données,
- reconstruire certains titres,
- corriger certaines incohérences,
- améliorer certaines performances.

Elle peut être utile après :

- un gros import CSV,
- des modifications importantes,
- certains problèmes de données.

[Retour aux questions](#questions)

---

# sauvegardes

## Dois-je faire des sauvegardes régulières ?

Oui, fortement.

Il est recommandé de faire des sauvegardes :

- avant un import,
- avant une maintenance,
- avant une restauration,
- avant une mise à jour importante.

Une sauvegarde permet de revenir en arrière en cas de problème.

[Retour aux questions](#questions)

---

# donnees-serveur

## Mes données sont-elles envoyées à un serveur externe ?

TradeVision privilégie un fonctionnement local.

Dans la majorité des cas :

- les portefeuilles restent stockés sur votre machine,
- les opérations restent locales,
- les sauvegardes restent sous votre contrôle.

Cependant, certaines fonctions utilisant des providers externes peuvent nécessiter des échanges limités avec des services tiers.

[Retour aux questions](#questions)

---

# ia-ordres

## L’IA passe-t-elle des ordres automatiquement ?

Non.

TradeVision :

- ne passe pas d’ordres,
- ne se connecte pas automatiquement à votre courtier pour trader,
- ne garantit aucun gain.

Les outils IA servent uniquement d’aide à l’analyse.

[Retour aux questions](#questions)

---

# plusieurs-portefeuilles

## Puis-je utiliser plusieurs portefeuilles ?

Oui.

TradeVision peut ouvrir différents fichiers de portefeuille selon votre organisation.

Vous pouvez par exemple :

- séparer PEA et CTO,
- créer des portefeuilles de test,
- conserver des sauvegardes indépendantes.

[Retour aux questions](#questions)

---

# grosse-modification

## Que faire avant une grosse modification ?

Avant une opération importante :

- faites un backup,
- vérifiez les imports,
- contrôlez les symboles,
- vérifiez le cash,
- gardez une copie du portefeuille actuel.

Une bonne sauvegarde reste la meilleure protection contre les erreurs.

[Retour aux questions](#questions)

---
