# Providers y APIs

TradeVision utiliza varios providers y APIs externas para recuperar datos relacionados con los mercados financieros.

Estos providers pueden utilizarse para:

- recuperar cotizaciones spot,
- descargar cierres oficiales,
- actualizar historiales de precios,
- recuperar algunos datos OHLC,
- completar información de determinados valores,
- alimentar algunos gráficos,
- proporcionar algunos datos utilizados por las herramientas IA.

Según tu configuración, varios providers pueden utilizarse automáticamente.

---

# Comprender los providers

Un provider es una fuente externa utilizada para recuperar información financiera.

TradeVision puede utilizar varios tipos de datos:

- cotizaciones de mercado,
- historiales diarios,
- datos OHLC,
- metadatos de valores,
- información de plazas de cotización,
- datos necesarios para algunos análisis IA.

Según los mercados y los valores, algunas fuentes pueden ser más adecuadas que otras.

---

# Papel de los providers en TradeVision

Los providers desempeñan un papel importante en varias partes de la aplicación.

Pueden servir para:

- descargar cotizaciones de mercado,
- recuperar cierres oficiales,
- actualizar historiales,
- alimentar algunos gráficos,
- recuperar determinados datos OHLC,
- completar cierta información de valores,
- alimentar algunas funciones IA.

Sin un provider compatible, algunos datos pueden estar limitados o no estar disponibles.

---

# Providers gratuitos

TradeVision puede funcionar sin licencia Pro ni clave API.

En este modo, la aplicación puede utilizar algunas fuentes gratuitas según las funciones disponibles.

Ejemplos:

- Google Finance,
- Yahoo Finance,
- importaciones manuales,
- historiales locales ya presentes en la base.

Estas fuentes permiten a menudo:

- seguir los principales ETF,
- recuperar cotizaciones simples,
- usar la aplicación sin una configuración compleja.

---

# Límites de los providers gratuitos

Los providers gratuitos pueden tener ciertas limitaciones.

Ejemplos:

- datos diferidos,
- cobertura incompleta,
- mercados poco cubiertos,
- ETF exóticos ausentes,
- limitaciones temporales,
- indisponibilidades puntuales,
- cambios de formato de los datos.

Es normal que algunos valores funcionen mejor con unas fuentes que con otras.

---

# APIs externas

TradeVision puede utilizar APIs externas opcionales.

Estas APIs pueden mejorar:

- la estabilidad de las cotizaciones,
- la disponibilidad de los datos,
- la cobertura de mercados,
- la calidad de algunos historiales,
- algunas funciones avanzadas,
- algunos datos utilizados por la IA.

Por lo general, las APIs no son obligatorias para utilizar la aplicación.

---

# APIs recomendadas para la edición Pro

Algunas funciones avanzadas de TradeVision AI Pro necesitan providers compatibles.

Para una experiencia más completa y una mejor estabilidad de los datos, se recomienda encarecidamente utilizar una API dedicada.

Provider recomendado:

- EODHD

Providers compatibles según tu configuración:

- EODHD
- Leeway
- Finnhub
- FMP

Según los providers utilizados, algunos datos pueden incluir:

- cotizaciones spot,
- cierres oficiales,
- historiales diarios,
- datos OHLC,
- algunos metadatos de valores,
- datos necesarios para algunas herramientas IA.

Algunas funciones avanzadas de la edición Pro pueden estar limitadas sin una clave API compatible.

---

# Claves API

Algunas APIs requieren una clave de acceso.

Una clave API permite a un servicio externo:

- identificar tu uso,
- aplicar ciertos límites,
- autorizar determinadas solicitudes.

Las claves API pueden indicarse desde los ajustes de TradeVision.

> Importante: algunas APIs gratuitas imponen límites diarios o mensuales.

---

# Gratis o de pago

Según los servicios utilizados, las claves API pueden ser:

- gratuitas con límites,
- parcialmente gratuitas,
- o de pago.

Las versiones gratuitas suelen permitir:

- probar la aplicación,
- recuperar un volumen limitado de datos,
- utilizar algunos mercados principales.

Las ofertas de pago pueden mejorar:

- el número de solicitudes,
- la estabilidad,
- la cobertura de mercado,
- los historiales disponibles.

---

# Google Finance

Google Finance puede utilizarse para recuperar algunas cotizaciones simples.

Esta fuente suele ser práctica para:

- ETF habituales,
- algunas acciones internacionales,
- seguimientos sencillos.

Sin embargo, la cobertura depende del mercado y de los datos accesibles públicamente.

---

# Yahoo Finance

Yahoo Finance se utiliza a menudo para:

- cotizaciones spot,
- algunos historiales,
- muchos mercados internacionales.

Según los valores, Yahoo puede proporcionar a veces:

- mejores resultados,
- datos diferentes,
- una cobertura más amplia.

Sin embargo, algunos datos pueden variar según los períodos o los mercados.

---

# APIs Pro

Según tu configuración, TradeVision puede utilizar APIs más avanzadas.

Estas APIs pueden mejorar:

- la calidad de los datos,
- la estabilidad de los precios,
- algunos historiales,
- la cobertura de algunos mercados especializados.

Según los servicios utilizados, algunas APIs pueden ser:

- gratuitas con límites,
- parcialmente gratuitas,
- de pago,
- sujetas a una suscripción externa.

---

# EODHD

Algunas configuraciones de TradeVision pueden utilizar EODHD para recuperar:

- cotizaciones spot,
- cierres oficiales,
- historiales,
- algunos datos OHLC,
- algunos datos de mercado.

Según los mercados, EODHD puede ofrecer:

- buena cobertura,
- historiales más completos,
- datos útiles para algunos análisis.

Como cualquier fuente externa, los datos pueden variar según los instrumentos o los períodos.

---

# OpenFIGI

OpenFIGI se utiliza principalmente para ayudar a identificar algunos valores.

Este servicio puede ayudar a encontrar:

- tickers,
- ISIN,
- plazas de cotización,
- algunos metadatos.

OpenFIGI es especialmente útil:

- durante las importaciones CSV,
- para símbolos ambiguos,
- para algunos ETF o acciones menos conocidos.

---

# ABCBourse

TradeVision también puede utilizar importaciones procedentes de ABCBourse.

Estas importaciones sirven principalmente para:

- recuperar historiales diarios,
- completar algunos datos locales,
- mejorar algunos gráficos,
- reconstruir algunos historiales.

ABCBourse es especialmente útil para algunos mercados europeos y algunos ETF.

---

# Providers e IA

Algunas funciones IA utilizan indirectamente datos procedentes de los providers.

Ejemplos:

- historiales de precios,
- variaciones,
- tendencias,
- datos utilizados para algunos indicadores,
- algunos datos OHLC,
- algunos datos de mercado.

Si los datos están incompletos, algunas funciones IA pueden estar limitadas.

---

# Elegir los providers adecuados

No todos los usuarios tienen las mismas necesidades.

Ejemplos:

- cartera simple de ETF europeos,
- acciones estadounidenses,
- ETF internacionales,
- mercados especializados,
- historiales grandes,
- uso principalmente local.

Según tu cartera, algunas fuentes pueden ser más adecuadas que otras.

---

# Por qué pueden utilizarse varios providers

TradeVision puede utilizar varios providers para:

- mejorar la disponibilidad,
- limitar algunos errores,
- recuperar datos complementarios,
- mejorar algunos historiales,
- comparar algunos datos de mercado.

Por tanto, algunos datos pueden proceder de fuentes distintas según:

- el valor,
- el mercado,
- el tipo de dato,
- la disponibilidad del provider.

---

# Posibles problemas con los providers

Los providers externos pueden encontrar problemas en algunos momentos.

Ejemplos:

- datos temporales incorrectos,
- indisponibilidad,
- ralentizaciones,
- cambios de API,
- límites de solicitudes,
- cobertura parcial de algunos ETF.

En algunos casos, un provider puede funcionar para un valor pero no para otro.

---

# Consejos para limitar los problemas

Para mejorar la estabilidad de los datos:

- utiliza símbolos precisos,
- añade los sufijos de mercado si es necesario,
- comprueba las plazas de cotización,
- utiliza APIs adaptadas a tus mercados,
- evita importaciones incoherentes,
- conserva copias de seguridad periódicas.

Después de una gran importación o de un cambio de provider, algunos datos pueden necesitar unos instantes antes de estabilizarse.

---

# Importante saber

TradeVision depende de servicios externos para recuperar algunos datos.

La aplicación:

- no controla los providers externos,
- no garantiza la disponibilidad permanente de las APIs,
- puede estar limitada por algunos servicios gratuitos,
- puede mostrar datos diferentes según las fuentes utilizadas.

Los providers deben verse como fuentes de información y no como flujos de trading en tiempo real garantizados.
