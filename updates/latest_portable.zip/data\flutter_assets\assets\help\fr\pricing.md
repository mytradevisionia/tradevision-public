# Cours et marché

TradeVision utilise plusieurs sources de données pour récupérer les cours des ETF, actions et autres instruments financiers.

Cette section explique :

- comment les prix sont récupérés,
- pourquoi certains cours peuvent varier,
- ce que signifient les cours spot et les clôtures officielles,
- pourquoi des écarts peuvent exister avec votre courtier,
- comment fonctionnent les mises à jour de marché.

---

# Comprendre les cours dans TradeVision

TradeVision peut afficher plusieurs types de données de marché.

Selon les écrans et les sources disponibles, l’application peut utiliser :

- des cours spot,
- des cours différés,
- des clôtures officielles,
- des historiques quotidiens,
- des données OHLC.

Les prix affichés peuvent évoluer pendant la séance de marché.

---

# Marché ouvert et marché fermé

Les marchés financiers n’utilisent pas les mêmes horaires selon les pays et les places de cotation.

Exemple :

- Euronext Paris,
- Xetra,
- Nasdaq,
- NYSE,
- Londres,
- Suisse,
- Toronto,
- etc.

Pendant l’ouverture du marché :

- les cours peuvent évoluer en permanence,
- certaines données sont mises à jour automatiquement,
- les variations peuvent changer rapidement.

Après la fermeture du marché :

- les cours deviennent plus stables,
- les clôtures officielles peuvent être vérifiées,
- certaines données peuvent être corrigées ou consolidées.

---

# Cours spot

Le cours spot correspond généralement au dernier prix connu sur le marché.

Il peut être :

- quasi temps réel,
- légèrement différé selon la source,
- mis à jour fréquemment pendant la séance.

Le cours spot est utile pour suivre rapidement l’évolution du portefeuille.

Cependant, selon les providers utilisés :

- le délai peut varier,
- certains ETF peuvent être moins bien couverts,
- certaines places peuvent avoir des limitations.

---

# Clôture officielle

La clôture officielle correspond au prix validé à la fin de la séance de marché.

Cette valeur peut être différente :

- du dernier cours spot,
- du prix affiché quelques minutes avant la fermeture,
- du prix affiché par une autre plateforme.

TradeVision peut vérifier automatiquement certaines clôtures après la fermeture des marchés afin de limiter les prix incorrects ou incohérents.

> Important : il est normal que certains prix évoluent légèrement après la clôture avant stabilisation complète des données.

---

# Données OHLC

OHLC signifie :

- Open : ouverture,
- High : plus haut,
- Low : plus bas,
- Close : clôture.

Ces données permettent notamment :

- d’afficher des graphiques,
- de calculer certains indicateurs techniques,
- de reconstruire des historiques quotidiens,
- de vérifier certaines clôtures.

Les données OHLC sont souvent utilisées pour les analyses de performance et les graphiques historiques.

---

# Mise à jour des prix

TradeVision peut mettre à jour les prix :

- au démarrage de l’application,
- automatiquement pendant l’utilisation,
- manuellement depuis les paramètres,
- après certains imports ou maintenances.

Selon votre configuration :

- certaines données peuvent être mises à jour plus souvent,
- certaines sources peuvent être prioritaires,
- certaines APIs peuvent être utilisées avant d’autres.

---

# Pourquoi certains cours peuvent manquer

Un cours peut être absent pour plusieurs raisons.

Exemples :

- le ticker n’est pas reconnu,
- le symbole est ambigu,
- la place de cotation est incorrecte,
- le provider ne couvre pas ce marché,
- le marché est fermé,
- la donnée n’est pas encore disponible,
- l’ETF est peu couvert par les sources gratuites.

Dans ce cas, vérifiez :

- le ticker,
- le suffixe éventuel,
- la place de cotation,
- le code MIC,
- les providers activés.

---

# Différences avec votre courtier

Il est normal que TradeVision affiche parfois des valeurs légèrement différentes de votre courtier.

Ces différences peuvent venir :

- du provider utilisé,
- du délai des données,
- des heures de mise à jour,
- des devises,
- des conversions,
- des clôtures utilisées,
- des arrondis,
- des historiques disponibles.

Deux plateformes différentes peuvent afficher des prix légèrement différents au même moment.

> Important : les données de marché dépendent toujours des fournisseurs utilisés.

---

# Providers gratuits et APIs

TradeVision peut fonctionner avec plusieurs types de sources :

- providers gratuits,
- APIs externes,
- imports manuels,
- historiques importés.

Certaines sources gratuites peuvent avoir :

- des délais,
- des limitations,
- des indisponibilités temporaires,
- une couverture incomplète de certains ETF ou marchés.

Les APIs Pro peuvent améliorer :

- la stabilité,
- la disponibilité,
- la couverture des marchés,
- la précision de certaines données.

Pour plus d’informations :

- [Providers et APIs](providers.md)

---

# Historique des prix

TradeVision peut conserver des historiques de prix locaux.

Ces historiques servent notamment à :

- afficher les graphiques,
- recalculer certaines performances,
- suivre les évolutions quotidiennes,
- alimenter certains outils IA.

Selon votre configuration, les historiques peuvent provenir :

- des providers,
- d’imports manuels,
- d’ABCBourse,
- d’anciennes données déjà présentes dans la base.

---

# Graphiques et indicateurs

Les graphiques peuvent utiliser :

- les historiques quotidiens,
- les données OHLC,
- les cours récents,
- certaines moyennes calculées.

Selon les écrans et les options activées, TradeVision peut afficher :

- moyennes mobiles,
- bandes de Bollinger,
- RSI,
- évolutions de portefeuille,
- variations journalières.

Certaines données peuvent mettre un peu de temps à apparaître après un gros import ou une première synchronisation.

---

# Conseils pour éviter les problèmes de cours

Pour améliorer la qualité des données :

- vérifiez les symboles et les places,
- utilisez des tickers précis,
- ajoutez les suffixes si nécessaire,
- utilisez des providers adaptés à vos marchés,
- faites les imports progressivement,
- évitez les doublons de données.

Après un gros import ou une maintenance, laissez quelques instants à TradeVision pour recalculer certaines informations.

---

# Important à savoir

Les données de marché affichées par TradeVision dépendent des sources utilisées.

L’application :

- ne produit pas elle-même les prix de marché,
- dépend des providers configurés,
- peut afficher des données légèrement différentes d’autres plateformes,
- peut être limitée par certaines sources gratuites.

Les données doivent être utilisées comme des informations de suivi et d’analyse, pas comme des données de trading temps réel garanties.
