﻿TradeVision IA Pro v9.97.4 - Version portable

Lancez tradevision_ia_pro.exe depuis ce dossier.

Dossier source du build :
C:\TradeVision_Build\Projet\build\windows\x64\runner\Release

Date de creation : 2026-09-14 14:41:44
