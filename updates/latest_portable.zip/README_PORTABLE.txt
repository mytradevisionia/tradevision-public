﻿TradeVision IA Pro v9.9.7 - Version portable

Lancez tradevision_ia_pro.exe depuis ce dossier.

Dossier source du build :
C:\TradeVision_Build\Projet\build\windows\x64\runner\Release

Date de creation : 2026-09-07 09:44:52
