# Licencia y edición Pro

TradeVision existe en varias configuraciones según tu licencia y las funciones activadas.

Esta sección explica:

- las diferencias entre el modo Demo y la edición Pro,
- la activación de una licencia,
- la caducidad,
- las posibles limitaciones,
- el uso en varios equipos.

---

# Modo Demo

TradeVision puede funcionar sin licencia Pro.

El modo Demo permite generalmente:

- utilizar las pantallas principales,
- seguir una cartera,
- añadir operaciones,
- usar algunas funciones básicas,
- importar ciertos datos,
- probar la aplicación.

El modo Demo permite descubrir la aplicación antes de activar una licencia completa.

---

# Edición Pro

La edición Pro desbloquea algunas funciones avanzadas según tu configuración.

Ejemplos:

- herramientas IA avanzadas,
- análisis adicionales,
- providers avanzados,
- exportaciones adicionales,
- algunas funciones de mantenimiento,
- ciertas opciones de personalización.

Las funciones exactas pueden evolucionar según las versiones de TradeVision.

---

# Activación de una licencia

La licencia suele poder activarse desde los ajustes de la aplicación.

Según tu versión, la activación puede requerir:

- una clave de licencia,
- cierta información de validación,
- una verificación local o remota.

Después de la activación, algunas funciones adicionales pasan a estar disponibles.

---

# Clave de licencia

La clave de licencia sirve para identificar tu edición de TradeVision.

Según tu oferta, puede incluir:

- un período de validez,
- funciones específicas,
- ciertas limitaciones,
- algunas opciones avanzadas.

> Importante: conserva siempre una copia de tu clave de licencia.

---

# Caducidad de una licencia

Algunas licencias pueden tener una duración limitada.

Cuando la licencia caduca:

- algunas funciones Pro pueden desactivarse,
- algunas opciones avanzadas pueden dejar de estar disponibles,
- la cartera y los datos generalmente siguen siendo accesibles.

Tus datos locales no se eliminan automáticamente.

---

# Renovación

Según tu oferta, la licencia puede renovarse o sustituirse.

Antes de una renovación:

- conserva una copia de seguridad de la cartera,
- comprueba la información de licencia,
- conserva tu clave actual.

En la mayoría de los casos, la renovación no afecta a tus datos locales.

---

# Datos y licencia

La licencia no es tu cartera.

Tu cartera sigue guardada localmente en tus archivos.

Incluso sin licencia activa:

- tus operaciones siguen presentes,
- tus historiales siguen disponibles,
- tus copias de seguridad siguen siendo utilizables,
- tus archivos de cartera siguen siendo accesibles.

> Importante: realiza copias de seguridad periódicas independientemente de la licencia.

---

# Uso en varios equipos

Según tu oferta, puede ser posible utilizar TradeVision en varios equipos.

Sin embargo:

- algunas licencias pueden tener limitaciones,
- algunas activaciones pueden estar vinculadas a un equipo,
- pueden ser necesarias algunas verificaciones.

Si cambias de equipo:

- haz una copia de seguridad de tu cartera,
- conserva tu clave,
- comprueba la información de licencia disponible.

---

# Copias de seguridad recomendadas

Antes de algunas operaciones importantes:

- cambio de equipo,
- reinstalación,
- actualización importante,
- mantenimiento,
- renovación de licencia,

se recomienda encarecidamente:

- crear un backup,
- conservar una copia externa de la cartera,
- comprobar los archivos importantes.

---

# Actualización de la aplicación

Según tu versión, TradeVision puede proponer algunas actualizaciones.

Algunas actualizaciones pueden:

- corregir errores,
- mejorar el rendimiento,
- añadir funciones,
- mejorar los providers,
- mejorar algunas herramientas IA.

Antes de una actualización importante, haz siempre una copia de seguridad de la cartera.

---

# Posibles limitaciones

Según la versión utilizada, pueden existir algunas limitaciones.

Ejemplos:

- funciones IA limitadas,
- providers restringidos,
- exportaciones limitadas,
- algunas opciones avanzadas no disponibles.

Estas limitaciones dependen principalmente de la edición utilizada.

---

# Seguridad y confidencialidad

TradeVision favorece un funcionamiento local.

En la mayoría de los casos:

- las carteras permanecen almacenadas en tu equipo,
- las operaciones permanecen locales,
- las copias de seguridad quedan bajo tu control.

Sin embargo, algunas funciones que utilizan providers externos pueden requerir intercambios limitados de datos con servicios de terceros.

---

# En caso de problema de licencia

Si una licencia parece incorrecta:

- comprueba la clave introducida,
- revisa espacios o caracteres adicionales,
- reinicia la aplicación,
- controla la versión utilizada,
- verifica la información proporcionada durante la activación.

En algunos casos, puede ser necesaria una nueva activación.

---

# Consejos importantes

Para evitar problemas:

- conserva una copia de tu clave,
- realiza copias de seguridad periódicas,
- guarda una copia de la cartera,
- comprueba las actualizaciones importantes,
- evita modificaciones no verificadas de los archivos de licencia.

Una buena gestión de las copias de seguridad sigue siendo la mejor protección contra los problemas técnicos.

---

# Importante saber

La licencia controla principalmente el acceso a algunas funciones avanzadas.

No sustituye:

- las copias de seguridad,
- la verificación de los datos,
- el control de las importaciones,
- las buenas prácticas de gestión de cartera.

El usuario sigue siendo responsable de sus datos locales y de sus copias de seguridad.
