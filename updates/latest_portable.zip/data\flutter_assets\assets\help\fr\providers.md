# Providers et APIs

TradeVision utilise plusieurs providers et APIs externes pour récupérer des données liées aux marchés financiers.

Ces providers peuvent être utilisés pour :

- récupérer les cours spot,
- télécharger les clôtures officielles,
- mettre à jour les historiques de prix,
- récupérer certaines données OHLC,
- compléter certaines informations de titres,
- alimenter certains graphiques,
- fournir certaines données utilisées par les outils IA.

Selon votre configuration, plusieurs providers peuvent être utilisés automatiquement.

---

# Comprendre les providers

Un provider est une source externe utilisée pour récupérer des informations financières.

TradeVision peut utiliser plusieurs types de données :

- cours de marché,
- historiques quotidiens,
- données OHLC,
- métadonnées des titres,
- informations de place de cotation,
- données nécessaires à certaines analyses IA.

Selon les marchés et les titres, certaines sources peuvent être plus adaptées que d’autres.

---

# Rôle des providers dans TradeVision

Les providers jouent un rôle important dans plusieurs parties de l’application.

Ils peuvent servir à :

- télécharger les cours de marché,
- récupérer les clôtures officielles,
- mettre à jour les historiques,
- alimenter certains graphiques,
- récupérer certaines données OHLC,
- compléter certaines informations de titres,
- alimenter certaines fonctions IA.

Sans provider compatible, certaines données peuvent être limitées ou indisponibles.

---

# Providers gratuits

TradeVision peut fonctionner sans licence Pro ni clé API.

Dans ce mode, l’application peut utiliser certaines sources gratuites selon les fonctionnalités disponibles.

Exemples :

- Google Finance,
- Yahoo Finance,
- imports manuels,
- historiques locaux déjà présents dans la base.

Ces sources permettent souvent :

- de suivre les principaux ETF,
- de récupérer des cours simples,
- d’utiliser l’application sans configuration complexe.

---

# Limites des providers gratuits

Les providers gratuits peuvent avoir certaines limitations.

Exemples :

- données différées,
- couverture incomplète,
- marchés peu couverts,
- ETF exotiques absents,
- limitations temporaires,
- indisponibilités ponctuelles,
- changements de format des données.

Il est normal que certains titres fonctionnent mieux avec certaines sources qu’avec d’autres.

---

# APIs externes

TradeVision peut utiliser des APIs externes optionnelles.

Ces APIs peuvent améliorer :

- la stabilité des cours,
- la disponibilité des données,
- la couverture des marchés,
- la qualité de certains historiques,
- certaines fonctions avancées,
- certaines données utilisées par l’IA.

Les APIs ne sont généralement pas obligatoires pour utiliser l’application.

---

# APIs recommandées pour l’édition Pro

Certaines fonctions avancées de TradeVision AI Pro nécessitent des providers compatibles.

Pour une expérience plus complète et une meilleure stabilité des données, l’utilisation d’une API dédiée est fortement recommandée.

Provider recommandé :

- EODHD

Providers compatibles selon votre configuration :

- EODHD
- Leeway
- Finnhub
- FMP

Selon les providers utilisés, certaines données peuvent inclure :

- cours spot,
- clôtures officielles,
- historiques quotidiens,
- données OHLC,
- certaines métadonnées de titres,
- données nécessaires à certains outils IA.

Certaines fonctions avancées de l’édition Pro peuvent être limitées sans clé API compatible.

---

# Clés API

Certaines APIs nécessitent une clé d’accès.

Une clé API permet à un service externe :

- d’identifier votre utilisation,
- d’appliquer certaines limites,
- d’autoriser certaines requêtes.

Les clés API peuvent être renseignées depuis les paramètres de TradeVision.

> Important : certaines APIs gratuites imposent des limites quotidiennes ou mensuelles.

---

# Gratuit ou payant

Selon les services utilisés, les clés API peuvent être :

- gratuites avec limites,
- partiellement gratuites,
- ou payantes.

Les versions gratuites permettent souvent :

- de tester l’application,
- de récupérer un volume limité de données,
- d’utiliser certains marchés principaux.

Les offres payantes peuvent améliorer :

- le nombre de requêtes,
- la stabilité,
- la couverture marché,
- les historiques disponibles.

---

# Google Finance

Google Finance peut être utilisé pour récupérer certains cours simples.

Cette source est souvent pratique pour :

- les ETF courants,
- certaines actions internationales,
- les suivis simples.

Cependant, la couverture dépend du marché et des données accessibles publiquement.

---

# Yahoo Finance

Yahoo Finance est souvent utilisé pour :

- les cours spot,
- certains historiques,
- de nombreux marchés internationaux.

Selon les titres, Yahoo peut parfois fournir :

- de meilleurs résultats,
- des données différentes,
- une couverture plus large.

Cependant, certaines données peuvent varier selon les périodes ou les marchés.

---

# APIs Pro

Selon votre configuration, TradeVision peut utiliser des APIs plus avancées.

Ces APIs peuvent améliorer :

- la qualité des données,
- la stabilité des prix,
- certains historiques,
- la couverture de certains marchés spécialisés.

Selon les services utilisés, certaines APIs peuvent être :

- gratuites avec limites,
- partiellement gratuites,
- payantes,
- soumises à abonnement externe.

---

# EODHD

Certaines configurations de TradeVision peuvent utiliser EODHD pour récupérer :

- des cours spot,
- des clôtures officielles,
- des historiques,
- certaines données OHLC,
- certaines données de marché.

Selon les marchés, EODHD peut offrir :

- une bonne couverture,
- des historiques plus complets,
- des données utiles pour certaines analyses.

Comme toute source externe, les données peuvent varier selon les instruments ou les périodes.

---

# OpenFIGI

OpenFIGI est principalement utilisé pour aider à identifier certains titres.

Ce service peut aider à retrouver :

- des tickers,
- des ISIN,
- des places de cotation,
- certaines métadonnées.

OpenFIGI est surtout utile :

- lors des imports CSV,
- pour les symboles ambigus,
- pour certains ETF ou actions moins connus.

---

# ABCBourse

TradeVision peut aussi utiliser des imports provenant d’ABCBourse.

Ces imports servent principalement à :

- récupérer des historiques quotidiens,
- compléter certaines données locales,
- améliorer certains graphiques,
- reconstruire certains historiques.

ABCBourse est particulièrement utile pour certains marchés européens et certains ETF.

---

# Providers et IA

Certaines fonctions IA utilisent indirectement des données provenant des providers.

Exemples :

- historiques de prix,
- variations,
- tendances,
- données utilisées pour certains indicateurs,
- certaines données OHLC,
- certaines données de marché.

Si les données sont incomplètes, certaines fonctions IA peuvent être limitées.

---

# Choisir les bons providers

Tous les utilisateurs n’ont pas les mêmes besoins.

Exemples :

- portefeuille simple ETF Europe,
- actions américaines,
- ETF internationaux,
- marchés spécialisés,
- gros historiques,
- utilisation principalement locale.

Selon votre portefeuille, certaines sources peuvent être plus adaptées que d’autres.

---

# Pourquoi plusieurs providers peuvent être utilisés

TradeVision peut utiliser plusieurs providers afin de :

- améliorer la disponibilité,
- limiter certaines erreurs,
- récupérer des données complémentaires,
- améliorer certains historiques,
- comparer certaines données de marché.

Certaines données peuvent donc provenir de sources différentes selon :

- le titre,
- le marché,
- le type de donnée,
- la disponibilité du provider.

---

# Problèmes possibles avec les providers

Les providers externes peuvent parfois rencontrer des problèmes.

Exemples :

- données temporaires incorrectes,
- indisponibilité,
- ralentissements,
- changements d’API,
- limites de requêtes,
- couverture partielle de certains ETF.

Dans certains cas, un provider peut fonctionner pour un titre mais pas pour un autre.

---

# Conseils pour limiter les problèmes

Pour améliorer la stabilité des données :

- utilisez des symboles précis,
- ajoutez les suffixes de marché si nécessaire,
- vérifiez les places de cotation,
- utilisez des APIs adaptées à vos marchés,
- évitez les imports incohérents,
- conservez des sauvegardes régulières.

Après un gros import ou un changement de provider, certaines données peuvent nécessiter quelques instants avant stabilisation.

---

# Important à savoir

TradeVision dépend de services externes pour récupérer certaines données.

L’application :

- ne contrôle pas les providers externes,
- ne garantit pas la disponibilité permanente des APIs,
- peut être limitée par certains services gratuits,
- peut afficher des données différentes selon les sources utilisées.

Les providers doivent être vus comme des sources d’information et non comme des flux de trading temps réel garantis.
