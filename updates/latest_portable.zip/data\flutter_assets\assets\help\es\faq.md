# Preguntas frecuentes

Esta sección reúne las preguntas y problemas más habituales en TradeVision IA Pro.

## Preguntas

- [¿Por qué algunos títulos no tienen cotización?](#cotizaciones-faltantes)
- [¿Por qué mis valores difieren de mi bróker?](#diferencia-broker)
- [¿Por qué mi efectivo es incoherente?](#efectivo-incoherente)
- [¿Por qué mi rentabilidad parece incorrecta?](#rentabilidad-incorrecta)
- [¿Por qué un ETF o una acción aparece como “desconocido”?](#titulo-desconocido)
- [¿Por qué algunos tickers son ambiguos?](#tickers-ambiguos)
- [¿Por qué los gráficos están incompletos?](#graficos-incompletos)
- [¿Por qué algunas funciones de IA no funcionan?](#ia-limitada)
- [¿Es obligatoria una clave API?](#clave-api-obligatoria)
- [¿Las APIs son gratuitas?](#apis-gratuitas)
- [¿Por qué cambian las cotizaciones después del cierre?](#cotizaciones-despues-cierre)
- [¿TradeVision funciona en tiempo real?](#tiempo-real)
- [¿Por qué las importaciones CSV crean duplicados?](#duplicados-csv)
- [¿Por qué algunos ETF europeos funcionan mejor con ABCBourse?](#abcbourse)
- [¿Por qué puede ser útil el mantenimiento?](#mantenimiento)
- [¿Debo hacer copias de seguridad regulares?](#copias-seguridad)
- [¿Mis datos se envían a un servidor externo?](#datos-servidor)
- [¿La IA pasa órdenes automáticamente?](#ia-ordenes)
- [¿Puedo usar varias carteras?](#varias-carteras)
- [¿Qué hacer antes de una gran modificación?](#gran-modificacion)

---

# cotizaciones-faltantes

## ¿Por qué algunos títulos no tienen cotización?

Puede deberse a un ticker incorrecto, una plaza no indicada, un proveedor que no cubre el mercado, un título ambiguo, un mercado cerrado o un dato aún no disponible.

Revise el ticker, el sufijo, el código MIC y los proveedores configurados.

Consulte también:

- [Cotizaciones y mercado](pricing.md)
- [Proveedores y APIs](providers.md)

[Volver a las preguntas](#preguntas)

---

# diferencia-broker

## ¿Por qué mis valores difieren de mi bróker?

Pequeñas diferencias son normales.

Pueden venir del proveedor, retraso de datos, divisas, redondeos, cierres utilizados u horarios de actualización.

Dos plataformas pueden mostrar valores ligeramente diferentes al mismo tiempo.

[Volver a las preguntas](#preguntas)

---

# efectivo-incoherente

## ¿Por qué mi efectivo es incoherente?

Normalmente se debe a un ingreso olvidado, una retirada faltante, comisiones no registradas, una importación duplicada o una operación incorrecta.

Revise ingresos, retiradas, comisiones, transferencias internas y últimas operaciones importadas.

[Volver a las preguntas](#preguntas)

---

# rentabilidad-incorrecta

## ¿Por qué mi rentabilidad parece incorrecta?

La rentabilidad depende directamente de las operaciones registradas.

Un resultado incoherente puede venir de una importación incompleta, duplicados, efectivo incorrecto, comisiones faltantes, títulos mal identificados o fechas erróneas.

Revise primero las operaciones antes de lanzar un mantenimiento.

[Volver a las preguntas](#preguntas)

---

# titulo-desconocido

## ¿Por qué un ETF o una acción aparece como “desconocido”?

Puede ocurrir si el ticker no se reconoce, el símbolo es ambiguo, la plaza es incorrecta, falta el ISIN o el proveedor no cubre el título.

Intente indicar sufijo, código MIC, ISIN y plaza de cotización.

[Volver a las preguntas](#preguntas)

---

# tickers-ambiguos

## ¿Por qué algunos tickers son ambiguos?

Un mismo ticker puede existir en varios mercados o en varias divisas, y un ETF puede cotizar en varias plazas.

Use un sufijo, un código MIC o un ISIN para evitar confusiones.

[Volver a las preguntas](#preguntas)

---

# graficos-incompletos

## ¿Por qué los gráficos están incompletos?

Puede ocurrir tras una gran importación, durante una primera sincronización, si faltan historiales o si algunos datos aún no se han descargado.

Algunos historiales pueden tardar unos instantes en estabilizarse.

[Volver a las preguntas](#preguntas)

---

# ia-limitada

## ¿Por qué algunas funciones de IA no funcionan?

Algunas funciones avanzadas necesitan suficiente historial, datos de mercado compatibles y, a veces, una API configurada.

Sin datos suficientes, ciertos análisis pueden estar limitados.

Consulte:

- [IA TradeVision](ai.md)
- [Proveedores y APIs](providers.md)

[Volver a las preguntas](#preguntas)

---

# clave-api-obligatoria

## ¿Es obligatoria una clave API?

No. TradeVision puede funcionar sin clave API.

Pero algunas funciones Pro avanzadas pueden requerir una API compatible, historiales más completos o proveedores avanzados.

Proveedor recomendado: EODHD.

Proveedores compatibles según configuración: EODHD, Leeway, Finnhub y FMP.

[Volver a las preguntas](#preguntas)

---

# apis-gratuitas

## ¿Las APIs son gratuitas?

Depende del proveedor.

Algunas APIs son gratuitas con límites, otras parcialmente gratuitas y otras de pago.

Los planes gratuitos suelen permitir probar la aplicación y recuperar un volumen limitado de datos.

[Volver a las preguntas](#preguntas)

---

# cotizaciones-despues-cierre

## ¿Por qué cambian las cotizaciones después del cierre?

Tras el cierre, algunos datos pueden corregirse, consolidarse o actualizarse en los historiales de los proveedores.

Es normal que ciertos valores cambien ligeramente antes de estabilizarse.

[Volver a las preguntas](#preguntas)

---

# tiempo-real

## ¿TradeVision funciona en tiempo real?

TradeVision no es una plataforma de trading de alta frecuencia.

Según los proveedores, algunos datos pueden ser casi en tiempo real, otros diferidos y algunos cierres validados después del cierre.

[Volver a las preguntas](#preguntas)

---

# duplicados-csv

## ¿Por qué las importaciones CSV crean duplicados?

Suele ocurrir si el mismo archivo se importa varias veces, si varios exports se solapan o si algunas operaciones ya existen.

Los duplicados pueden falsear rentabilidad, efectivo, cantidades y gráficos.

Haga siempre una copia de seguridad antes de una gran importación.

[Volver a las preguntas](#preguntas)

---

# abcbourse

## ¿Por qué algunos ETF europeos funcionan mejor con ABCBourse?

ABCBourse puede ser útil para ciertos ETF europeos, historiales diarios y mercados Euronext.

Según los proveedores, algunos datos pueden ser más completos a través de ABCBourse.

[Volver a las preguntas](#preguntas)

---

# mantenimiento

## ¿Por qué puede ser útil el mantenimiento?

Puede optimizar datos, reconstruir títulos, corregir incoherencias y mejorar algunas prestaciones.

Es útil tras una gran importación CSV, cambios importantes o problemas de datos.

[Volver a las preguntas](#preguntas)

---

# copias-seguridad

## ¿Debo hacer copias de seguridad regulares?

Sí, encarecidamente.

Se recomienda antes de importar, mantener, restaurar o actualizar de forma importante.

Una copia permite volver atrás en caso de problema.

[Volver a las preguntas](#preguntas)

---

# datos-servidor

## ¿Mis datos se envían a un servidor externo?

TradeVision prioriza el funcionamiento local.

En la mayoría de los casos, carteras, operaciones y copias permanecen bajo su control.

Algunas funciones con proveedores externos pueden requerir intercambios limitados con servicios de terceros.

[Volver a las preguntas](#preguntas)

---

# ia-ordenes

## ¿La IA pasa órdenes automáticamente?

No.

TradeVision no pasa órdenes, no se conecta automáticamente al bróker para operar y no garantiza ganancias.

Las herramientas de IA solo ayudan al análisis.

[Volver a las preguntas](#preguntas)

---

# varias-carteras

## ¿Puedo usar varias carteras?

Sí.

TradeVision puede abrir distintos archivos de cartera.

Puede separar PEA y cuenta de valores, crear carteras de prueba o conservar copias independientes.

[Volver a las preguntas](#preguntas)

---

# gran-modificacion

## ¿Qué hacer antes de una gran modificación?

Antes de una operación importante:

- haga una copia de seguridad,
- revise importaciones,
- controle símbolos,
- verifique el efectivo,
- conserve una copia de la cartera actual.

Una buena copia de seguridad es la mejor protección contra errores.

[Volver a las preguntas](#preguntas)
