﻿TRADEVISION IA PRO – VERSION PORTABLE
Version : 9.5.57

Instructions d’utilisation :

1. Extraire complètement le fichier ZIP dans un dossier de votre choix
   (ne pas lancer l’application directement depuis le ZIP)

2. Ouvrir le dossier extrait

3. Lancer le fichier :
   tradevision_ia_pro.exe

---

⚠️ IMPORTANT :

* Si Windows affiche un message de sécurité :
  → Cliquer sur “Informations complémentaires”
  → Puis “Exécuter quand même”

* Il s’agit d’une version portable :
  → aucune installation n’est nécessaire
  → aucun fichier système n’est modifié

---

💡 Conseils :

* Éviter les chemins trop longs ou spéciaux
* Vous pouvez déplacer le dossier où vous voulez
* Vous pouvez créer un raccourci vers l’exécutable

---

Merci d’utiliser TradeVision IA 🚀
