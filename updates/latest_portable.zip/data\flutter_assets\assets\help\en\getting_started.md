# Getting started

This section helps you get started with TradeVision AI Pro without going into technical detail.

The goal is simple: create or open a portfolio, add your first data, check prices and save your work.

---

# What is TradeVision?

TradeVision AI Pro is a local application for portfolio tracking and market analysis.

It lets you track:

- your ETFs,
- your stocks,
- your PEA accounts,
- your securities accounts,
- your available cash,
- your performance,
- your buy, sell, fee and dividend transactions.

TradeVision can also provide AI-based analysis support tools.

These tools help you better understand your portfolio, but they do not replace your own judgment.

> Important: TradeVision never places orders on your behalf.  
> The application does not connect to your broker to buy or sell automatically.

---

# Create or open a portfolio

In TradeVision, a portfolio is a local file.

This file contains, among other things:

- your transactions,
- your positions,
- your cash,
- your price histories,
- your portfolio-specific settings.

You can create a new portfolio or open an existing one from the application menu.

A portfolio file can be backed up, copied or restored like any other file.

> Tip: keep your portfolio files in a folder that is easy to find, for example in your Documents folder.

---

# Add a first transaction

To begin, add a simple transaction.

Example:

- type: buy,
- account: PEA or securities account,
- security: ETF or stock,
- quantity: number of units or shares,
- price: unit price,
- fees: any brokerage fees.

Once the transaction has been saved, TradeVision can recalculate:

- the quantity held,
- the average cost price,
- the line value,
- the gain or loss,
- the security's weight in the portfolio.

> Tip: start with one or two simple transactions before importing a large CSV file.

---

# Add cash

Cash represents the money available in your portfolio.

It is important to enter it correctly, especially if you want to track:

- the total portfolio value,
- contributions,
- withdrawals,
- uninvested balance,
- overall performance.

Depending on your situation, you can add a contribution, a withdrawal or an internal transfer.

If the cash balance looks inconsistent, first check your contribution, withdrawal and fee transactions.

---

# Understand the main screens

TradeVision is organized into several screens.

## Home

The Home screen gives a summary view of the portfolio:

- total value,
- gain or loss,
- daily movement,
- important information,
- position summary.

## Transactions

The Transactions screen lets you view, add or correct your movements:

- buys,
- sells,
- fees,
- taxes,
- dividends,
- contributions,
- withdrawals,
- internal transfers.

## Portfolio

The Portfolio screen displays the securities held and their valuation.

It lets you quickly check:

- the quantity held,
- the average cost price,
- the current price,
- the value of each line,
- the weight of each security.

## Performance

The Performance screen helps you follow how the portfolio changes over time.

It may include:

- portfolio value,
- contributions,
- cash,
- gains or losses,
- return indicators.

## Notes

The Notes screen lets you keep personal notes related to your tracking.

Depending on your version, it may also include spreadsheet-style features for tracking custom data.

## Settings

Settings include, among other things:

- price sources,
- optional API keys,
- the license,
- maintenance,
- display options,
- backup tools.

---

# Check prices

After adding your securities, check that prices load correctly.

A price may be missing if:

- the ticker is ambiguous,
- the security has not yet been recognized,
- the listing venue is not specified,
- the price source does not cover this security,
- the market is closed or the data is not available yet.

In that case, see the sections:

- [Prices and markets](pricing.md)
- [Providers and APIs](providers.md)
- [Import / Export](csv.md)

---

# Back up your portfolio

Backing up is essential.

TradeVision can work with local files, so it is recommended to create safety copies regularly.

Before an important operation, such as a large CSV import or maintenance task, make a backup.

A backup lets you roll back if an error is detected afterwards.

> Tip: always make a backup before importing a large file or restoring an old database.

---

# Best practices for getting started

To avoid mistakes at the beginning:

- start with a few simple transactions,
- check symbols and listing venues,
- add starting cash if needed,
- check retrieved prices,
- make a backup before large imports,
- import your data gradually.

It is better to validate a small clean database than to fix a large incomplete import.

---

# Important to know

TradeVision is a tool for tracking and analysis support.

The application:

- does not guarantee future performance,
- does not replace a financial adviser,
- does not place orders automatically,
- depends on the quality of the data you enter,
- may display prices that differ from your broker depending on the sources used.

AI tools should be treated as aids for reflection, never as buy or sell instructions.
