# Premiers pas

Cette section vous aide à démarrer avec TradeVision AI Pro sans entrer dans les détails techniques.

L’objectif est simple : créer ou ouvrir un portefeuille, ajouter vos premières données, vérifier les cours et sauvegarder votre travail.

---

# Qu’est-ce que TradeVision ?

TradeVision AI Pro est une application locale de suivi de portefeuille et d’analyse de marché.

Elle permet de suivre :

- vos ETF,
- vos actions,
- vos comptes PEA,
- vos comptes CTO,
- votre cash disponible,
- vos performances,
- vos opérations d’achat, de vente, de frais ou de dividendes.

TradeVision peut aussi proposer des outils d’aide à l’analyse basés sur l’IA.

Ces outils servent à mieux comprendre votre portefeuille, mais ils ne remplacent pas votre propre jugement.

> Important : TradeVision ne passe jamais d’ordre à votre place.  
> L’application ne se connecte pas à votre courtier pour acheter ou vendre automatiquement.

---

# Créer ou ouvrir un portefeuille

Dans TradeVision, un portefeuille correspond à un fichier local.

Ce fichier contient notamment :

- vos opérations,
- vos positions,
- votre cash,
- vos historiques de prix,
- vos paramètres liés au portefeuille.

Vous pouvez créer un nouveau portefeuille ou ouvrir un portefeuille existant depuis le menu de l’application.

Un fichier de portefeuille peut être sauvegardé, copié ou restauré comme un fichier classique.

> Conseil : gardez vos fichiers de portefeuille dans un dossier facile à retrouver, par exemple dans vos Documents.

---

# Ajouter une première opération

Pour commencer, ajoutez une opération simple.

Exemple :

- type : achat,
- compte : PEA ou CTO,
- titre : ETF ou action,
- quantité : nombre de parts ou d’actions,
- prix : prix unitaire,
- frais : frais éventuels de courtage.

Une fois l’opération enregistrée, TradeVision peut recalculer :

- la quantité détenue,
- le prix de revient,
- la valeur de la ligne,
- la plus-value ou moins-value,
- le poids du titre dans le portefeuille.

> Conseil : commencez avec une ou deux opérations simples avant d’importer un gros fichier CSV.

---

# Ajouter du cash

Le cash représente l’argent disponible dans votre portefeuille.

Il est important de le renseigner correctement, surtout si vous voulez suivre :

- la valeur totale du portefeuille,
- les apports,
- les retraits,
- le solde non investi,
- la performance globale.

Selon votre situation, vous pouvez ajouter un apport, un retrait ou un virement interne.

Si le cash semble incohérent, vérifiez d’abord vos opérations d’apport, de retrait et de frais.

---

# Comprendre les principaux écrans

TradeVision est organisé en plusieurs écrans.

## Accueil

L’écran d’accueil donne une vue synthétique du portefeuille :

- valeur totale,
- plus-value ou moins-value,
- évolution du jour,
- informations importantes,
- résumé des positions.

## Opérations

L’écran Opérations permet de consulter, ajouter ou corriger vos mouvements :

- achats,
- ventes,
- frais,
- taxes,
- dividendes,
- apports,
- retraits,
- virements internes.

## Portefeuille

L’écran Portefeuille affiche les titres détenus et leur valorisation.

Il permet de vérifier rapidement :

- la quantité détenue,
- le prix de revient,
- le cours actuel,
- la valeur de chaque ligne,
- le poids de chaque titre.

## Performance

L’écran Performance aide à suivre l’évolution du portefeuille dans le temps.

Il peut inclure :

- la valeur du portefeuille,
- les apports,
- le cash,
- les gains ou pertes,
- les indicateurs de rendement.

## Notes

L’écran Notes permet de conserver des notes personnelles liées à votre suivi.

Selon votre version, il peut aussi contenir des fonctions de type tableur pour suivre certaines données personnalisées.

## Paramètres

Les paramètres regroupent notamment :

- les sources de cours,
- les clés API éventuelles,
- la licence,
- la maintenance,
- les options d’affichage,
- les outils de sauvegarde.

---

# Vérifier les cours

Après avoir ajouté vos titres, vérifiez que les cours se chargent correctement.

Un cours peut manquer si :

- le ticker est ambigu,
- le titre n’est pas encore reconnu,
- la place de cotation n’est pas précisée,
- la source de prix ne couvre pas ce titre,
- le marché est fermé ou la donnée n’est pas encore disponible.

Dans ce cas, consultez les sections :

- [Cours et marché](pricing.md)
- [Providers et APIs](providers.md)
- [Import / Export](csv.md)

---

# Sauvegarder son portefeuille

La sauvegarde est une étape essentielle.

TradeVision peut travailler avec des fichiers locaux. Il est donc recommandé de créer régulièrement des copies de sécurité.

Avant une opération importante, comme un gros import CSV ou une maintenance, faites un backup.

Un backup permet de revenir en arrière si une erreur est détectée après coup.

> Conseil : faites toujours une sauvegarde avant d’importer un gros fichier ou de restaurer une ancienne base.

---

# Bonnes pratiques pour bien commencer

Pour éviter les erreurs au démarrage :

- commencez avec quelques opérations simples,
- vérifiez les symboles et les places de cotation,
- ajoutez le cash de départ si nécessaire,
- contrôlez les cours récupérés,
- faites une sauvegarde avant les gros imports,
- importez vos données progressivement.

Il vaut mieux valider une petite base propre que corriger un gros import incomplet.

---

# Important à savoir

TradeVision est un outil d’aide au suivi et à l’analyse.

L’application :

- ne garantit pas les performances futures,
- ne remplace pas un conseiller financier,
- ne passe pas d’ordres automatiquement,
- dépend de la qualité des données que vous renseignez,
- peut afficher des cours différents de votre courtier selon les sources utilisées.

Les outils IA doivent être considérés comme des aides à la réflexion, jamais comme des instructions d’achat ou de vente.
