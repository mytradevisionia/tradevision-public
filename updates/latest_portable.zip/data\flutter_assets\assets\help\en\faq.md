# FAQ

This section gathers the most common questions and issues in TradeVision AI Pro.

## Questions

- [Why do some securities have no price?](#missing-prices)
- [Why are my values different from my broker?](#broker-difference)
- [Why is my cash inconsistent?](#inconsistent-cash)
- [Why does my performance look wrong?](#wrong-performance)
- [Why is an ETF or share shown as “unknown”?](#unknown-security)
- [Why are some tickers ambiguous?](#ambiguous-tickers)
- [Why are charts incomplete?](#incomplete-charts)
- [Why do some AI features not work?](#limited-ai)
- [Is an API key mandatory?](#api-key-required)
- [Are APIs free?](#free-apis)
- [Why do prices change after market close?](#prices-after-close)
- [Does TradeVision work in real time?](#real-time)
- [Why do CSV imports create duplicates?](#csv-duplicates)
- [Why do some European ETFs work better with ABCBourse?](#abcbourse)
- [Why can maintenance be useful?](#maintenance)
- [Should I create regular backups?](#backups)
- [Are my data sent to an external server?](#external-server-data)
- [Does the AI place orders automatically?](#ai-orders)
- [Can I use several portfolios?](#several-portfolios)
- [What should I do before a major change?](#major-change)

---

# missing-prices

## Why do some securities have no price?

Several causes are possible:

- the ticker is incorrect,
- the exchange is not specified,
- the provider does not cover this market,
- the security is ambiguous,
- the market is closed,
- the data is not available yet.

Check in particular:

- the ticker,
- any suffix,
- the MIC code,
- configured providers.

See also:

- [Prices and market data](pricing.md)
- [Providers and APIs](providers.md)

[Back to questions](#questions)

---

# broker-difference

## Why are my values different from my broker?

Small differences are normal.

They may come from:

- the provider used,
- data delay,
- currencies,
- rounding,
- closing prices used,
- update times.

Two platforms can show slightly different values at the same moment.

[Back to questions](#questions)

---

# inconsistent-cash

## Why is my cash inconsistent?

In most cases, this comes from:

- a missing deposit,
- a missing withdrawal,
- fees not entered,
- a duplicate import,
- an incorrect transaction.

Check:

- deposits,
- withdrawals,
- fees,
- internal transfers,
- the latest imported transactions.

[Back to questions](#questions)

---

# wrong-performance

## Why does my performance look wrong?

Performance depends directly on recorded transactions.

Inconsistent results may come from:

- an incomplete import,
- a duplicate,
- incorrect cash,
- missing fees,
- poorly identified securities,
- incorrect dates.

Check your transactions before running maintenance.

[Back to questions](#questions)

---

# unknown-security

## Why is an ETF or share shown as “unknown”?

This may happen if:

- the ticker is not recognized,
- the symbol is ambiguous,
- the exchange is wrong,
- the ISIN is missing,
- the provider does not cover the security.

Try to specify:

- ticker suffix,
- MIC code,
- ISIN,
- exchange.

[Back to questions](#questions)

---

# ambiguous-tickers

## Why are some tickers ambiguous?

The same ticker can exist on several markets.

Examples:

- same symbol in Paris and Amsterdam,
- same ETF listed on several exchanges,
- several possible currencies.

In that case, use:

- a suffix,
- a MIC code,
- an ISIN.

[Back to questions](#questions)

---

# incomplete-charts

## Why are charts incomplete?

This can happen:

- after a large import,
- during first synchronization,
- if some histories are missing,
- if some data has not yet been downloaded.

Depending on your configuration, some histories may need a few moments before stabilizing.

[Back to questions](#questions)

---

# limited-ai

## Why do some AI features not work?

Some advanced AI features need:

- enough history,
- compatible market data,
- sometimes a compatible API.

Without enough data, some analysis may be limited.

See:

- [TradeVision AI](ai.md)
- [Providers and APIs](providers.md)

[Back to questions](#questions)

---

# api-key-required

## Is an API key mandatory?

No, TradeVision can work without an API key.

However, some advanced Pro features may require:

- a compatible API,
- more complete histories,
- advanced providers.

Recommended provider:

- EODHD

Compatible providers depending on your configuration:

- EODHD
- Leeway
- Finnhub
- FMP

[Back to questions](#questions)

---

# free-apis

## Are APIs free?

It depends on the provider.

Depending on the service:

- some APIs are free with limits,
- some are partly free,
- some are paid.

Free plans often allow you to test the application and retrieve a limited amount of data.

[Back to questions](#questions)

---

# prices-after-close

## Why do prices change after market close?

After market close:

- some data may be corrected,
- some closes may be consolidated,
- some providers may update histories.

It is normal for some values to move slightly before full stabilization.

[Back to questions](#questions)

---

# real-time

## Does TradeVision work in real time?

TradeVision is not a high-frequency trading platform.

Depending on providers:

- some data may be near real time,
- some may be delayed,
- some closes may be validated after market close.

Displayed data always depends on the providers used.

[Back to questions](#questions)

---

# csv-duplicates

## Why do CSV imports create duplicates?

Duplicates often appear when:

- the same file is imported several times,
- several exports overlap,
- some transactions already exist.

Duplicates can distort:

- performance,
- cash,
- quantities,
- charts.

Always create a backup before a large import.

[Back to questions](#questions)

---

# abcbourse

## Why do some European ETFs work better with ABCBourse?

ABCBourse can be useful for:

- some European ETFs,
- some daily histories,
- some Euronext markets.

Depending on providers, some data may be more complete through ABCBourse.

[Back to questions](#questions)

---

# maintenance

## Why can maintenance be useful?

Maintenance can help:

- optimize some data,
- rebuild some securities,
- correct inconsistencies,
- improve some performance.

It can be useful after a large CSV import, major changes or data issues.

[Back to questions](#questions)

---

# backups

## Should I create regular backups?

Yes, strongly.

Backups are recommended before:

- import,
- maintenance,
- restore,
- major update.

A backup lets you go back if something goes wrong.

[Back to questions](#questions)

---

# external-server-data

## Are my data sent to an external server?

TradeVision favors local operation.

In most cases:

- portfolios stay on your machine,
- transactions remain local,
- backups stay under your control.

Some features using external providers may require limited exchanges with third-party services.

[Back to questions](#questions)

---

# ai-orders

## Does the AI place orders automatically?

No.

TradeVision:

- does not place orders,
- does not automatically connect to your broker to trade,
- does not guarantee profit.

AI tools are analysis aids only.

[Back to questions](#questions)

---

# several-portfolios

## Can I use several portfolios?

Yes.

TradeVision can open different portfolio files.

You can:

- separate PEA and securities account,
- create test portfolios,
- keep independent backups.

[Back to questions](#questions)

---

# major-change

## What should I do before a major change?

Before an important operation:

- create a backup,
- check imports,
- check symbols,
- check cash,
- keep a copy of the current portfolio.

A good backup is the best protection against mistakes.

[Back to questions](#questions)
