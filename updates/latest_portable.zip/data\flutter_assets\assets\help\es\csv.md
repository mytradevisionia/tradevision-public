# Importación / Exportación

TradeVision permite importar y exportar distintos datos relacionados con la cartera.

Esta sección explica principalmente:

- las importaciones CSV,
- los símbolos y plazas de cotización,
- los tickers ambiguos,
- las copias de seguridad,
- las exportaciones,
- los problemas más frecuentes.

---

# Comprender las importaciones CSV

La importación CSV permite añadir rápidamente:

- operaciones,
- historiales,
- listas de valores,
- algunos datos de cartera.

Suele ser la forma más rápida de recuperar un historial procedente de un bróker o de una herramienta anterior.

---

# Antes de importar un CSV

Antes de una importación importante, se recomienda encarecidamente:

- hacer una copia de seguridad,
- comprobar el formato del archivo,
- importar unas pocas líneas de prueba,
- controlar los símbolos utilizados,
- evitar duplicados.

> Consejo: empieza siempre con un archivo pequeño antes de importar un historial completo.

---

# Tipos de datos importados

Según las herramientas disponibles en tu versión, TradeVision puede importar:

- compras,
- ventas,
- dividendos,
- comisiones,
- impuestos,
- aportaciones,
- retiros,
- transferencias internas,
- historiales de precios.

---

# Símbolos y tickers

Los valores se identifican generalmente mediante un ticker.

Ejemplos:

- AI,
- MC,
- TTE,
- ASML,
- VWCE.

Sin embargo, un mismo ticker puede existir en varios mercados.

Ejemplo:

- SAN puede existir en varias plazas de cotización.

En ese caso, puede ser necesario indicar:

- el sufijo del ticker,
- la plaza,
- el código MIC,
- el ISIN.

---

# Sufijos de mercado

Algunos providers usan sufijos para distinguir las plazas de cotización.

Ejemplos:

- `.PA` para París,
- `.AS` para Ámsterdam,
- `.DE` para Alemania,
- `.L` para Londres.

Según el provider utilizado, estos sufijos pueden ser importantes para recuperar correctamente las cotizaciones.

---

# Códigos MIC

El código MIC identifica una plaza de mercado.

Ejemplos:

- XPAR: Euronext Paris,
- XAMS: Ámsterdam,
- XETR: Xetra,
- XLON: Londres.

Los códigos MIC permiten evitar algunas ambigüedades durante las importaciones.

---

# ISIN

El ISIN es un identificador internacional único.

Ejemplo:

- FR0000121014,
- IE00B4L5Y983.

El ISIN suele ser más fiable que un simple ticker.

Puede ser útil cuando:

- varios valores utilizan el mismo ticker,
- un ETF existe en varios mercados,
- algunos datos son ambiguos.

---

# Tickers ambiguos

Cuando un ticker corresponde a varios valores posibles, TradeVision puede mostrar una advertencia.

Ejemplos:

- mismo ticker en varios mercados,
- varias divisas,
- varios listados de un mismo ETF.

En ese caso, puede ser necesario:

- elegir manualmente el valor correcto,
- precisar la plaza,
- añadir un sufijo,
- utilizar un ISIN.

---

# Valores desconocidos

Un valor puede considerarse desconocido si:

- el ticker es incorrecto,
- la plaza no se reconoce,
- el provider no conoce ese valor,
- el archivo CSV contiene un error,
- el ETF está poco cubierto.

En algunos casos, TradeVision puede proponer herramientas de ayuda para identificarlo.

---

# Comprobar los datos después de importar

Después de una importación, comprueba siempre:

- las cantidades,
- los precios,
- las comisiones,
- el efectivo,
- las cuentas utilizadas,
- los símbolos reconocidos.

Una importación incorrecta puede provocar:

- rendimientos incoherentes,
- efectivo negativo,
- posiciones incorrectas,
- duplicados.

---

# Duplicados de importación

Los duplicados son uno de los problemas más frecuentes.

Aparecen a menudo cuando:

- se importa varias veces el mismo archivo,
- varias exportaciones se solapan,
- algunas operaciones ya existen.

Los duplicados pueden falsear:

- los rendimientos,
- las cantidades,
- el efectivo,
- los gráficos.

> Consejo: revisa siempre tus últimas operaciones después de una importación importante.

---

# Importaciones progresivas

Para historiales grandes, es preferible:

- importar de forma progresiva,
- controlar los resultados por etapas,
- comprobar los símbolos antes de continuar.

Este método permite corregir los errores con más facilidad.

---

# Historial de precios

TradeVision también puede utilizar importaciones de historiales de precios.

Estos historiales sirven especialmente para:

- mostrar los gráficos,
- reconstruir algunos rendimientos,
- alimentar algunas herramientas IA.

Según tu configuración, algunos datos pueden proceder de:

- ABCBourse,
- providers,
- antiguos historiales locales,
- importaciones manuales.

---

# Importación ABCBourse

TradeVision puede importar algunos historiales procedentes de ABCBourse.

Estas importaciones son especialmente útiles para:

- completar historiales diarios,
- algunos ETF europeos,
- ciertos datos faltantes.

Al exportar desde ABCBourse, generalmente se recomienda:

- utilizar los ISIN,
- añadir las plazas de mercado,
- comprobar los formatos utilizados.

---

# Exportación PDF

Según tu versión, TradeVision puede generar algunas exportaciones PDF.

Estas exportaciones pueden contener:

- las posiciones,
- los rendimientos,
- las operaciones,
- algunos gráficos.

Las exportaciones PDF sirven principalmente para el seguimiento y el archivo.

---

# Copias de seguridad y backups

TradeVision permite crear copias locales de seguridad de la cartera.

Una copia de seguridad permite, entre otras cosas:

- volver atrás después de un error,
- proteger los datos,
- restaurar un estado anterior de la cartera.

Antes de una gran importación o de una operación de mantenimiento, haz siempre un backup.

---

# Restaurar una cartera

Una restauración permite sustituir la cartera actual por una copia anterior.

Antes de restaurar:

- comprueba que sea el archivo correcto,
- haz un backup de la cartera actual,
- controla la fecha de la copia de seguridad.

Una restauración puede sobrescribir datos recientes.

---

# Problemas frecuentes después de importar

Los problemas más habituales son:

- símbolos no reconocidos,
- efectivo incoherente,
- duplicados,
- cuentas incorrectas,
- errores de divisa,
- plazas incorrectas,
- valores ambiguos.

En la mayoría de los casos, el problema viene de:

- el archivo CSV,
- el símbolo utilizado,
- la plaza de cotización,
- una importación duplicada.

---

# Consejos para importar correctamente

Para reducir los errores:

- utiliza símbolos precisos,
- añade sufijos si es necesario,
- utiliza ISIN cuando sea posible,
- comprueba las plazas de cotización,
- haz copias de seguridad periódicas,
- importa de forma progresiva los historiales grandes.

Una pequeña comprobación después de cada importación evita muchos problemas más adelante.

---

# Importante saber

TradeVision intenta normalizar automáticamente los datos importados.

Sin embargo:

- algunos tickers pueden seguir siendo ambiguos,
- algunas plazas pueden detectarse mal,
- algunos providers pueden utilizar formatos diferentes.

Las importaciones deben comprobarse siempre después del tratamiento.
