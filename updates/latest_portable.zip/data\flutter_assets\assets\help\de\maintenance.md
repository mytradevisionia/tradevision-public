# Wartung

TradeVision enthält mehrere Wartungswerkzeuge, die dazu dienen:

- bestimmte Daten zu optimieren,
- einige Unstimmigkeiten zu korrigieren,
- Informationen neu aufzubauen,
- Probleme mit Portfolio oder Wertpapieren zu reparieren.

Diese Werkzeuge befinden sich hauptsächlich in den Anwendungseinstellungen.

---

# Vor jeder Wartung

Vor einem wichtigen Wartungsvorgang wird dringend empfohlen:

- das Portfolio zu sichern,
- unnötige Anwendungen zu schließen,
- sicherzustellen, dass aktuelle Importe beendet sind,
- die Anwendung während wichtiger Vorgänge nicht zu unterbrechen.

> Tipp: Erstellen Sie vor jeder größeren Wartung eine Sicherung.

---

# SQLite-Wartung

TradeVision nutzt eine lokale Datenbank für Transaktionen, Wertpapiere, Historien, Marktdaten und Portfolioeinstellungen.

Mit der Zeit können bestimmte Vorgänge die Datenbank größer oder weniger optimiert machen.

Die SQLite-Wartung kann Abfragen optimieren, temporäre Dateien reduzieren, interne Daten bereinigen und die Leistung verbessern.

---

# Wann SQLite-Wartung sinnvoll ist

Sie kann nützlich sein:

- nach einem großen CSV-Import,
- nach vielen Löschungen,
- nach umfangreichen Tests,
- wenn einige Ansichten langsamer werden,
- nach bestimmten Fehlern oder Unterbrechungen.

In den meisten Fällen muss sie nicht regelmäßig ausgeführt werden.

---

# Wertpapiere neu aufbauen

TradeVision kann bestimmte Informationen zu Wertpapieren neu aufbauen.

Das kann helfen bei unstimmigen Wertpapieren, fehlenden Namen, falschen Metadaten oder Zuordnungsproblemen.

Der Neuaufbau kann vorhandene Transaktionen, Historien, lokale Daten und externe Anbieter nutzen.

---

# Wann Wertpapiere neu aufgebaut werden sollten

Dieser Vorgang kann sinnvoll sein nach mehreren CSV-Importen, Symboltests, größeren Änderungen oder wenn Wertpapiere falsch wirken oder nicht mehr korrekt angezeigt werden.

---

# OpenFIGI-Prüfung

TradeVision kann OpenFIGI verwenden, um Wertpapierinformationen zu ergänzen oder zu prüfen.

Diese Prüfung kann ISINs, Ticker, Handelsplätze und Metadaten finden.

Sie ist besonders nützlich bei mehrdeutigen Tickern, falsch erkannten Wertpapieren, auffälligen Daten oder Importen mit komplexen Symbolen.

---

# Datenreparatur

Je nach Version können einige Werkzeuge versuchen, bestimmte Unstimmigkeiten automatisch zu reparieren.

Beispiele:

- falsche Symbole,
- unvollständige Wertpapiere,
- unstimmige Historien,
- fehlende Daten,
- ungültige Zuordnungen.

Einige Reparaturen können je nach Portfoliogröße dauern.

---

# Neuberechnung von Daten

Nach wichtigen Vorgängen kann TradeVision Performance, Positionen, Diagramme, Historien und Statistiken neu berechnen.

Diese Neuberechnungen erfolgen meist automatisch.

Je nach Portfoliogröße kann das einige Augenblicke dauern.

---

# Probleme, die Wartung erfordern können

Wartung kann sinnvoll sein bei:

- unstimmiger Performance,
- falschem Barbestand,
- unvollständigen Diagrammen,
- doppelten Wertpapieren,
- fehlenden Daten,
- starken Verlangsamungen,
- Problemen nach CSV-Import.

In vielen Fällen reicht eine einfache Prüfung von Transaktionen oder Symbolen.

---

# Was Wartung nicht leisten kann

Wartungswerkzeuge können nicht jeden Importfehler automatisch korrigieren, keine Anbieterqualität garantieren, völlig fehlende Daten neu erzeugen, eine Sicherung ersetzen oder eine falsche Historie einer externen Quelle korrigieren.

Einige Fehler müssen manuell geprüft werden.

---

# Sicherungen vor der Wartung

Vor jedem wichtigen Vorgang:

- Sicherung erstellen,
- verwendete Datei prüfen,
- eine aktuelle Kopie des Portfolios behalten.

Eine Sicherung ermöglicht die Rückkehr, falls nach der Wartung ein unerwartetes Ergebnis erscheint.

---

# Wartung und Leistung

Wartung kann Ladezeiten, bestimmte Berechnungen, Diagramme, Suchen und Portfoliooperationen verbessern.

Die Geschwindigkeit hängt aber auch von Datenbankgröße, gespeicherten Historien, verwendeten Anbietern und Rechnerleistung ab.

---

# Nach einer Wartung

Nach bestimmten Wartungsvorgängen:

- TradeVision etwas Zeit für Neuberechnungen geben,
- wichtige Positionen prüfen,
- Barbestand kontrollieren,
- Hauptdiagramme prüfen,
- letzte Importe kontrollieren.

Nach einer großen Neuberechnung ist es normal, dass sich einige Ansichten erst nach kurzer Zeit stabilisieren.

---

# Tipps zur Vermeidung von Problemen

Für eine saubere Datenbank:

- doppelte Importe vermeiden,
- Symbole vor dem Import prüfen,
- regelmäßig sichern,
- große Historien schrittweise importieren,
- unnötige Massenänderungen vermeiden,
- konsistente Daten behalten.

Eine saubere Datenbank senkt das Risiko späterer Fehler erheblich.

---

# Wichtiger Hinweis

Wartungswerkzeuge dienen hauptsächlich zum Optimieren, Neuaufbauen, Prüfen und Reparieren bestimmter Daten.

Sie sollten vorsichtig verwendet werden, besonders nach großen Importen oder wichtigen Änderungen.

Vor jedem sensiblen Vorgang:

- Sicherung erstellen,
- Daten prüfen,
- Ergebnisse nach der Wartung kontrollieren.
