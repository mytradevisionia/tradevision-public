# Cotizaciones y mercado

TradeVision usa varias fuentes para recuperar las cotizaciones de ETF, acciones y otros instrumentos financieros.

Esta sección explica:

- cómo se obtienen los precios,
- por qué pueden variar,
- qué son los precios instantáneos y los cierres oficiales,
- por qué puede haber diferencias con el bróker,
- cómo funcionan las actualizaciones de mercado.

---

# Comprender las cotizaciones en TradeVision

TradeVision puede mostrar distintos tipos de datos de mercado:

- precios instantáneos,
- precios diferidos,
- cierres oficiales,
- historiales diarios,
- datos OHLC.

Los precios mostrados pueden cambiar durante la sesión de mercado.

---

# Mercado abierto y cerrado

Los mercados financieros no tienen todos los mismos horarios.

Ejemplos:

- Euronext París,
- Xetra,
- Nasdaq,
- NYSE,
- Londres,
- Suiza,
- Toronto.

Durante la apertura:

- los precios pueden cambiar continuamente,
- algunos datos se actualizan automáticamente,
- las variaciones pueden moverse rápido.

Después del cierre:

- las cotizaciones se estabilizan,
- los cierres oficiales pueden verificarse,
- algunos datos pueden corregirse o consolidarse.

---

# Precio instantáneo

El precio instantáneo suele corresponder al último precio conocido en el mercado.

Puede ser casi en tiempo real, ligeramente diferido según la fuente o actualizado varias veces durante la sesión.

Sirve para seguir rápidamente la evolución de la cartera.

Sin embargo, según los proveedores:

- el retraso puede variar,
- algunos ETF pueden estar peor cubiertos,
- ciertas plazas pueden tener limitaciones.

---

# Cierre oficial

El cierre oficial es el precio validado al final de la sesión de mercado.

Puede diferir del último precio instantáneo, del precio mostrado pocos minutos antes del cierre o del precio de otra plataforma.

TradeVision puede verificar automáticamente algunos cierres tras el cierre de mercado para limitar precios incorrectos o incoherentes.

> Importante: es normal que algunos precios cambien ligeramente después del cierre antes de estabilizarse por completo.

---

# Datos OHLC

OHLC significa:

- apertura,
- máximo,
- mínimo,
- cierre.

Estos datos permiten mostrar gráficos, calcular indicadores técnicos, reconstruir historiales diarios y verificar cierres.

Se usan a menudo para análisis de rentabilidad y gráficos históricos.

---

# Actualización de precios

TradeVision puede actualizar precios:

- al iniciar la aplicación,
- automáticamente durante el uso,
- manualmente desde los ajustes,
- después de ciertas importaciones o mantenimientos.

Según la configuración, algunas fuentes pueden tener prioridad y algunas APIs pueden usarse antes que otras.

---

# Por qué pueden faltar cotizaciones

Una cotización puede faltar porque:

- el ticker no se reconoce,
- el símbolo es ambiguo,
- la plaza de cotización es incorrecta,
- el proveedor no cubre ese mercado,
- el mercado está cerrado,
- el dato aún no está disponible,
- el ETF está poco cubierto por fuentes gratuitas.

Revise el ticker, el sufijo, la plaza, el código MIC y los proveedores activados.

---

# Diferencias con el bróker

Es normal que TradeVision muestre a veces valores ligeramente distintos de los del bróker.

Las diferencias pueden proceder del proveedor, el retraso de datos, las divisas, conversiones, cierres usados, redondeos u horarios de actualización.

Dos plataformas pueden mostrar precios algo diferentes en el mismo momento.

> Importante: los datos de mercado dependen siempre de los proveedores utilizados.

---

# Proveedores gratuitos y APIs

TradeVision puede funcionar con proveedores gratuitos, APIs externas, importaciones manuales e historiales importados.

Las fuentes gratuitas pueden tener retrasos, límites, interrupciones temporales o cobertura incompleta.

Las APIs Pro pueden mejorar la estabilidad, la disponibilidad, la cobertura de mercados y la precisión de algunos datos.

Más información:

- [Proveedores y APIs](providers.md)

---

# Historial de precios

TradeVision puede conservar historiales locales de precios.

Sirven para gráficos, recálculo de rentabilidad, seguimiento diario y algunas herramientas de IA.

Según la configuración, pueden venir de proveedores, importaciones manuales, ABCBourse o datos antiguos ya presentes en la base.

---

# Gráficos e indicadores

Los gráficos pueden usar historiales diarios, datos OHLC, precios recientes y medias calculadas.

Según las opciones activadas, TradeVision puede mostrar medias móviles, bandas de Bollinger, RSI, evolución de cartera y variaciones diarias.

Tras una gran importación o primera sincronización, algunos datos pueden tardar en aparecer.

---

# Consejos para evitar problemas de cotización

Para mejorar la calidad de los datos:

- revise símbolos y plazas,
- use tickers precisos,
- añada sufijos si hace falta,
- use proveedores adaptados a sus mercados,
- importe progresivamente,
- evite duplicados.

Después de una importación grande o mantenimiento, deje que TradeVision recalcule la información.

---

# Nota importante

TradeVision no produce los precios de mercado por sí mismo.

Depende de los proveedores configurados, puede mostrar datos algo distintos de otras plataformas y puede estar limitado por fuentes gratuitas.

Los datos deben usarse para seguimiento y análisis, no como datos de trading en tiempo real garantizados.
