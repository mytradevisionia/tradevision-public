# Import / Export

TradeVision permet d’importer et d’exporter différentes données liées au portefeuille.

Cette section explique principalement :

- les imports CSV,
- les symboles et places de cotation,
- les tickers ambigus,
- les sauvegardes,
- les exports,
- les problèmes les plus fréquents.

---

# Comprendre les imports CSV

L’import CSV permet d’ajouter rapidement :

- des opérations,
- des historiques,
- des listes de titres,
- certaines données de portefeuille.

C’est souvent la méthode la plus rapide pour récupérer un historique provenant d’un courtier ou d’un ancien outil.

---

# Avant d’importer un CSV

Avant un import important, il est fortement recommandé de :

- faire une sauvegarde,
- vérifier le format du fichier,
- importer quelques lignes de test,
- contrôler les symboles utilisés,
- éviter les doublons.

> Conseil : commencez toujours avec un petit fichier avant d’importer un historique complet.

---

# Types de données importées

Selon les outils disponibles dans votre version, TradeVision peut importer :

- achats,
- ventes,
- dividendes,
- frais,
- taxes,
- apports,
- retraits,
- virements internes,
- historiques de prix.

---

# Symboles et tickers

Les titres sont généralement identifiés par un ticker.

Exemples :

- AI,
- MC,
- TTE,
- ASML,
- VWCE.

Cependant, un même ticker peut exister sur plusieurs marchés.

Exemple :

- SAN peut exister sur plusieurs places de cotation.

Dans ce cas, il peut être nécessaire de préciser :

- le suffixe du ticker,
- la place,
- le code MIC,
- l’ISIN.

---

# Suffixes de marché

Certains providers utilisent des suffixes pour distinguer les places de cotation.

Exemples :

- `.PA` pour Paris,
- `.AS` pour Amsterdam,
- `.DE` pour Allemagne,
- `.L` pour Londres.

Selon le provider utilisé, ces suffixes peuvent être importants pour récupérer correctement les cours.

---

# Codes MIC

Le code MIC identifie une place de marché.

Exemples :

- XPAR : Euronext Paris,
- XAMS : Amsterdam,
- XETR : Xetra,
- XLON : Londres.

Les codes MIC permettent d’éviter certaines ambiguïtés lors des imports.

---

# ISIN

L’ISIN est un identifiant international unique.

Exemple :

- FR0000121014,
- IE00B4L5Y983.

L’ISIN est souvent plus fiable qu’un simple ticker.

Il peut être utile lorsque :

- plusieurs titres utilisent le même ticker,
- un ETF existe sur plusieurs marchés,
- certaines données sont ambiguës.

---

# Tickers ambigus

Lorsqu’un ticker correspond à plusieurs titres possibles, TradeVision peut afficher un avertissement.

Exemples :

- même ticker sur plusieurs marchés,
- plusieurs devises,
- plusieurs listings d’un même ETF.

Dans ce cas, il peut être nécessaire de :

- choisir manuellement le bon titre,
- préciser la place,
- ajouter un suffixe,
- utiliser un ISIN.

---

# Titres inconnus

Un titre peut être considéré comme inconnu si :

- le ticker est incorrect,
- la place n’est pas reconnue,
- le provider ne connaît pas ce titre,
- le fichier CSV contient une erreur,
- l’ETF est peu couvert.

Dans certains cas, TradeVision peut proposer des outils d’aide à l’identification.

---

# Vérifier les données après import

Après un import, vérifiez toujours :

- les quantités,
- les prix,
- les frais,
- le cash,
- les comptes utilisés,
- les symboles reconnus.

Un import incorrect peut provoquer :

- des performances incohérentes,
- un cash négatif,
- des positions incorrectes,
- des doublons.

---

# Doublons d’import

Les doublons sont l’un des problèmes les plus fréquents.

Ils apparaissent souvent lorsque :

- le même fichier est importé plusieurs fois,
- plusieurs exports se chevauchent,
- certaines opérations existent déjà.

Les doublons peuvent fausser :

- les performances,
- les quantités,
- le cash,
- les graphiques.

> Conseil : vérifiez toujours vos dernières opérations après un import important.

---

# Imports progressifs

Pour les gros historiques, il est préférable :

- d’importer progressivement,
- de contrôler les résultats par étapes,
- de vérifier les symboles avant de continuer.

Cette méthode permet de corriger les erreurs plus facilement.

---

# Historique des prix

TradeVision peut aussi utiliser des imports d’historiques de prix.

Ces historiques servent notamment à :

- afficher les graphiques,
- reconstruire certaines performances,
- alimenter certains outils IA.

Selon votre configuration, certaines données peuvent provenir :

- d’ABCBourse,
- des providers,
- d’anciens historiques locaux,
- d’imports manuels.

---

# Import ABCBourse

TradeVision peut importer certains historiques provenant d’ABCBourse.

Ces imports sont surtout utiles pour :

- compléter les historiques quotidiens,
- certains ETF européens,
- certaines données manquantes.

Lors de l’export depuis ABCBourse, il est généralement recommandé :

- d’utiliser les ISIN,
- d’ajouter les places de marché,
- de vérifier les formats utilisés.

---

# Export PDF

Selon votre version, TradeVision peut générer certains exports PDF.

Ces exports peuvent contenir :

- les positions,
- les performances,
- les opérations,
- certains graphiques.

Les exports PDF servent principalement au suivi et à l’archivage.

---

# Sauvegardes et backups

TradeVision permet de créer des sauvegardes locales du portefeuille.

Une sauvegarde permet notamment :

- de revenir en arrière après une erreur,
- de sécuriser les données,
- de restaurer un ancien état du portefeuille.

Avant un gros import ou une maintenance, faites toujours un backup.

---

# Restaurer un portefeuille

Une restauration permet de remplacer le portefeuille actuel par une sauvegarde précédente.

Avant une restauration :

- vérifiez le bon fichier,
- faites un backup du portefeuille actuel,
- contrôlez la date de la sauvegarde.

Une restauration peut écraser les données récentes.

---

# Problèmes fréquents après import

Les problèmes les plus courants sont :

- symboles non reconnus,
- cash incohérent,
- doublons,
- mauvais comptes,
- erreurs de devise,
- places incorrectes,
- titres ambigus.

Dans la majorité des cas, le problème vient :

- du fichier CSV,
- du symbole utilisé,
- de la place de cotation,
- d’un import dupliqué.

---

# Conseils pour réussir ses imports

Pour limiter les erreurs :

- utilisez des symboles précis,
- ajoutez les suffixes si nécessaire,
- utilisez les ISIN lorsque possible,
- vérifiez les places de cotation,
- faites des sauvegardes régulières,
- importez progressivement les gros historiques.

Une petite vérification après chaque import évite beaucoup de problèmes plus tard.

---

# Important à savoir

TradeVision essaie de normaliser automatiquement les données importées.

Cependant :

- certains tickers peuvent rester ambigus,
- certaines places peuvent être mal détectées,
- certains providers peuvent utiliser des formats différents.

Les imports doivent toujours être vérifiés après traitement.
