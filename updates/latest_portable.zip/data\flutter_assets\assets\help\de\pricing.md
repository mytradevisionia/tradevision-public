# Kurse und Marktdaten

TradeVision nutzt mehrere Datenquellen, um Kurse für ETFs, Aktien und andere Finanzinstrumente abzurufen.

Dieser Bereich erklärt:

- wie Kurse abgerufen werden,
- warum Kurse variieren können,
- was Spotkurse und offizielle Schlusskurse bedeuten,
- warum Abweichungen zum Broker entstehen können,
- wie Marktaktualisierungen funktionieren.

---

# Kurse in TradeVision verstehen

TradeVision kann verschiedene Arten von Marktdaten anzeigen:

- Spotkurse,
- verzögerte Kurse,
- offizielle Schlusskurse,
- Tageshistorien,
- OHLC-Daten.

Während der Börsensitzung können sich angezeigte Kurse ändern.

---

# Markt geöffnet und Markt geschlossen

Finanzmärkte haben je nach Land und Handelsplatz unterschiedliche Öffnungszeiten.

Beispiele:

- Euronext Paris,
- Xetra,
- Nasdaq,
- NYSE,
- London,
- Schweiz,
- Toronto.

Während der Markt geöffnet ist, können Kurse laufend schwanken, Daten automatisch aktualisiert werden und Veränderungen schnell auftreten.

Nach Marktschluss werden Kurse stabiler, offizielle Schlusskurse können geprüft und Daten korrigiert oder konsolidiert werden.

---

# Spotkurs

Der Spotkurs entspricht in der Regel dem zuletzt bekannten Marktpreis.

Er kann nahezu in Echtzeit, je nach Quelle leicht verzögert oder während der Sitzung häufig aktualisiert sein.

Er ist nützlich, um die Portfolioentwicklung schnell zu verfolgen.

Je nach Anbieter können jedoch Verzögerungen, schwächere ETF-Abdeckung oder Einschränkungen einzelner Handelsplätze bestehen.

---

# Offizieller Schlusskurs

Der offizielle Schlusskurs ist der am Ende der Börsensitzung bestätigte Preis.

Er kann vom letzten Spotkurs, vom kurz vor Handelsschluss angezeigten Preis oder vom Preis einer anderen Plattform abweichen.

TradeVision kann bestimmte Schlusskurse nach Marktschluss automatisch prüfen, um falsche oder unstimmige Preise zu begrenzen.

> Wichtig: Es ist normal, dass sich manche Kurse nach Marktschluss noch leicht verändern, bevor die Daten vollständig stabil sind.

---

# OHLC-Daten

OHLC bedeutet:

- Eröffnung,
- Hoch,
- Tief,
- Schluss.

Diese Daten werden verwendet, um Diagramme anzuzeigen, technische Indikatoren zu berechnen, Tageshistorien aufzubauen und Schlusskurse zu prüfen.

Sie werden häufig für Performanceanalysen und historische Diagramme genutzt.

---

# Kursaktualisierung

TradeVision kann Kurse aktualisieren:

- beim Start der Anwendung,
- automatisch während der Nutzung,
- manuell über die Einstellungen,
- nach bestimmten Importen oder Wartungen.

Je nach Konfiguration können manche Quellen priorisiert und manche APIs vor anderen verwendet werden.

---

# Warum Kurse fehlen können

Ein Kurs kann fehlen, wenn der Ticker nicht erkannt wird, das Symbol mehrdeutig ist, der Handelsplatz falsch ist, der Anbieter den Markt nicht abdeckt, der Markt geschlossen ist, die Daten noch nicht verfügbar sind oder ein ETF von kostenlosen Quellen schlecht abgedeckt wird.

Prüfen Sie Ticker, Suffix, Handelsplatz, MIC-Code und aktivierte Anbieter.

---

# Unterschiede zum Broker

Es ist normal, dass TradeVision gelegentlich leicht andere Werte als der Broker anzeigt.

Abweichungen können durch Anbieter, Datenverzögerung, Währungen, Umrechnungen, verwendete Schlusskurse, Rundungen, Historien oder Aktualisierungszeiten entstehen.

Zwei Plattformen können zum selben Zeitpunkt leicht unterschiedliche Preise anzeigen.

> Wichtig: Marktdaten hängen immer von den verwendeten Datenlieferanten ab.

---

# Kostenlose Anbieter und APIs

TradeVision kann mit kostenlosen Anbietern, externen APIs, manuellen Importen und importierten Historien arbeiten.

Kostenlose Quellen können Verzögerungen, Limits, zeitweise Ausfälle oder unvollständige Abdeckung haben.

Pro-APIs können Stabilität, Verfügbarkeit, Marktabdeckung und Datengenauigkeit verbessern.

Weitere Informationen:

- [Anbieter und APIs](providers.md)

---

# Kurshistorie

TradeVision kann lokale Kurshistorien speichern.

Sie dienen für Diagramme, Performance-Neuberechnungen, tägliche Veränderungen und bestimmte KI-Werkzeuge.

Je nach Konfiguration stammen Historien von Anbietern, manuellen Importen, ABCBourse oder bereits vorhandenen Daten.

---

# Diagramme und Indikatoren

Diagramme können Tageshistorien, OHLC-Daten, aktuelle Kurse und berechnete Durchschnitte nutzen.

Je nach Ansicht und Optionen kann TradeVision gleitende Durchschnitte, Bollinger-Bänder, RSI, Portfolioentwicklungen und Tagesveränderungen anzeigen.

Nach einem großen Import oder einer ersten Synchronisierung kann es etwas dauern, bis alles erscheint.

---

# Tipps gegen Kursprobleme

Für bessere Datenqualität:

- Symbole und Handelsplätze prüfen,
- genaue Ticker verwenden,
- bei Bedarf Suffixe hinzufügen,
- geeignete Anbieter für die Märkte nutzen,
- schrittweise importieren,
- doppelte Daten vermeiden.

Nach großen Importen oder Wartungen sollte TradeVision Zeit für Neuberechnungen bekommen.

---

# Wichtiger Hinweis

TradeVision erzeugt keine Marktkurse selbst.

Die Anwendung hängt von konfigurierten Anbietern ab, kann leicht andere Daten als andere Plattformen anzeigen und durch kostenlose Quellen begrenzt sein.

Die Daten dienen der Überwachung und Analyse, nicht als garantierte Echtzeit-Handelsdaten.
