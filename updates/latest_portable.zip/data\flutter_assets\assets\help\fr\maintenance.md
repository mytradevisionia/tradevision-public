# Maintenance

TradeVision inclut plusieurs outils de maintenance destinés à :

- optimiser certaines données,
- corriger certaines incohérences,
- reconstruire certaines informations,
- réparer certains problèmes liés au portefeuille ou aux titres.

Ces outils sont principalement accessibles depuis les paramètres de l’application.

---

# Avant toute maintenance

Avant d’utiliser un outil de maintenance important, il est fortement recommandé de :

- faire une sauvegarde du portefeuille,
- fermer les autres applications inutiles,
- vérifier que les imports récents sont terminés,
- éviter d’interrompre l’application pendant une opération importante.

> Conseil : faites toujours un backup avant une maintenance importante.

---

# Maintenance SQLite

TradeVision utilise une base de données locale pour enregistrer :

- les opérations,
- les titres,
- les historiques,
- certaines données de marché,
- les paramètres liés au portefeuille.

Avec le temps, certaines opérations peuvent rendre la base plus lourde ou moins optimisée.

La maintenance SQLite peut aider à :

- optimiser certaines requêtes,
- réduire certains fichiers temporaires,
- nettoyer certaines données internes,
- améliorer certaines performances.

---

# Quand utiliser la maintenance SQLite

La maintenance SQLite peut être utile :

- après un gros import CSV,
- après beaucoup de suppressions,
- après des tests importants,
- si certains écrans deviennent plus lents,
- après certaines erreurs ou interruptions.

Dans la majorité des cas, il n’est pas nécessaire de lancer cette maintenance régulièrement.

---

# Reconstruction des titres

TradeVision peut reconstruire certaines informations liées aux titres.

Cette opération peut aider à corriger :

- des titres incohérents,
- certains noms manquants,
- certaines métadonnées incorrectes,
- certains problèmes de mapping.

La reconstruction peut utiliser :

- les opérations existantes,
- les historiques,
- certaines données locales,
- certains providers externes.

---

# Quand reconstruire les titres

Cette opération peut être utile :

- après plusieurs imports CSV,
- après des tests de symboles,
- après des modifications importantes,
- si certains titres semblent incorrects,
- si certaines informations ne s’affichent plus correctement.

---

# Vérification OpenFIGI

TradeVision peut utiliser OpenFIGI pour compléter ou vérifier certaines informations de titres.

Cette vérification peut aider à retrouver :

- des ISIN,
- des tickers,
- des places de cotation,
- certaines métadonnées.

Cette fonction est surtout utile lorsque :

- un ticker est ambigu,
- un titre est mal reconnu,
- certaines données semblent incorrectes,
- des imports contiennent des symboles complexes.

---

# Réparation de certaines données

Selon votre version, certains outils peuvent tenter de réparer automatiquement certaines incohérences.

Exemples :

- symboles incorrects,
- titres incomplets,
- historiques incohérents,
- données manquantes,
- mappings invalides.

Certaines réparations peuvent prendre un peu de temps selon la taille du portefeuille.

---

# Recalcul des données

Après certaines opérations importantes, TradeVision peut recalculer :

- les performances,
- les positions,
- les graphiques,
- les historiques,
- certaines statistiques.

Ces recalculs sont généralement automatiques.

Selon la taille du portefeuille, cela peut prendre quelques instants.

---

# Problèmes pouvant nécessiter une maintenance

Certaines situations peuvent justifier une maintenance.

Exemples :

- performances incohérentes,
- cash incorrect,
- graphiques incomplets,
- titres dupliqués,
- données manquantes,
- ralentissements importants,
- problèmes après import CSV.

Dans de nombreux cas, une simple vérification des opérations ou des symboles suffit.

---

# Ce qu’une maintenance ne fait pas

Les outils de maintenance ne peuvent pas :

- corriger automatiquement toutes les erreurs d’import,
- garantir la qualité des providers,
- recréer des données totalement absentes,
- remplacer une sauvegarde,
- corriger un mauvais historique fourni par une source externe.

Certaines erreurs nécessitent une vérification manuelle.

---

# Sauvegardes avant maintenance

Avant toute opération importante :

- créez un backup,
- vérifiez le fichier utilisé,
- conservez une copie récente du portefeuille.

Une sauvegarde permet de revenir en arrière si un résultat inattendu apparaît après une maintenance.

---

# Maintenance et performances

La maintenance peut parfois améliorer :

- le temps de chargement,
- certains calculs,
- les graphiques,
- les recherches,
- certaines opérations de portefeuille.

Cependant, la vitesse dépend aussi :

- de la taille de la base,
- des historiques stockés,
- des providers utilisés,
- des performances de votre machine.

---

# Après une maintenance

Après certaines opérations de maintenance :

- laissez quelques instants à TradeVision pour recalculer certaines données,
- vérifiez les positions importantes,
- contrôlez le cash,
- vérifiez les graphiques principaux,
- contrôlez les derniers imports.

Il est normal que certains écrans prennent un peu de temps à se stabiliser après un gros recalcul.

---

# Conseils pour limiter les problèmes

Pour garder une base propre :

- évitez les imports dupliqués,
- vérifiez les symboles avant import,
- utilisez des sauvegardes régulières,
- importez progressivement les gros historiques,
- évitez les modifications massives inutiles,
- conservez des données cohérentes.

Une base propre réduit fortement les risques d’erreurs futures.

---

# Important à savoir

Les outils de maintenance servent principalement à :

- optimiser,
- reconstruire,
- vérifier,
- réparer certaines données.

Ils doivent être utilisés avec prudence, surtout après de gros imports ou des modifications importantes.

Avant toute opération sensible :

- faites une sauvegarde,
- vérifiez vos données,
- contrôlez les résultats après maintenance.
