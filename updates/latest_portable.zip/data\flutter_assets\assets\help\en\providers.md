# Providers and APIs

TradeVision uses several external providers and APIs to retrieve financial market data.

These providers can be used to:

- retrieve spot prices,
- download official closes,
- update price histories,
- retrieve certain OHLC data,
- complete certain security information,
- feed certain charts,
- provide certain data used by AI tools.

Depending on your configuration, several providers may be used automatically.

---

# Understanding providers

A provider is an external source used to retrieve financial information.

TradeVision can use several types of data:

- market prices,
- daily histories,
- OHLC data,
- security metadata,
- listing venue information,
- data needed for certain AI analyses.

Depending on the markets and securities, some sources may be more suitable than others.

---

# Role of providers in TradeVision

Providers play an important role in several parts of the application.

They can be used to:

- download market prices,
- retrieve official closes,
- update histories,
- feed certain charts,
- retrieve certain OHLC data,
- complete certain security information,
- feed certain AI features.

Without a compatible provider, some data may be limited or unavailable.

---

# Free providers

TradeVision can run without a Pro license or API key.

In this mode, the application can use certain free sources depending on the available features.

Examples:

- Google Finance,
- Yahoo Finance,
- manual imports,
- local histories already present in the database.

These sources often allow you to:

- track the main ETFs,
- retrieve simple prices,
- use the application without complex configuration.

---

# Limits of free providers

Free providers may have certain limitations.

Examples:

- delayed data,
- incomplete coverage,
- poorly covered markets,
- missing exotic ETFs,
- temporary limitations,
- occasional unavailability,
- changes in data format.

It is normal for some securities to work better with some sources than with others.

---

# External APIs

TradeVision can use optional external APIs.

These APIs can improve:

- price stability,
- data availability,
- market coverage,
- the quality of certain histories,
- certain advanced features,
- certain data used by AI.

APIs are generally not required to use the application.

---

# Recommended APIs for the Pro edition

Some advanced TradeVision AI Pro features require compatible providers.

For a more complete experience and better data stability, using a dedicated API is strongly recommended.

Recommended provider:

- EODHD

Compatible providers depending on your configuration:

- EODHD
- Leeway
- Finnhub
- FMP

Depending on the providers used, some data may include:

- spot prices,
- official closes,
- daily histories,
- OHLC data,
- certain security metadata,
- data needed by certain AI tools.

Some advanced Pro edition features may be limited without a compatible API key.

---

# API keys

Some APIs require an access key.

An API key allows an external service to:

- identify your usage,
- apply certain limits,
- authorize certain requests.

API keys can be entered from the TradeVision settings.

> Important: some free APIs impose daily or monthly limits.

---

# Free or paid

Depending on the services used, API keys may be:

- free with limits,
- partially free,
- or paid.

Free versions often allow you to:

- test the application,
- retrieve a limited volume of data,
- use certain major markets.

Paid plans may improve:

- the number of requests,
- stability,
- market coverage,
- available histories.

---

# Google Finance

Google Finance can be used to retrieve certain simple prices.

This source is often convenient for:

- common ETFs,
- certain international stocks,
- simple tracking.

However, coverage depends on the market and publicly available data.

---

# Yahoo Finance

Yahoo Finance is often used for:

- spot prices,
- certain histories,
- many international markets.

Depending on the securities, Yahoo may sometimes provide:

- better results,
- different data,
- wider coverage.

However, some data may vary depending on periods or markets.

---

# Pro APIs

Depending on your configuration, TradeVision can use more advanced APIs.

These APIs can improve:

- data quality,
- price stability,
- certain histories,
- coverage of some specialized markets.

Depending on the services used, some APIs may be:

- free with limits,
- partially free,
- paid,
- subject to an external subscription.

---

# EODHD

Some TradeVision configurations can use EODHD to retrieve:

- spot prices,
- official closes,
- histories,
- certain OHLC data,
- certain market data.

Depending on the markets, EODHD may offer:

- good coverage,
- more complete histories,
- useful data for certain analyses.

Like any external source, data may vary depending on instruments or periods.

---

# OpenFIGI

OpenFIGI is mainly used to help identify certain securities.

This service can help retrieve:

- tickers,
- ISINs,
- listing venues,
- certain metadata.

OpenFIGI is especially useful:

- during CSV imports,
- for ambiguous symbols,
- for certain less common ETFs or stocks.

---

# ABCBourse

TradeVision can also use imports from ABCBourse.

These imports are mainly used to:

- retrieve daily histories,
- complete certain local data,
- improve certain charts,
- rebuild certain histories.

ABCBourse is particularly useful for some European markets and ETFs.

---

# Providers and AI

Some AI features indirectly use data from providers.

Examples:

- price histories,
- movements,
- trends,
- data used for certain indicators,
- certain OHLC data,
- certain market data.

If the data is incomplete, some AI features may be limited.

---

# Choosing the right providers

Not all users have the same needs.

Examples:

- simple European ETF portfolio,
- US stocks,
- international ETFs,
- specialized markets,
- large histories,
- mainly local use.

Depending on your portfolio, some sources may be more suitable than others.

---

# Why several providers can be used

TradeVision can use several providers in order to:

- improve availability,
- reduce certain errors,
- retrieve complementary data,
- improve certain histories,
- compare certain market data.

Some data may therefore come from different sources depending on:

- the security,
- the market,
- the type of data,
- provider availability.

---

# Possible provider issues

External providers may sometimes encounter problems.

Examples:

- temporarily incorrect data,
- unavailability,
- slowdowns,
- API changes,
- request limits,
- partial coverage of certain ETFs.

In some cases, a provider may work for one security but not for another.

---

# Tips to reduce problems

To improve data stability:

- use precise symbols,
- add market suffixes if needed,
- check listing venues,
- use APIs suited to your markets,
- avoid inconsistent imports,
- keep regular backups.

After a large import or a provider change, some data may need a few moments to stabilize.

---

# Important to know

TradeVision depends on external services to retrieve certain data.

The application:

- does not control external providers,
- does not guarantee permanent API availability,
- may be limited by certain free services,
- may display different data depending on the sources used.

Providers should be seen as information sources, not as guaranteed real-time trading feeds.
