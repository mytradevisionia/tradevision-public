# Portfolio and transactions

This section explains how TradeVision manages transactions, accounts and portfolio tracking.

Transactions are the foundation of the application. They are used to automatically recalculate:

- open positions,
- available cash,
- performance,
- gains and losses,
- cost basis,
- charts and statistics.

---

# Understanding the portfolio

A portfolio includes:

- the securities you hold,
- your accounts,
- your cash,
- your transactions,
- price histories.

TradeVision can manage several account types, including:

- PEA,
- securities account,
- other custom accounts depending on your setup.

Each transaction is stored in your local portfolio.

---

# Main transaction types

TradeVision supports several transaction types.

## Buy

A buy transaction increases:

- the quantity held,
- the invested amount,
- any related fees.

Buys are used to recalculate:

- unit cost basis,
- open positions,
- performance.

---

## Sell

A sell transaction reduces or closes a position.

TradeVision can automatically recalculate:

- realized gain or loss,
- remaining quantities,
- performance statistics.

Depending on your settings, different calculation methods may be used for sales.

---

## Dividend

Dividends add income linked to a security.

Depending on how they are entered, they can:

- increase cash,
- be linked to a specific account,
- be included in overall performance.

---

## Fees and taxes

Fees make it possible to track:

- brokerage fees,
- some taxes,
- transaction-related costs.

They can directly affect:

- performance,
- available cash,
- return calculations.

> Tip: entering fees correctly improves result accuracy.

---

## Deposit

A deposit adds cash to the portfolio.

Examples:

- deposit into a PEA,
- deposit into a securities account,
- manual cash addition.

Deposits are important for correctly tracking:

- performance,
- returns,
- value charts.

---

## Withdrawal

A withdrawal reduces available cash.

Examples:

- bank withdrawal,
- cash transfer,
- money leaving the portfolio.

---

## Internal transfer

Internal transfers move cash between accounts.

Examples:

- transfer between securities account and PEA,
- transfer between sub-portfolios.

These transactions prevent global performance from being distorted.

---

# Understanding cash

Cash is money available but not invested.

Cash can change because of:

- buys,
- sells,
- dividends,
- fees,
- deposits,
- withdrawals,
- internal transfers.

Negative cash can indicate:

- a missing deposit,
- missing fees,
- an incorrect transaction,
- an incomplete import.

---

# PEA and securities accounts

TradeVision can manage different account types.

## PEA

A PEA is often used for:

- European shares,
- eligible ETFs,
- specific tax tracking.

Depending on available data, some screens may display PEA eligibility.

---

## Securities account

A securities account is more flexible and can hold:

- international shares,
- ETFs not eligible for PEA,
- instruments listed on several markets.

TradeVision can track several accounts separately if needed.

---

# Cost basis and performance

TradeVision recalculates several indicators from your transactions.

Examples:

- unit cost basis,
- gain or loss,
- invested value,
- overall return,
- annual performance.

These calculations depend directly on the quality of the recorded transactions.

> Important: if results look inconsistent, first check your transactions and cash.

---

# Securities and symbols

Each security can be identified with several pieces of information:

- ticker,
- ISIN,
- exchange,
- currency.

Some symbols are ambiguous when they exist on several markets.

Example:

- the same ticker may exist in Paris, Amsterdam or Frankfurt.

In that case, you may need to specify:

- the exchange,
- the MIC code,
- the ticker suffix.

For more information, see:

- [Prices and market data](pricing.md)
- [Import / Export](csv.md)

---

# Edit or correct a transaction

Transactions can be corrected from the Transactions screen.

After a major edit:

- positions,
- performance,
- cash,
- charts

may be recalculated automatically.

If some data still looks wrong after a large import, use the maintenance tools.

---

# Tips to avoid errors

To keep a consistent portfolio:

- check symbols before validating,
- enter fees correctly,
- add real cash deposits,
- avoid duplicate imports,
- create regular backups,
- import large histories progressively.

A small transaction error can have a major impact on calculated performance.

---

# Important note

TradeVision relies mainly on the transactions stored in your portfolio.

If imported data is incomplete or incorrect:

- cash may become inconsistent,
- some performance values may be distorted,
- positions may look wrong.

Before making major changes:

- create a backup,
- check imports,
- verify symbols and accounts.
