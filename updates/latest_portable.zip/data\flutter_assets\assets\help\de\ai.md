# TradeVision KI

TradeVision IA Pro enthält mehrere Werkzeuge zur Analyseunterstützung auf Basis von Marktindikatoren, Kurshistorien und Kontextdaten.

Ziel dieser Werkzeuge ist es:

- ein Portfolio besser zu analysieren,
- bestimmte Trends zu erkennen,
- Wertpapiere zu vergleichen,
- Diversifikationsideen vorzuschlagen,
- den Gesamtmarkt besser einzuordnen.

KI-Funktionen sind als Entscheidungshilfe zu verstehen, niemals als garantierte Anlageberatung.

---

# Was die KI macht

Je nach Version und verfügbaren Daten können KI-Werkzeuge technische Indikatoren analysieren, Marktveränderungen verfolgen, Trends erkennen, Scores erzeugen, Diversifikationsideen vorschlagen, Nachrichten auswerten und Aktien oder ETFs vergleichen.

Diese Werkzeuge verwenden hauptsächlich Kurshistorien, Marktdaten, Informationen aus dem Portfolio und konfigurierte Anbieter.

---

# Technische Signale

TradeVision kann mehrere technische Signale berechnen:

- RSI,
- gleitende Durchschnitte,
- Volatilität,
- Momentum,
- Bollinger-Bänder,
- Trendänderungen.

Diese Signale sollen Informationen für den Benutzer verständlicher machen.

---

# KI-Hinweise

Je nach Datenlage kann TradeVision vereinfachte Hinweise erzeugen:

- Kaufen,
- Halten,
- Verkaufen,
- Neutral.

Diese Hinweise werden meist mit einem Score, einem Vertrauensniveau und Kontextinformationen angezeigt.

> Wichtig: Ein KI-Hinweis ist niemals eine Garantie für Performance.

---

# KI-Score

Der KI-Score ist eine aus mehreren verfügbaren Daten berechnete Einschätzung.

Je nach Konfiguration kann er Trends, Historien, Veränderungen, technische Indikatoren, Marktdaten und Nachrichten berücksichtigen.

Der Score hilft vor allem beim Vergleich mehrerer Wertpapiere.

---

# Vertrauensniveau

Einige Ansichten können ein Vertrauensniveau zu einem Signal oder Score anzeigen.

Dieses Vertrauen hängt von Datenqualität, Marktstabilität, verfügbaren Historien, jüngsten Veränderungen und Kontextdaten ab.

Ein hoher Score mit geringem Vertrauen sollte vorsichtig interpretiert werden.

---

# Diversifikation

TradeVision kann Diversifikationsideen vorschlagen.

Diese können ETFs, Sektoren, geografische Regionen, Marktthemen oder Wertpapiere mit Bezug zum Portfolio enthalten.

Ziel ist es, weitere Möglichkeiten der Aufteilung zu erkunden.

---

# Nachrichtenbewertung

Einige KI-Funktionen können Nachrichten aus bestimmten Anbietern analysieren.

Je nach Datenlage kann TradeVision Trends, wichtige Ereignisse, Phasen hoher Aktivität oder positive und negative Tendenzen erkennen.

Diese Daten ergänzen bestimmte Analysen.

---

# KI und Portfolio

Einige KI-Analysen können direkt Daten aus dem Portfolio verwenden:

- gehaltene Wertpapiere,
- Sektoren,
- Performance,
- Gewichtungen,
- lokale Historie.

Dadurch kann TradeVision passendere Analysen liefern.

---

# Verwendete Daten

KI-Funktionen hängen stark von den verfügbaren Daten ab.

Ergebnisse können je nach Anbietern, vorhandenen Historien, Importqualität, abgedeckten Märkten, verfügbaren ETFs und fehlenden Daten variieren.

Unvollständige Daten können Analysen begrenzen.

---

# Lokale KI

Ein wichtiger Teil der Verarbeitung kann lokal auf Ihrem Rechner erfolgen.

Je nach Konfiguration bleiben bestimmte Daten im lokalen Portfolio gespeichert.

TradeVision sendet Ihr Portfolio nicht automatisch an einen externen Dienst, um Käufe oder Verkäufe auszuführen.

---

# Neuberechnung und Entwicklung

Je nach Version können einige KI-Modelle regelmäßig neu berechnet oder aktualisiert werden.

Diese Neuberechnungen können neue Marktdaten, aktuelle Historien, neue Portfoliopositionen und statistische Daten verwenden.

Die Ergebnisse können sich daher im Laufe der Zeit ändern.

---

# Grenzen der KI

KI-Werkzeuge können die Zukunft nicht sicher vorhersagen, keine Performance garantieren, keinen Fachmann ersetzen, nicht jedes Marktereignis vorhersehen und Verluste nicht vermeiden.

Finanzmärkte bleiben auch mit fortgeschrittenen Werkzeugen unvorhersehbar.

---

# Warum Signale sich ändern können

Dasselbe Wertpapier kann unterschiedliche Signale erhalten, je nach Tageszeit, geöffnetem oder geschlossenem Markt, verwendeten Anbietern, neuen Daten, verfügbaren Historien und jüngsten Schwankungen.

Es ist normal, dass Analysen sich verändern.

---

# Warum TradeVision von anderen Websites abweichen kann

Zwei Plattformen können unterschiedliche Analysen erzeugen.

Gründe können verwendete Indikatoren, verfügbare Historien, Anbieter, Marktdaten, Berechnungsregeln oder Aktualisierungsverzögerungen sein.

Jedes Werkzeug hat seine eigene Analyselogik.

---

# Tipps für die richtige Nutzung der KI

Für eine sinnvollere Nutzung:

- Marktdaten immer prüfen,
- mehrere Quellen vergleichen,
- KI als Denkhilfe verwenden,
- impulsive Entscheidungen vermeiden,
- reale Märkte beobachten,
- eine konsistente Strategie behalten.

KI-Werkzeuge sind am nützlichsten, wenn sie die eigene Analyse ergänzen.

---

# Wichtiger Hinweis

Die KI-Funktionen von TradeVision dienen vor allem dem Analysieren, Vergleichen, Erkunden und Verstehen bestimmter Trends.

Sie sind keine Gewinnversprechen, keine personalisierte Finanzberatung und keine automatischen Kauf- oder Verkaufsorders.

Der Benutzer bleibt für seine Anlageentscheidungen verantwortlich.
