# Maintenance

TradeVision includes several maintenance tools designed to:

- optimize some data,
- correct certain inconsistencies,
- rebuild some information,
- repair some issues related to the portfolio or securities.

These tools are mainly available from the application settings.

---

# Before any maintenance

Before using an important maintenance tool, it is strongly recommended to:

- back up the portfolio,
- close unnecessary applications,
- make sure recent imports are finished,
- avoid interrupting the application during an important operation.

> Tip: always create a backup before major maintenance.

---

# SQLite maintenance

TradeVision uses a local database to store:

- transactions,
- securities,
- histories,
- some market data,
- portfolio settings.

Over time, some operations can make the database larger or less optimized.

SQLite maintenance can help:

- optimize some queries,
- reduce some temporary files,
- clean up internal data,
- improve some performance.

---

# When to use SQLite maintenance

SQLite maintenance can be useful:

- after a large CSV import,
- after many deletions,
- after extensive testing,
- if some screens become slower,
- after some errors or interruptions.

In most cases, you do not need to run it regularly.

---

# Rebuilding securities

TradeVision can rebuild some information linked to securities.

This operation can help correct:

- inconsistent securities,
- missing names,
- wrong metadata,
- mapping issues.

The rebuild may use:

- existing transactions,
- histories,
- local data,
- some external providers.

---

# When to rebuild securities

This operation can be useful:

- after several CSV imports,
- after symbol tests,
- after major changes,
- if some securities look incorrect,
- if some information no longer displays properly.

---

# OpenFIGI check

TradeVision can use OpenFIGI to complete or verify some security information.

This check can help find:

- ISINs,
- tickers,
- exchanges,
- metadata.

This feature is especially useful when:

- a ticker is ambiguous,
- a security is not recognized correctly,
- some data looks wrong,
- imports contain complex symbols.

---

# Repairing some data

Depending on your version, some tools can attempt to repair inconsistencies automatically.

Examples:

- incorrect symbols,
- incomplete securities,
- inconsistent histories,
- missing data,
- invalid mappings.

Some repairs may take time depending on portfolio size.

---

# Data recalculation

After some important operations, TradeVision may recalculate:

- performance,
- positions,
- charts,
- histories,
- some statistics.

These recalculations are usually automatic.

Depending on portfolio size, they may take a few moments.

---

# Problems that may require maintenance

Some situations may justify maintenance.

Examples:

- inconsistent performance,
- incorrect cash,
- incomplete charts,
- duplicate securities,
- missing data,
- major slowdowns,
- issues after CSV import.

In many cases, simply checking transactions or symbols is enough.

---

# What maintenance does not do

Maintenance tools cannot:

- automatically fix every import error,
- guarantee provider quality,
- recreate completely missing data,
- replace a backup,
- correct a bad history supplied by an external source.

Some errors require manual checking.

---

# Backups before maintenance

Before any important operation:

- create a backup,
- check the file being used,
- keep a recent copy of the portfolio.

A backup lets you go back if an unexpected result appears after maintenance.

---

# Maintenance and performance

Maintenance can sometimes improve:

- loading time,
- some calculations,
- charts,
- searches,
- some portfolio operations.

However, speed also depends on:

- database size,
- stored histories,
- providers used,
- your computer performance.

---

# After maintenance

After some maintenance operations:

- give TradeVision a moment to recalculate data,
- check important positions,
- check cash,
- check main charts,
- check recent imports.

It is normal for some screens to take a little time to stabilize after a large recalculation.

---

# Tips to limit problems

To keep a clean database:

- avoid duplicate imports,
- check symbols before import,
- use regular backups,
- import large histories progressively,
- avoid unnecessary massive edits,
- keep data consistent.

A clean database greatly reduces future error risks.

---

# Important note

Maintenance tools are mainly used to:

- optimize,
- rebuild,
- verify,
- repair some data.

They should be used carefully, especially after large imports or major changes.

Before any sensitive operation:

- create a backup,
- check your data,
- verify results after maintenance.
