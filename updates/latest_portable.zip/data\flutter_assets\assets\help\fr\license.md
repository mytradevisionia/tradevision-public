# Licence et édition Pro

TradeVision existe en plusieurs configurations selon votre licence et les fonctions activées.

Cette section explique :

- les différences entre le mode Démo et l’édition Pro,
- l’activation d’une licence,
- l’expiration,
- les limitations possibles,
- l’utilisation sur plusieurs machines.

---

# Mode Démo

TradeVision peut fonctionner sans licence Pro.

Le mode Démo permet généralement :

- d’utiliser les principaux écrans,
- de suivre un portefeuille,
- d’ajouter des opérations,
- d’utiliser certaines fonctions de base,
- d’importer certaines données,
- de tester l’application.

Le mode Démo permet de découvrir l’application avant d’activer une licence complète.

---

# Édition Pro

L’édition Pro débloque certaines fonctions avancées selon votre configuration.

Exemples :

- outils IA avancés,
- analyses supplémentaires,
- providers avancés,
- exports supplémentaires,
- certaines fonctions de maintenance,
- certaines options de personnalisation.

Les fonctions exactes peuvent évoluer selon les versions de TradeVision.

---

# Activation d’une licence

La licence peut généralement être activée depuis les paramètres de l’application.

Selon votre version, l’activation peut nécessiter :

- une clé de licence,
- certaines informations de validation,
- une vérification locale ou distante.

Après activation, certaines fonctions supplémentaires deviennent disponibles.

---

# Clé de licence

La clé de licence sert à identifier votre édition de TradeVision.

Selon votre offre, elle peut inclure :

- une durée de validité,
- certaines fonctions spécifiques,
- certaines limitations,
- certaines options avancées.

> Important : conservez toujours une copie de votre clé de licence.

---

# Expiration d’une licence

Certaines licences peuvent avoir une durée limitée.

Lorsque la licence expire :

- certaines fonctions Pro peuvent être désactivées,
- certaines options avancées peuvent devenir indisponibles,
- le portefeuille et les données restent généralement accessibles.

Vos données locales ne sont pas supprimées automatiquement.

---

# Renouvellement

Selon votre offre, la licence peut être renouvelée ou remplacée.

Avant un renouvellement :

- conservez une sauvegarde du portefeuille,
- vérifiez les informations de licence,
- conservez votre clé actuelle.

Dans la majorité des cas, le renouvellement n’affecte pas vos données locales.

---

# Données et licence

La licence n’est pas votre portefeuille.

Votre portefeuille reste enregistré localement dans vos fichiers.

Même sans licence active :

- vos opérations restent présentes,
- vos historiques restent disponibles,
- vos sauvegardes restent utilisables,
- vos fichiers de portefeuille restent accessibles.

> Important : faites régulièrement des sauvegardes indépendamment de la licence.

---

# Utilisation sur plusieurs machines

Selon votre offre, il peut être possible d’utiliser TradeVision sur plusieurs machines.

Cependant :

- certaines licences peuvent avoir des limitations,
- certaines activations peuvent être liées à une machine,
- certaines vérifications peuvent être nécessaires.

Si vous changez de machine :

- sauvegardez votre portefeuille,
- conservez votre clé,
- vérifiez les informations de licence disponibles.

---

# Sauvegardes recommandées

Avant certaines opérations importantes :

- changement de machine,
- réinstallation,
- mise à jour importante,
- maintenance,
- renouvellement de licence,

il est fortement recommandé de :

- créer un backup,
- conserver une copie externe du portefeuille,
- vérifier les fichiers importants.

---

# Mise à jour de l’application

Selon votre version, TradeVision peut proposer certaines mises à jour.

Certaines mises à jour peuvent :

- corriger des bugs,
- améliorer les performances,
- ajouter des fonctions,
- améliorer les providers,
- améliorer certains outils IA.

Avant une mise à jour importante, faites toujours une sauvegarde du portefeuille.

---

# Limitations possibles

Selon la version utilisée, certaines limitations peuvent exister.

Exemples :

- certaines fonctions IA limitées,
- providers restreints,
- exports limités,
- certaines options avancées indisponibles.

Ces limitations dépendent principalement de l’édition utilisée.

---

# Sécurité et confidentialité

TradeVision privilégie un fonctionnement local.

Dans la majorité des cas :

- les portefeuilles restent stockés sur votre machine,
- les opérations restent locales,
- les sauvegardes restent sous votre contrôle.

Cependant, certaines fonctions utilisant des providers externes peuvent nécessiter des échanges de données limités avec des services tiers.

---

# En cas de problème de licence

Si une licence semble incorrecte :

- vérifiez la clé saisie,
- vérifiez les espaces ou caractères supplémentaires,
- redémarrez l’application,
- contrôlez la version utilisée,
- vérifiez les informations fournies lors de l’activation.

Dans certains cas, une nouvelle activation peut être nécessaire.

---

# Conseils importants

Pour éviter les problèmes :

- conservez une copie de votre clé,
- faites des sauvegardes régulières,
- gardez une copie du portefeuille,
- vérifiez les mises à jour importantes,
- évitez les modifications non vérifiées des fichiers de licence.

Une bonne gestion des sauvegardes reste la meilleure protection contre les problèmes techniques.

---

# Important à savoir

La licence contrôle principalement l’accès à certaines fonctions avancées.

Elle ne remplace pas :

- les sauvegardes,
- la vérification des données,
- le contrôle des imports,
- les bonnes pratiques de gestion du portefeuille.

L’utilisateur reste responsable de ses données locales et de ses sauvegardes.
