# Import / Export

TradeVision kann verschiedene portfoliobezogene Daten importieren und exportieren.

Dieser Abschnitt erklärt vor allem:

- CSV-Importe,
- Symbole und Handelsplätze,
- mehrdeutige Ticker,
- Sicherungen,
- Exporte,
- die häufigsten Probleme.

---

# CSV-Importe verstehen

Mit dem CSV-Import können Sie schnell hinzufügen:

- Transaktionen,
- Historien,
- Wertpapierlisten,
- bestimmte Portfoliodaten.

Das ist oft der schnellste Weg, um eine Historie von einem Broker oder einem älteren Werkzeug zu übernehmen.

---

# Vor dem Import einer CSV-Datei

Vor einem größeren Import wird dringend empfohlen:

- eine Sicherung zu erstellen,
- das Dateiformat zu prüfen,
- einige Testzeilen zu importieren,
- die verwendeten Symbole zu kontrollieren,
- Duplikate zu vermeiden.

> Tipp: Beginnen Sie immer mit einer kleinen Datei, bevor Sie eine vollständige Historie importieren.

---

# Arten importierter Daten

Je nach den in Ihrer Version verfügbaren Werkzeugen kann TradeVision importieren:

- Käufe,
- Verkäufe,
- Dividenden,
- Gebühren,
- Steuern,
- Einzahlungen,
- Auszahlungen,
- interne Überträge,
- Kurshistorien.

---

# Symbole und Ticker

Wertpapiere werden in der Regel über einen Ticker identifiziert.

Beispiele:

- AI,
- MC,
- TTE,
- ASML,
- VWCE.

Derselbe Ticker kann jedoch auf mehreren Märkten existieren.

Beispiel:

- SAN kann auf mehreren Handelsplätzen existieren.

In diesem Fall kann es notwendig sein, Folgendes anzugeben:

- das Ticker-Suffix,
- den Handelsplatz,
- den MIC-Code,
- die ISIN.

---

# Marktsuffixe

Einige Provider verwenden Suffixe, um Handelsplätze zu unterscheiden.

Beispiele:

- `.PA` für Paris,
- `.AS` für Amsterdam,
- `.DE` für Deutschland,
- `.L` für London.

Je nach verwendetem Provider können diese Suffixe wichtig sein, um Kurse korrekt abzurufen.

---

# MIC-Codes

Der MIC-Code identifiziert einen Handelsplatz.

Beispiele:

- XPAR: Euronext Paris,
- XAMS: Amsterdam,
- XETR: Xetra,
- XLON: London.

MIC-Codes helfen, bestimmte Mehrdeutigkeiten beim Import zu vermeiden.

---

# ISIN

Die ISIN ist eine eindeutige internationale Kennung.

Beispiel:

- FR0000121014,
- IE00B4L5Y983.

Die ISIN ist oft zuverlässiger als ein einfacher Ticker.

Sie kann nützlich sein, wenn:

- mehrere Wertpapiere denselben Ticker verwenden,
- ein ETF auf mehreren Märkten existiert,
- bestimmte Daten mehrdeutig sind.

---

# Mehrdeutige Ticker

Wenn ein Ticker zu mehreren möglichen Wertpapieren passt, kann TradeVision eine Warnung anzeigen.

Beispiele:

- derselbe Ticker auf mehreren Märkten,
- mehrere Währungen,
- mehrere Listings desselben ETF.

In diesem Fall kann es notwendig sein:

- das richtige Wertpapier manuell auszuwählen,
- den Handelsplatz anzugeben,
- ein Suffix hinzuzufügen,
- eine ISIN zu verwenden.

---

# Unbekannte Wertpapiere

Ein Wertpapier kann als unbekannt gelten, wenn:

- der Ticker falsch ist,
- der Handelsplatz nicht erkannt wird,
- der Provider dieses Wertpapier nicht kennt,
- die CSV-Datei einen Fehler enthält,
- der ETF nur schwach abgedeckt ist.

In manchen Fällen kann TradeVision Werkzeuge zur Identifizierung anbieten.

---

# Daten nach dem Import prüfen

Nach einem Import sollten Sie immer prüfen:

- Mengen,
- Preise,
- Gebühren,
- Cash,
- verwendete Konten,
- erkannte Symbole.

Ein fehlerhafter Import kann verursachen:

- unstimmige Performance,
- negatives Cash,
- falsche Positionen,
- Duplikate.

---

# Import-Duplikate

Duplikate gehören zu den häufigsten Problemen.

Sie entstehen oft, wenn:

- dieselbe Datei mehrfach importiert wird,
- mehrere Exporte sich überschneiden,
- bestimmte Transaktionen bereits existieren.

Duplikate können verfälschen:

- die Performance,
- die Mengen,
- das Cash,
- die Diagramme.

> Tipp: Prüfen Sie nach einem wichtigen Import immer Ihre letzten Transaktionen.

---

# Schrittweise Importe

Bei großen Historien ist es besser:

- schrittweise zu importieren,
- die Ergebnisse in Etappen zu kontrollieren,
- die Symbole vor dem Fortfahren zu prüfen.

Diese Methode erleichtert das Korrigieren von Fehlern.

---

# Kurshistorie

TradeVision kann auch Importe von Kurshistorien verwenden.

Diese Historien dienen insbesondere dazu:

- Diagramme anzuzeigen,
- bestimmte Performancewerte zu rekonstruieren,
- bestimmte KI-Werkzeuge zu versorgen.

Je nach Konfiguration können einige Daten stammen aus:

- ABCBourse,
- Providern,
- älteren lokalen Historien,
- manuellen Importen.

---

# ABCBourse-Import

TradeVision kann bestimmte Historien von ABCBourse importieren.

Diese Importe sind besonders nützlich, um:

- tägliche Historien zu ergänzen,
- bestimmte europäische ETFs abzudecken,
- fehlende Daten zu ergänzen.

Beim Export aus ABCBourse wird im Allgemeinen empfohlen:

- ISINs zu verwenden,
- Handelsplätze hinzuzufügen,
- die verwendeten Formate zu prüfen.

---

# PDF-Export

Je nach Version kann TradeVision bestimmte PDF-Exporte erzeugen.

Diese Exporte können enthalten:

- Positionen,
- Performance,
- Transaktionen,
- bestimmte Diagramme.

PDF-Exporte dienen hauptsächlich der Nachverfolgung und Archivierung.

---

# Sicherungen und Backups

TradeVision kann lokale Sicherungen des Portfolios erstellen.

Eine Sicherung ermöglicht insbesondere:

- nach einem Fehler zurückzugehen,
- Daten abzusichern,
- einen früheren Portfoliozustand wiederherzustellen.

Erstellen Sie vor einem großen Import oder einer Wartung immer ein Backup.

---

# Portfolio wiederherstellen

Eine Wiederherstellung ersetzt das aktuelle Portfolio durch eine frühere Sicherung.

Vor einer Wiederherstellung:

- prüfen Sie die richtige Datei,
- erstellen Sie ein Backup des aktuellen Portfolios,
- kontrollieren Sie das Datum der Sicherung.

Eine Wiederherstellung kann neuere Daten überschreiben.

---

# Häufige Probleme nach dem Import

Die häufigsten Probleme sind:

- nicht erkannte Symbole,
- unstimmiges Cash,
- Duplikate,
- falsche Konten,
- Währungsfehler,
- falsche Handelsplätze,
- mehrdeutige Wertpapiere.

In den meisten Fällen liegt das Problem an:

- der CSV-Datei,
- dem verwendeten Symbol,
- dem Handelsplatz,
- einem doppelten Import.

---

# Tipps für erfolgreiche Importe

Um Fehler zu begrenzen:

- verwenden Sie genaue Symbole,
- fügen Sie Suffixe hinzu, wenn nötig,
- verwenden Sie ISINs, wenn möglich,
- prüfen Sie Handelsplätze,
- erstellen Sie regelmäßige Sicherungen,
- importieren Sie große Historien schrittweise.

Eine kurze Prüfung nach jedem Import vermeidet später viele Probleme.

---

# Wichtig zu wissen

TradeVision versucht, importierte Daten automatisch zu normalisieren.

Dennoch:

- können manche Ticker mehrdeutig bleiben,
- können manche Handelsplätze falsch erkannt werden,
- können manche Provider unterschiedliche Formate verwenden.

Importe müssen nach der Verarbeitung immer geprüft werden.
