# Portfolio und Transaktionen

Dieser Bereich erklärt, wie TradeVision Transaktionen, Konten und Portfolioverfolgung verwaltet.

Transaktionen bilden die Grundlage der Anwendung. Sie dienen zur automatischen Neuberechnung von:

- gehaltenen Positionen,
- verfügbarem Barbestand,
- Performance,
- Gewinnen und Verlusten,
- Einstandspreis,
- Diagrammen und Statistiken.

---

# Portfolio verstehen

Ein Portfolio enthält:

- gehaltene Wertpapiere,
- Konten,
- Barbestand,
- Transaktionen,
- Kurshistorien.

TradeVision kann mehrere Kontotypen verwalten, darunter:

- PEA,
- Wertpapierdepot,
- weitere benutzerdefinierte Konten je nach Konfiguration.

Jede Transaktion wird im lokalen Portfolio gespeichert.

---

# Wichtige Transaktionstypen

TradeVision unterstützt mehrere Transaktionstypen.

## Kauf

Ein Kauf erhöht:

- die gehaltene Menge,
- den investierten Betrag,
- gegebenenfalls verbundene Gebühren.

Käufe werden genutzt, um Einstandspreis, offene Positionen und Performance neu zu berechnen.

---

## Verkauf

Ein Verkauf reduziert oder schließt eine Position.

TradeVision kann automatisch berechnen:

- realisierten Gewinn oder Verlust,
- verbleibende Mengen,
- Performance-Statistiken.

Je nach Konfiguration können unterschiedliche Berechnungsmethoden verwendet werden.

---

## Dividende

Dividenden erfassen Erträge aus einem Wertpapier.

Je nach Eingabe können sie Barbestand erhöhen, einem Konto zugeordnet und in die Gesamtperformance einbezogen werden.

---

## Gebühren und Steuern

Gebühren dienen zur Verfolgung von Brokergebühren, bestimmten Steuern und transaktionsbezogenen Kosten.

Sie wirken sich direkt auf Barbestand, Performance und Renditeberechnungen aus.

> Tipp: korrekt eingetragene Gebühren verbessern die Genauigkeit der Ergebnisse.

---

## Einzahlung

Eine Einzahlung fügt dem Portfolio Barbestand hinzu.

Beispiele:

- Einzahlung auf einen PEA,
- Einzahlung in ein Wertpapierdepot,
- manuelle Liquiditätsbuchung.

Einzahlungen sind wichtig für Performance, Renditen und Wertdiagramme.

---

## Auszahlung

Eine Auszahlung reduziert das verfügbare Barbestand.

Beispiele:

- Bankauszahlung,
- Liquiditätsübertrag,
- Geldabfluss aus dem Portfolio.

---

## Interne Umbuchung

Interne Umbuchungen verschieben Barbestand zwischen Konten.

Beispiele:

- Umbuchung zwischen Wertpapierdepot und PEA,
- Verschiebung zwischen Teilportfolios.

Diese Vorgänge verhindern eine Verzerrung der Gesamtperformance.

---

# Barbestand verstehen

Barbestand ist nicht investiertes verfügbares Geld.

Es verändert sich durch Käufe, Verkäufe, Dividenden, Gebühren, Einzahlungen, Auszahlungen und interne Umbuchungen.

Negatives Barbestand kann hinweisen auf:

- eine vergessene Einzahlung,
- nicht erfasste Gebühren,
- eine falsche Transaktion,
- einen unvollständigen Import.

---

# PEA und Wertpapierdepots

TradeVision kann verschiedene Kontotypen verwalten.

## PEA

Ein PEA wird häufig für europäische Aktien, bestimmte geeignete ETFs und eine spezifische steuerliche Nachverfolgung genutzt.

Je nach Datenlage können manche Ansichten die PEA-Eignung anzeigen.

---

## Wertpapierdepot

Ein Wertpapierdepot ist flexibler und kann internationale Aktien, nicht PEA-fähige ETFs und Produkte auf mehreren Märkten enthalten.

TradeVision kann mehrere Konten getrennt verfolgen.

---

# Einstandspreis und Performance

TradeVision berechnet mehrere Kennzahlen aus den Transaktionen:

- Einstandspreis je Einheit,
- Gewinn oder Verlust,
- investierter Wert,
- Gesamtrendite,
- jährliche Performance.

Diese Berechnungen hängen direkt von der Qualität der erfassten Transaktionen ab.

> Wichtig: Wenn Ergebnisse unstimmig wirken, prüfen Sie zuerst Transaktionen und Barbestand.

---

# Wertpapiere und Symbole

Ein Wertpapier kann über mehrere Angaben identifiziert werden:

- Ticker,
- ISIN,
- Handelsplatz,
- Währung.

Manche Symbole sind mehrdeutig, wenn sie auf mehreren Märkten existieren.

Beispiel: derselbe Ticker kann in Paris, Amsterdam oder Frankfurt vorkommen.

Dann kann es nötig sein, Handelsplatz, MIC-Code oder Ticker-Suffix anzugeben.

Weitere Informationen:

- [Kurse und Marktdaten](pricing.md)
- [Import / Export](csv.md)

---

# Transaktion ändern oder korrigieren

Transaktionen können in der Transaktionsansicht korrigiert werden.

Nach einer größeren Änderung können Positionen, Performance, Barbestand und Diagramme automatisch neu berechnet werden.

Wenn Daten nach einem großen Import weiterhin falsch wirken, können Wartungswerkzeuge helfen.

---

# Tipps zur Fehlervermeidung

Für ein stimmiges Portfolio:

- Symbole vor dem Speichern prüfen,
- Gebühren korrekt erfassen,
- echte Einzahlungen eintragen,
- doppelte Importe vermeiden,
- regelmäßig Sicherungen erstellen,
- große Historien schrittweise importieren.

Ein kleiner Buchungsfehler kann die berechnete Performance stark beeinflussen.

---

# Wichtiger Hinweis

TradeVision basiert vor allem auf den gespeicherten Transaktionen.

Sind importierte Daten unvollständig oder falsch, können Barbestand, Positionen und Performance verfälscht werden.

Vor größeren Änderungen:

- Sicherung erstellen,
- Importe prüfen,
- Symbole und Konten kontrollieren.
