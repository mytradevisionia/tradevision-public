# Prices and market data

TradeVision uses several data sources to retrieve prices for ETFs, shares and other financial instruments.

This section explains:

- how prices are retrieved,
- why prices can vary,
- what spot prices and official closes mean,
- why differences can exist with your broker,
- how market updates work.

---

# Understanding prices in TradeVision

TradeVision can display several kinds of market data.

Depending on the screen and available sources, the application may use:

- spot prices,
- delayed prices,
- official closes,
- daily history,
- OHLC data.

Displayed prices can change while the market is open.

---

# Market open and market closed

Financial markets do not all use the same trading hours.

Examples:

- Euronext Paris,
- Xetra,
- Nasdaq,
- NYSE,
- London,
- Switzerland,
- Toronto.

While the market is open:

- prices may change continuously,
- some data is updated automatically,
- variations can move quickly.

After the market closes:

- prices become more stable,
- official closes can be checked,
- some data may be corrected or consolidated.

---

# Spot prices

A spot price usually means the latest known market price.

It may be:

- near real time,
- slightly delayed depending on the source,
- frequently updated during the session.

Spot prices are useful for quickly following portfolio changes.

However, depending on the providers used:

- the delay may vary,
- some ETFs may be less well covered,
- some exchanges may have limitations.

---

# Official close

The official close is the price validated at the end of the market session.

This value may differ from:

- the latest spot price,
- the price shown a few minutes before the close,
- the price shown by another platform.

TradeVision can automatically check some closing prices after market close to reduce incorrect or inconsistent prices.

> Important: it is normal for some prices to move slightly after the close before the data fully stabilizes.

---

# OHLC data

OHLC means:

- Open,
- High,
- Low,
- Close.

This data is used to:

- display charts,
- calculate technical indicators,
- rebuild daily histories,
- verify some closing prices.

OHLC data is often used for performance analysis and historical charts.

---

# Price updates

TradeVision can update prices:

- when the application starts,
- automatically during use,
- manually from the settings,
- after some imports or maintenance operations.

Depending on your configuration:

- some data may be updated more often,
- some sources may have priority,
- some APIs may be used before others.

---

# Why some prices may be missing

A price may be missing for several reasons.

Examples:

- the ticker is not recognized,
- the symbol is ambiguous,
- the exchange is wrong,
- the provider does not cover this market,
- the market is closed,
- the data is not available yet,
- the ETF is poorly covered by free sources.

In that case, check:

- the ticker,
- any suffix,
- the exchange,
- the MIC code,
- the enabled providers.

---

# Differences with your broker

It is normal for TradeVision to sometimes show values slightly different from your broker.

Differences may come from:

- the provider used,
- data delay,
- update times,
- currencies,
- conversions,
- closing prices used,
- rounding,
- available histories.

Two different platforms can show slightly different prices at the same moment.

> Important: market data always depends on the data suppliers used.

---

# Free providers and APIs

TradeVision can work with several kinds of sources:

- free providers,
- external APIs,
- manual imports,
- imported histories.

Some free sources may have:

- delays,
- limits,
- temporary outages,
- incomplete coverage for some ETFs or markets.

Pro APIs can improve:

- stability,
- availability,
- market coverage,
- accuracy of some data.

For more information:

- [Providers and APIs](providers.md)

---

# Price history

TradeVision can keep local price histories.

These histories are used to:

- display charts,
- recalculate some performance values,
- track daily changes,
- feed some AI tools.

Depending on your setup, histories may come from:

- providers,
- manual imports,
- ABCBourse,
- older data already stored in the database.

---

# Charts and indicators

Charts may use:

- daily histories,
- OHLC data,
- recent prices,
- calculated averages.

Depending on the screen and enabled options, TradeVision can display:

- moving averages,
- Bollinger Bands,
- RSI,
- portfolio changes,
- daily variations.

Some data may take a little time to appear after a large import or first synchronization.

---

# Tips to avoid price issues

To improve data quality:

- check symbols and exchanges,
- use precise tickers,
- add suffixes when needed,
- use providers adapted to your markets,
- import progressively,
- avoid duplicate data.

After a large import or maintenance operation, give TradeVision a moment to recalculate some information.

---

# Important note

Market data shown by TradeVision depends on the sources used.

The application:

- does not create market prices itself,
- depends on configured providers,
- may show data slightly different from other platforms,
- may be limited by some free sources.

Data should be used for tracking and analysis, not as guaranteed real-time trading data.
