# Lizenz und Pro-Edition

TradeVision existiert je nach Lizenz und aktivierten Funktionen in mehreren Konfigurationen.

Dieser Abschnitt erklärt:

- die Unterschiede zwischen Demo-Modus und Pro-Edition,
- die Aktivierung einer Lizenz,
- den Ablauf,
- mögliche Einschränkungen,
- die Nutzung auf mehreren Rechnern.

---

# Demo-Modus

TradeVision kann ohne Pro-Lizenz funktionieren.

Der Demo-Modus erlaubt in der Regel:

- die wichtigsten Bildschirme zu nutzen,
- ein Portfolio zu verfolgen,
- Transaktionen hinzuzufügen,
- einige Grundfunktionen zu verwenden,
- bestimmte Daten zu importieren,
- die Anwendung zu testen.

Der Demo-Modus ermöglicht es, die Anwendung kennenzulernen, bevor eine vollständige Lizenz aktiviert wird.

---

# Pro-Edition

Die Pro-Edition schaltet je nach Konfiguration bestimmte erweiterte Funktionen frei.

Beispiele:

- erweiterte KI-Werkzeuge,
- zusätzliche Analysen,
- erweiterte Provider,
- zusätzliche Exporte,
- bestimmte Wartungsfunktionen,
- bestimmte Anpassungsoptionen.

Die genauen Funktionen können sich je nach TradeVision-Version ändern.

---

# Lizenz aktivieren

Die Lizenz kann in der Regel über die Einstellungen der Anwendung aktiviert werden.

Je nach Version kann die Aktivierung erfordern:

- einen Lizenzschlüssel,
- bestimmte Validierungsinformationen,
- eine lokale oder entfernte Prüfung.

Nach der Aktivierung werden zusätzliche Funktionen verfügbar.

---

# Lizenzschlüssel

Der Lizenzschlüssel dient dazu, Ihre TradeVision-Edition zu identifizieren.

Je nach Angebot kann er enthalten:

- eine Gültigkeitsdauer,
- bestimmte Funktionen,
- bestimmte Einschränkungen,
- erweiterte Optionen.

> Wichtig: Bewahren Sie immer eine Kopie Ihres Lizenzschlüssels auf.

---

# Ablauf einer Lizenz

Einige Lizenzen können zeitlich begrenzt sein.

Wenn die Lizenz abläuft:

- können einige Pro-Funktionen deaktiviert werden,
- können bestimmte erweiterte Optionen nicht mehr verfügbar sein,
- bleiben Portfolio und Daten in der Regel zugänglich.

Ihre lokalen Daten werden nicht automatisch gelöscht.

---

# Verlängerung

Je nach Angebot kann die Lizenz verlängert oder ersetzt werden.

Vor einer Verlängerung:

- bewahren Sie eine Sicherung des Portfolios auf,
- prüfen Sie die Lizenzinformationen,
- behalten Sie Ihren aktuellen Schlüssel.

In den meisten Fällen wirkt sich die Verlängerung nicht auf Ihre lokalen Daten aus.

---

# Daten und Lizenz

Die Lizenz ist nicht Ihr Portfolio.

Ihr Portfolio bleibt lokal in Ihren Dateien gespeichert.

Auch ohne aktive Lizenz:

- bleiben Ihre Transaktionen vorhanden,
- bleiben Ihre Historien verfügbar,
- bleiben Ihre Sicherungen nutzbar,
- bleiben Ihre Portfolio-Dateien zugänglich.

> Wichtig: Erstellen Sie regelmäßig Sicherungen, unabhängig von der Lizenz.

---

# Nutzung auf mehreren Rechnern

Je nach Angebot kann es möglich sein, TradeVision auf mehreren Rechnern zu verwenden.

Allerdings:

- können manche Lizenzen Einschränkungen haben,
- können manche Aktivierungen an einen Rechner gebunden sein,
- können bestimmte Prüfungen erforderlich sein.

Wenn Sie den Rechner wechseln:

- sichern Sie Ihr Portfolio,
- bewahren Sie Ihren Schlüssel auf,
- prüfen Sie die verfügbaren Lizenzinformationen.

---

# Empfohlene Sicherungen

Vor bestimmten wichtigen Vorgängen:

- Rechnerwechsel,
- Neuinstallation,
- wichtige Aktualisierung,
- Wartung,
- Lizenzverlängerung,

wird dringend empfohlen:

- ein Backup zu erstellen,
- eine externe Kopie des Portfolios aufzubewahren,
- wichtige Dateien zu prüfen.

---

# Anwendung aktualisieren

Je nach Version kann TradeVision bestimmte Updates anbieten.

Einige Updates können:

- Fehler beheben,
- die Performance verbessern,
- Funktionen hinzufügen,
- Provider verbessern,
- bestimmte KI-Werkzeuge verbessern.

Erstellen Sie vor einem wichtigen Update immer eine Sicherung des Portfolios.

---

# Mögliche Einschränkungen

Je nach verwendeter Version können bestimmte Einschränkungen bestehen.

Beispiele:

- eingeschränkte KI-Funktionen,
- beschränkte Provider,
- begrenzte Exporte,
- bestimmte erweiterte Optionen nicht verfügbar.

Diese Einschränkungen hängen hauptsächlich von der verwendeten Edition ab.

---

# Sicherheit und Datenschutz

TradeVision ist auf lokalen Betrieb ausgelegt.

In den meisten Fällen:

- bleiben Portfolios auf Ihrem Rechner gespeichert,
- bleiben Transaktionen lokal,
- bleiben Sicherungen unter Ihrer Kontrolle.

Einige Funktionen, die externe Provider verwenden, können jedoch begrenzte Datenaustausche mit Drittanbietern erfordern.

---

# Bei Lizenzproblemen

Wenn eine Lizenz fehlerhaft erscheint:

- prüfen Sie den eingegebenen Schlüssel,
- prüfen Sie zusätzliche Leerzeichen oder Zeichen,
- starten Sie die Anwendung neu,
- prüfen Sie die verwendete Version,
- prüfen Sie die bei der Aktivierung angegebenen Informationen.

In manchen Fällen kann eine neue Aktivierung erforderlich sein.

---

# Wichtige Tipps

Um Probleme zu vermeiden:

- bewahren Sie eine Kopie Ihres Schlüssels auf,
- erstellen Sie regelmäßige Sicherungen,
- behalten Sie eine Kopie des Portfolios,
- prüfen Sie wichtige Updates,
- vermeiden Sie ungeprüfte Änderungen an Lizenzdateien.

Eine gute Sicherungsstrategie bleibt der beste Schutz vor technischen Problemen.

---

# Wichtig zu wissen

Die Lizenz steuert hauptsächlich den Zugriff auf bestimmte erweiterte Funktionen.

Sie ersetzt nicht:

- Sicherungen,
- die Prüfung der Daten,
- die Kontrolle von Importen,
- gute Praktiken bei der Portfolioverwaltung.

Der Nutzer bleibt für seine lokalen Daten und Sicherungen verantwortlich.
