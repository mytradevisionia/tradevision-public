# Häufige Fragen

Dieser Bereich sammelt die häufigsten Fragen und Probleme in TradeVision IA Pro.

## Fragen

- [Warum haben manche Wertpapiere keinen Kurs?](#fehlende-kurse)
- [Warum unterscheiden sich meine Werte vom Broker?](#broker-abweichung)
- [Warum ist mein Barbestand unstimmig?](#unstimmiges-Barbestand)
- [Warum wirkt meine Performance falsch?](#falsche-performance)
- [Warum wird ein ETF oder eine Aktie als „unbekannt“ angezeigt?](#unbekanntes-wertpapier)
- [Warum sind manche Ticker mehrdeutig?](#mehrdeutige-ticker)
- [Warum sind Diagramme unvollständig?](#unvollstaendige-diagramme)
- [Warum funktionieren einige KI-Funktionen nicht?](#begrenzte-ki)
- [Ist ein API-Schlüssel Pflicht?](#api-schluessel-pflicht)
- [Sind APIs kostenlos?](#kostenlose-apis)
- [Warum ändern sich Kurse nach Marktschluss?](#kurse-nach-schluss)
- [Arbeitet TradeVision in Echtzeit?](#echtzeit)
- [Warum erzeugen CSV-Importe Duplikate?](#csv-duplikate)
- [Warum funktionieren manche europäischen ETFs besser mit ABCBourse?](#abcbourse)
- [Warum kann Wartung nützlich sein?](#wartung)
- [Sollte ich regelmäßig Sicherungen erstellen?](#sicherungen)
- [Werden meine Daten an einen externen Server gesendet?](#externe-daten)
- [Erteilt die KI automatisch Orders?](#ki-orders)
- [Kann ich mehrere Portfolios verwenden?](#mehrere-portfolios)
- [Was tun vor einer großen Änderung?](#grosse-aenderung)

---

# fehlende-kurse

## Warum haben manche Wertpapiere keinen Kurs?

Mögliche Ursachen sind ein falscher Ticker, ein fehlender Handelsplatz, fehlende Anbieterabdeckung, ein mehrdeutiges Wertpapier, ein geschlossener Markt oder noch nicht verfügbare Daten.

Prüfen Sie Ticker, Suffix, MIC-Code und konfigurierte Anbieter.

Siehe auch:

- [Kurse und Marktdaten](pricing.md)
- [Anbieter und APIs](providers.md)

[Zurück zu den Fragen](#fragen)

---

# broker-abweichung

## Warum unterscheiden sich meine Werte vom Broker?

Kleine Abweichungen sind normal.

Sie können durch Anbieter, Datenverzögerung, Währungen, Rundungen, verwendete Schlusskurse oder Aktualisierungszeiten entstehen.

Zwei Plattformen können gleichzeitig leicht unterschiedliche Werte anzeigen.

[Zurück zu den Fragen](#fragen)

---

# unstimmiges-Barbestand

## Warum ist mein Barbestand unstimmig?

Meist liegt es an einer vergessenen Einzahlung, fehlenden Auszahlung, nicht erfassten Gebühren, einem doppelten Import oder einer falschen Transaktion.

Prüfen Sie Einzahlungen, Auszahlungen, Gebühren, interne Umbuchungen und zuletzt importierte Transaktionen.

[Zurück zu den Fragen](#fragen)

---

# falsche-performance

## Warum wirkt meine Performance falsch?

Die Performance hängt direkt von gespeicherten Transaktionen ab.

Unstimmige Ergebnisse können durch unvollständige Importe, Duplikate, falsches Barbestand, fehlende Gebühren, falsch erkannte Wertpapiere oder falsche Daten entstehen.

Prüfen Sie zuerst die Transaktionen, bevor Sie Wartung starten.

[Zurück zu den Fragen](#fragen)

---

# unbekanntes-wertpapier

## Warum wird ein ETF oder eine Aktie als „unbekannt“ angezeigt?

Das kann passieren, wenn der Ticker nicht erkannt wird, das Symbol mehrdeutig ist, der Handelsplatz falsch ist, die ISIN fehlt oder der Anbieter das Wertpapier nicht abdeckt.

Geben Sie möglichst Suffix, MIC-Code, ISIN und Handelsplatz an.

[Zurück zu den Fragen](#fragen)

---

# mehrdeutige-ticker

## Warum sind manche Ticker mehrdeutig?

Derselbe Ticker kann auf mehreren Märkten oder in mehreren Währungen existieren; ein ETF kann ebenfalls mehrere Listings haben.

Verwenden Sie Suffix, MIC-Code oder ISIN, um Verwechslungen zu vermeiden.

[Zurück zu den Fragen](#fragen)

---

# unvollstaendige-diagramme

## Warum sind Diagramme unvollständig?

Das kann nach einem großen Import, bei der ersten Synchronisierung, bei fehlenden Historien oder noch nicht geladenen Daten passieren.

Einige Historien brauchen etwas Zeit, bis sie stabil angezeigt werden.

[Zurück zu den Fragen](#fragen)

---

# begrenzte-ki

## Warum funktionieren einige KI-Funktionen nicht?

Einige erweiterte Funktionen benötigen ausreichende Historien, kompatible Marktdaten und manchmal eine konfigurierte API.

Ohne genügend Daten können Analysen eingeschränkt sein.

Siehe:

- [TradeVision KI](ai.md)
- [Anbieter und APIs](providers.md)

[Zurück zu den Fragen](#fragen)

---

# api-schluessel-pflicht

## Ist ein API-Schlüssel Pflicht?

Nein. TradeVision kann ohne API-Schlüssel funktionieren.

Einige erweiterte Pro-Funktionen können jedoch eine kompatible API, vollständigere Historien oder fortgeschrittene Anbieter benötigen.

Empfohlener Anbieter: EODHD.

Kompatible Anbieter je nach Konfiguration: EODHD, Leeway, Finnhub und FMP.

[Zurück zu den Fragen](#fragen)

---

# kostenlose-apis

## Sind APIs kostenlos?

Das hängt vom Anbieter ab.

Einige APIs sind kostenlos mit Limits, andere teilweise kostenlos, andere kostenpflichtig.

Kostenlose Tarife erlauben oft das Testen der Anwendung und den Abruf eines begrenzten Datenvolumens.

[Zurück zu den Fragen](#fragen)

---

# kurse-nach-schluss

## Warum ändern sich Kurse nach Marktschluss?

Nach Marktschluss können Daten korrigiert, Schlusskurse konsolidiert oder Historien bei Anbietern aktualisiert werden.

Es ist normal, dass einige Werte vor vollständiger Stabilisierung leicht schwanken.

[Zurück zu den Fragen](#fragen)

---

# echtzeit

## Arbeitet TradeVision in Echtzeit?

TradeVision ist keine Hochfrequenz-Handelsplattform.

Je nach Anbieter können einige Daten nahezu in Echtzeit, andere verzögert und manche Schlusskurse erst nach Marktschluss validiert werden.

[Zurück zu den Fragen](#fragen)

---

# csv-duplikate

## Warum erzeugen CSV-Importe Duplikate?

Das passiert oft, wenn dieselbe Datei mehrfach importiert wird, Exporte sich überschneiden oder einige Transaktionen bereits vorhanden sind.

Duplikate können Performance, Barbestand, Mengen und Diagramme verfälschen.

Erstellen Sie vor großen Importen immer eine Sicherung.

[Zurück zu den Fragen](#fragen)

---

# abcbourse

## Warum funktionieren manche europäischen ETFs besser mit ABCBourse?

ABCBourse kann für bestimmte europäische ETFs, Tageshistorien und Euronext-Märkte nützlich sein.

Je nach Anbieter können manche Daten dort vollständiger sein.

[Zurück zu den Fragen](#fragen)

---

# wartung

## Warum kann Wartung nützlich sein?

Wartung kann Daten optimieren, Wertpapiere neu aufbauen, Unstimmigkeiten korrigieren und die Leistung verbessern.

Sie ist hilfreich nach großen CSV-Importen, wichtigen Änderungen oder Datenproblemen.

[Zurück zu den Fragen](#fragen)

---

# sicherungen

## Sollte ich regelmäßig Sicherungen erstellen?

Ja, unbedingt.

Sicherungen werden empfohlen vor Importen, Wartungen, Wiederherstellungen und wichtigen Updates.

Eine Sicherung ermöglicht die Rückkehr bei Problemen.

[Zurück zu den Fragen](#fragen)

---

# externe-daten

## Werden meine Daten an einen externen Server gesendet?

TradeVision bevorzugt lokalen Betrieb.

In den meisten Fällen bleiben Portfolios, Transaktionen und Sicherungen unter Ihrer Kontrolle.

Einige Funktionen mit externen Anbietern können begrenzte Datenübertragungen an Drittanbieter erfordern.

[Zurück zu den Fragen](#fragen)

---

# ki-orders

## Erteilt die KI automatisch Orders?

Nein.

TradeVision erteilt keine Orders, verbindet sich nicht automatisch mit Ihrem Broker zum Handeln und garantiert keine Gewinne.

KI-Werkzeuge dienen nur der Analyse.

[Zurück zu den Fragen](#fragen)

---

# mehrere-portfolios

## Kann ich mehrere Portfolios verwenden?

Ja.

TradeVision kann verschiedene Portfoliodateien öffnen.

Sie können PEA und Wertpapierdepot trennen, Testportfolios erstellen oder unabhängige Sicherungen behalten.

[Zurück zu den Fragen](#fragen)

---

# grosse-aenderung

## Was tun vor einer großen Änderung?

Vor einem wichtigen Vorgang:

- Sicherung erstellen,
- Importe prüfen,
- Symbole kontrollieren,
- Barbestand prüfen,
- Kopie des aktuellen Portfolios behalten.

Eine gute Sicherung ist der beste Schutz vor Fehlern.

[Zurück zu den Fragen](#fragen)
