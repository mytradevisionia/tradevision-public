# TradeVision AI

TradeVision IA Pro includes several analysis assistance tools based on market indicators, price histories and contextual data.

The purpose of these tools is to:

- help analyze a portfolio,
- detect some trends,
- compare securities,
- suggest diversification ideas,
- improve the overall reading of the market.

AI features must be seen as decision-support tools, never as guaranteed investment advice.

---

# What the AI does

Depending on your version and available data, AI tools can:

- analyze some technical indicators,
- track market variations,
- detect trends,
- produce scores,
- suggest diversification ideas,
- analyze some news,
- compare shares or ETFs.

These tools mainly use:

- price histories,
- market data,
- information available in your portfolio,
- configured providers.

---

# Technical signals

TradeVision can calculate several technical signals.

Examples:

- RSI,
- moving averages,
- volatility,
- momentum,
- Bollinger Bands,
- trend changes.

These signals are used to make information easier to read.

---

# AI recommendations

Depending on available data, TradeVision can generate simplified recommendations.

Examples:

- Buy,
- Hold,
- Sell,
- Neutral.

These indications are usually shown with:

- a score,
- a confidence level,
- some context information.

> Important: an AI recommendation is never a guarantee of performance.

---

# AI score

The AI score is an estimate calculated from several available data points.

Depending on your configuration, it may include:

- trends,
- histories,
- variations,
- technical indicators,
- market data,
- news.

The score mainly helps compare several securities with each other.

---

# Confidence level

Some screens may show a confidence level linked to a signal or score.

This confidence may vary depending on:

- available data quality,
- market stability,
- available history,
- recent variations,
- context data.

A high score with low confidence should be interpreted carefully.

---

# Diversification

TradeVision can suggest diversification ideas.

Suggestions may include:

- ETFs,
- sectors,
- geographical areas,
- market themes,
- securities related to your portfolio.

The goal is mainly to help explore other allocation possibilities.

---

# News scoring

Some AI features can analyze news available through certain providers.

Depending on available data, TradeVision may try to detect:

- trends,
- important events,
- high-activity periods,
- positive or negative tone.

This data is mainly used to complement some analysis.

---

# AI and portfolio

Some AI analysis can use data directly from your portfolio.

Examples:

- holdings,
- sectors,
- performance,
- weights,
- local history.

This allows TradeVision to provide analysis better adapted to your situation.

---

# Data used

AI features strongly depend on available data.

Results may vary depending on:

- providers used,
- available histories,
- import quality,
- covered markets,
- available ETFs,
- missing data.

Incomplete data can limit some analysis.

---

# Local AI

A significant part of processing can be done locally on your machine.

Depending on your configuration, some data remains stored in your local portfolio.

TradeVision does not automatically send your portfolio to an external service to buy or sell.

---

# Retraining and evolution

Depending on your version, some AI models can be recalculated or updated periodically.

These recalculations may use:

- new market data,
- recent histories,
- new portfolio positions,
- some statistical data.

Results can therefore change over time.

---

# AI limitations

AI tools have important limits.

They cannot:

- predict the future with certainty,
- guarantee performance,
- replace a professional,
- anticipate every market event,
- prevent losses.

Financial markets remain unpredictable, even with advanced tools.

---

# Why signals can change

The same security can receive different signals depending on:

- time of day,
- whether markets are open or closed,
- providers used,
- new data received,
- available histories,
- recent variations.

It is normal for some analysis to change over time.

---

# Why TradeVision can differ from another website

Two platforms can produce different analysis.

Differences may come from:

- indicators used,
- available histories,
- providers,
- market data,
- calculation rules,
- update delays.

Each tool has its own analysis logic.

---

# Tips for using AI properly

To use AI tools more effectively:

- always check market data,
- compare several sources,
- use AI as a thinking aid,
- avoid impulsive decisions,
- monitor real markets,
- keep a coherent strategy.

AI tools are most useful when they complement your own analysis.

---

# Important note

TradeVision AI features are mainly used to:

- analyze,
- compare,
- explore,
- help understand trends.

They should never be considered:

- guaranteed profit signals,
- personalized financial advice,
- automatic buy or sell orders.

The user remains fully responsible for investment decisions.
