# Cartera y operaciones

Esta sección explica cómo TradeVision gestiona las operaciones, las cuentas y el seguimiento de la cartera.

Las operaciones son la base de la aplicación. Permiten recalcular automáticamente:

- posiciones mantenidas,
- efectivo disponible,
- rentabilidad,
- plusvalías y minusvalías,
- precio medio o coste de adquisición,
- gráficos y estadísticas.

---

# Comprender la cartera

Una cartera agrupa:

- los títulos que posee,
- las cuentas,
- el efectivo,
- las operaciones,
- los historiales de precios.

TradeVision puede gestionar varios tipos de cuenta, entre ellos:

- PEA,
- cuenta de valores,
- otras cuentas personalizadas según su configuración.

Cada operación queda guardada en su cartera local.

---

# Principales tipos de operación

TradeVision admite varios tipos de operación.

## Compra

Una compra aumenta:

- la cantidad mantenida,
- el importe invertido,
- las comisiones asociadas si existen.

Las compras sirven para recalcular el coste unitario, las posiciones abiertas y la rentabilidad.

---

## Venta

Una venta reduce o cierra una posición.

TradeVision puede recalcular automáticamente:

- la plusvalía o minusvalía realizada,
- las cantidades restantes,
- las estadísticas de rentabilidad.

Según la configuración, pueden utilizarse distintos métodos de cálculo para las ventas.

---

## Dividendo

Los dividendos añaden un ingreso vinculado a un título.

Según cómo se introduzcan, pueden aumentar el efectivo, asociarse a una cuenta concreta e integrarse en la rentabilidad global.

---

## Comisiones e impuestos

Las comisiones permiten seguir:

- gastos de corretaje,
- ciertos impuestos,
- costes vinculados a operaciones.

Afectan directamente al efectivo, a la rentabilidad y a los cálculos de retorno.

> Consejo: introducir correctamente las comisiones mejora la precisión de los resultados.

---

## Ingreso

Un ingreso añade efectivo a la cartera.

Ejemplos:

- aportación a un PEA,
- depósito en una cuenta de valores,
- alta manual de liquidez.

Los ingresos son importantes para seguir correctamente la rentabilidad y los gráficos de valor.

---

## Retirada

Una retirada reduce el efectivo disponible.

Ejemplos:

- retirada bancaria,
- transferencia de liquidez,
- salida de dinero de la cartera.

---

## Transferencia interna

Las transferencias internas desplazan efectivo entre cuentas.

Ejemplos:

- transferencia entre cuenta de valores y PEA,
- movimiento entre subcarteras.

Estas operaciones evitan falsear la rentabilidad global.

---

# Comprender el efectivo

El efectivo representa el dinero disponible no invertido.

Puede variar por compras, ventas, dividendos, comisiones, ingresos, retiradas y transferencias internas.

Un efectivo negativo puede indicar:

- un ingreso olvidado,
- comisiones no registradas,
- una operación incorrecta,
- una importación incompleta.

---

# PEA y cuentas de valores

TradeVision puede gestionar distintos tipos de cuenta.

## PEA

El PEA se usa normalmente para acciones europeas, ciertos ETF elegibles y un seguimiento fiscal específico.

Según los datos disponibles, algunas pantallas pueden mostrar la elegibilidad PEA de los títulos.

---

## Cuenta de valores

La cuenta de valores es más flexible y puede contener acciones internacionales, ETF no elegibles para PEA y productos cotizados en varios mercados.

TradeVision permite seguir varias cuentas por separado si es necesario.

---

# Coste de adquisición y rentabilidad

TradeVision recalcula varios indicadores a partir de las operaciones:

- precio de adquisición unitario,
- plusvalía o minusvalía,
- valor invertido,
- rentabilidad global,
- rentabilidad anual.

Estos cálculos dependen directamente de la calidad de las operaciones registradas.

> Importante: si los resultados parecen incoherentes, revise primero las operaciones y el efectivo.

---

# Títulos y símbolos

Cada título puede identificarse mediante:

- ticker,
- ISIN,
- plaza de cotización,
- divisa.

Algunos símbolos son ambiguos cuando existen en varios mercados.

Ejemplo: un mismo ticker puede existir en París, Ámsterdam o Fráncfort.

En ese caso puede ser necesario indicar la plaza, el código MIC o el sufijo del ticker.

Para más información:

- [Cotizaciones y mercado](pricing.md)
- [Importación / Exportación](csv.md)

---

# Modificar o corregir una operación

Las operaciones pueden corregirse desde la pantalla de Operaciones.

Después de una modificación importante, las posiciones, la rentabilidad, el efectivo y los gráficos pueden recalcularse automáticamente.

Si algunos datos siguen siendo incorrectos tras una gran importación, puede ser útil usar las herramientas de mantenimiento.

---

# Consejos para evitar errores

Para conservar una cartera coherente:

- compruebe los símbolos antes de validar,
- registre correctamente las comisiones,
- añada los ingresos reales de efectivo,
- evite importaciones duplicadas,
- haga copias de seguridad periódicas,
- importe los grandes historiales progresivamente.

Un pequeño error de operación puede tener un impacto importante en la rentabilidad calculada.

---

# Nota importante

TradeVision depende principalmente de las operaciones guardadas en la cartera.

Si los datos importados son incompletos o incorrectos, el efectivo, las posiciones y la rentabilidad pueden quedar falseados.

Antes de cambios importantes:

- haga una copia de seguridad,
- revise las importaciones,
- controle los símbolos y las cuentas usadas.
