# License and Pro edition

TradeVision exists in several configurations depending on your license and the features enabled.

This section explains:

- the differences between Demo mode and the Pro edition,
- license activation,
- expiry,
- possible limitations,
- use on several machines.

---

# Demo mode

TradeVision can run without a Pro license.

Demo mode generally lets you:

- use the main screens,
- track a portfolio,
- add transactions,
- use certain basic features,
- import certain data,
- test the application.

Demo mode lets you discover the application before activating a full license.

---

# Pro edition

The Pro edition unlocks certain advanced features depending on your configuration.

Examples:

- advanced AI tools,
- additional analyses,
- advanced providers,
- extra exports,
- certain maintenance features,
- certain customization options.

The exact features may change between TradeVision versions.

---

# License activation

The license can generally be activated from the application settings.

Depending on your version, activation may require:

- a license key,
- certain validation information,
- a local or remote check.

After activation, additional features become available.

---

# License key

The license key identifies your TradeVision edition.

Depending on your plan, it may include:

- a validity period,
- specific features,
- certain limitations,
- advanced options.

> Important: always keep a copy of your license key.

---

# License expiry

Some licenses may be time-limited.

When the license expires:

- some Pro features may be disabled,
- some advanced options may become unavailable,
- the portfolio and data generally remain accessible.

Your local data is not automatically deleted.

---

# Renewal

Depending on your plan, the license may be renewed or replaced.

Before renewal:

- keep a portfolio backup,
- check the license information,
- keep your current key.

In most cases, renewal does not affect your local data.

---

# Data and license

The license is not your portfolio.

Your portfolio remains stored locally in your files.

Even without an active license:

- your transactions remain present,
- your histories remain available,
- your backups remain usable,
- your portfolio files remain accessible.

> Important: make regular backups independently of the license.

---

# Use on several machines

Depending on your plan, it may be possible to use TradeVision on several machines.

However:

- some licenses may have limitations,
- some activations may be tied to one machine,
- some checks may be required.

If you change machine:

- back up your portfolio,
- keep your key,
- check the available license information.

---

# Recommended backups

Before certain important operations:

- changing machine,
- reinstalling,
- major update,
- maintenance,
- license renewal,

it is strongly recommended to:

- create a backup,
- keep an external copy of the portfolio,
- check important files.

---

# Application update

Depending on your version, TradeVision may offer certain updates.

Some updates may:

- fix bugs,
- improve performance,
- add features,
- improve providers,
- improve certain AI tools.

Before a major update, always back up the portfolio.

---

# Possible limitations

Depending on the version used, certain limitations may exist.

Examples:

- limited AI features,
- restricted providers,
- limited exports,
- some advanced options unavailable.

These limitations mainly depend on the edition used.

---

# Security and privacy

TradeVision is designed to work locally.

In most cases:

- portfolios remain stored on your machine,
- transactions remain local,
- backups remain under your control.

However, some features using external providers may require limited data exchanges with third-party services.

---

# In case of a license issue

If a license seems incorrect:

- check the key entered,
- check for extra spaces or characters,
- restart the application,
- check the version used,
- check the information provided during activation.

In some cases, a new activation may be required.

---

# Important tips

To avoid problems:

- keep a copy of your key,
- make regular backups,
- keep a copy of the portfolio,
- check important updates,
- avoid unverified changes to license files.

Good backup management remains the best protection against technical issues.

---

# Important to know

The license mainly controls access to certain advanced features.

It does not replace:

- backups,
- data checking,
- import control,
- good portfolio management practices.

The user remains responsible for local data and backups.
