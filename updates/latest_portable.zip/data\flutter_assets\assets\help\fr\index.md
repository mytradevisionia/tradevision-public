# TradeVision IA Pro — Aide

Bienvenue dans l’aide de TradeVision IA Pro.

TradeVision est une application locale de suivi de portefeuille et d’analyse de marché orientée ETF, actions, PEA et CTO.

L’application permet de :

- suivre vos investissements,
- analyser les performances de votre portefeuille,
- gérer vos opérations,
- importer des données de marché,
- utiliser des outils d’aide à l’analyse basés sur l’IA,
- sauvegarder et restaurer vos portefeuilles localement.

Toutes les données restent enregistrées sur votre machine.  
TradeVision ne transmet pas automatiquement votre portefeuille à un serveur externe.

---

# Premiers pas

Découvrez les bases de l’application :

- créer un portefeuille,
- ajouter une première opération,
- ajouter du cash,
- comprendre les principaux écrans,
- effectuer une première sauvegarde.

[Voir la section Premiers pas](getting_started.md)

---

# Portefeuille et opérations

Cette section explique :

- les achats et ventes,
- les comptes PEA et CTO,
- les dividendes,
- les frais et taxes,
- les virements internes,
- la gestion du cash.

[Voir la section Portefeuille et opérations](portfolio.md)

---

# Cours et marché

TradeVision peut utiliser plusieurs sources de données pour récupérer les cours de marché.

Cette section explique :

- les différentes sources de prix,
- les marchés ouverts et fermés,
- les cours spot,
- les clôtures officielles,
- les données OHLC,
- les mises à jour automatiques des prix.

[Voir la section Cours et marché](pricing.md)

---

# Providers et APIs

TradeVision peut fonctionner avec des providers gratuits ou avec des APIs externes optionnelles.

Cette section couvre :

- Google Finance,
- Yahoo Finance,
- les APIs Pro,
- la configuration des clés API,
- ABCBourse,
- les limites des providers gratuits.

[Voir la section Providers et APIs](providers.md)

---

# Import / Export

TradeVision permet d’importer et d’exporter plusieurs types de données.

Cette section explique :

- l’import CSV,
- les tickers ambigus,
- les codes MIC et ISIN,
- les exports PDF,
- les sauvegardes,
- la restauration d’un portefeuille.

[Voir la section Import / Export](csv.md)

---

# IA TradeVision

TradeVision IA Pro inclut plusieurs outils d’aide à l’analyse.

Cette section présente :

- les conseils IA,
- les scores IA,
- les suggestions de diversification,
- le news scoring,
- les limites des outils IA.

[Voir la section IA TradeVision](ai.md)

---

# Maintenance

Des outils de maintenance sont disponibles pour optimiser ou réparer certaines données.

Cette section explique :

- la maintenance SQLite,
- la reconstruction des titres,
- la vérification OpenFIGI,
- les outils de réparation de base.

[Voir la section Maintenance](maintenance.md)

---

# Licence et édition Pro

TradeVision existe en mode Démo et en édition Pro.

Cette section explique :

- les différences entre les éditions,
- l’activation de la licence,
- l’expiration d’une licence,
- l’utilisation sur plusieurs machines.

[Voir la section Licence et édition Pro](license.md)

---

# FAQ

Retrouvez ici les réponses aux questions fréquentes et aux problèmes les plus courants.

[Voir la FAQ](faq.md)
