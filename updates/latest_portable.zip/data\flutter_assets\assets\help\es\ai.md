# IA TradeVision

TradeVision AI Pro incluye varias herramientas de ayuda al análisis basadas en indicadores de mercado, historiales de precios y datos de contexto.

El objetivo de estas herramientas es:

- ayudar a analizar una cartera,
- detectar algunas tendencias,
- comparar títulos,
- proponer ideas de diversificación,
- mejorar la lectura global del mercado.

Las funciones de IA deben verse como herramientas de ayuda a la decisión, nunca como consejos de inversión garantizados.

---

# Qué hace la IA

Según la versión y los datos disponibles, las herramientas de IA pueden analizar indicadores técnicos, seguir variaciones de mercado, detectar tendencias, producir puntuaciones, proponer ideas de diversificación, analizar algunas noticias y comparar acciones o ETF.

Estas herramientas usan principalmente historiales de precios, datos de mercado, información disponible en la cartera y proveedores configurados.

---

# Señales técnicas

TradeVision puede calcular varias señales técnicas:

- RSI,
- medias móviles,
- volatilidad,
- momentum,
- bandas de Bollinger,
- cambios de tendencia.

Estas señales sirven para presentar la información de forma más legible.

---

# Consejos IA

Según los datos disponibles, TradeVision puede generar indicaciones simplificadas:

- comprar,
- conservar,
- vender,
- neutral.

Normalmente se muestran con una puntuación, un nivel de confianza y datos de contexto.

> Importante: una indicación de IA nunca garantiza rentabilidad.

---

# Puntuación IA

La puntuación IA es una estimación calculada a partir de varios datos disponibles.

Puede tener en cuenta tendencias, historiales, variaciones, indicadores técnicos, datos de mercado y noticias.

Sirve sobre todo para comparar varios títulos entre sí.

---

# Nivel de confianza

Algunas pantallas pueden mostrar un nivel de confianza asociado a una señal o puntuación.

Esta confianza puede variar según la calidad de los datos, la estabilidad del mercado, los historiales disponibles, las variaciones recientes y el contexto.

Una puntuación alta con baja confianza debe interpretarse con prudencia.

---

# Diversificación

TradeVision puede proponer ideas de diversificación.

Pueden incluir ETF, sectores, zonas geográficas, temas de mercado o títulos relacionados con la cartera.

El objetivo es ayudar a explorar otras posibilidades de reparto.

---

# Análisis de noticias

Algunas funciones de IA pueden analizar noticias disponibles mediante ciertos proveedores.

Según los datos, TradeVision puede intentar detectar tendencias, eventos importantes, periodos de actividad elevada o tonalidades positivas y negativas.

Estos datos complementan algunos análisis.

---

# IA y cartera

Algunos análisis pueden usar datos directamente procedentes de la cartera:

- títulos mantenidos,
- sectores,
- rentabilidad,
- ponderaciones,
- historial local.

Esto permite ofrecer análisis más adaptados a la situación del usuario.

---

# Datos utilizados

Las funciones de IA dependen mucho de los datos disponibles.

Los resultados pueden variar según proveedores, historiales presentes, calidad de importaciones, mercados cubiertos, ETF disponibles y datos faltantes.

Datos incompletos pueden limitar algunos análisis.

---

# IA local

Una parte importante del procesamiento puede realizarse localmente en su equipo.

Según la configuración, ciertos datos permanecen guardados en la cartera local.

TradeVision no transmite automáticamente la cartera a un servicio externo para comprar o vender.

---

# Reentrenamiento y evolución

Según la versión, algunos modelos de IA pueden recalcularse o actualizarse periódicamente.

Estos recálculos pueden usar nuevos datos de mercado, historiales recientes, nuevas posiciones de cartera y datos estadísticos.

Por eso los resultados pueden evolucionar con el tiempo.

---

# Límites de la IA

Las herramientas de IA no pueden predecir el futuro con certeza, garantizar rentabilidad, sustituir a un profesional, anticipar todos los eventos de mercado ni evitar pérdidas.

Los mercados financieros siguen siendo imprevisibles, incluso con herramientas avanzadas.

---

# Por qué pueden cambiar las señales

Un mismo título puede recibir señales distintas según la hora, si el mercado está abierto o cerrado, los proveedores usados, los nuevos datos recibidos, los historiales disponibles y las variaciones recientes.

Es normal que algunos análisis evolucionen.

---

# Por qué TradeVision puede diferir de otro sitio

Dos plataformas pueden producir análisis distintos por los indicadores utilizados, los historiales disponibles, los proveedores, los datos de mercado, las reglas de cálculo o los retrasos de actualización.

Cada herramienta tiene su propia lógica de análisis.

---

# Consejos para usar correctamente la IA

Para usar mejor estas herramientas:

- revise siempre los datos de mercado,
- compare varias fuentes,
- use la IA como apoyo a la reflexión,
- evite decisiones impulsivas,
- vigile los mercados reales,
- mantenga una estrategia coherente.

La IA es más útil cuando completa su propio análisis.

---

# Nota importante

Las funciones de IA de TradeVision sirven principalmente para analizar, comparar, explorar y ayudar a comprender tendencias.

No deben considerarse garantías de ganancia, asesoramiento financiero personalizado ni órdenes automáticas de compra o venta.

El usuario sigue siendo responsable de sus decisiones de inversión.
