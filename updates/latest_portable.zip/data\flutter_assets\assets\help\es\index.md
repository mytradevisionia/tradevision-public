# TradeVision AI Pro — Ayuda

Bienvenido a la ayuda de TradeVision AI Pro.

TradeVision es una aplicación local de seguimiento de cartera y análisis de mercado orientada a ETF, acciones, PEA y cuentas de valores.

La aplicación permite:

- seguir tus inversiones,
- analizar el rendimiento de tu cartera,
- gestionar tus operaciones,
- importar datos de mercado,
- utilizar herramientas de apoyo al análisis basadas en IA,
- guardar y restaurar tus carteras localmente.

Todos los datos permanecen guardados en tu equipo.  
TradeVision no envía automáticamente tu cartera a un servidor externo.

---

# Primeros pasos

Descubre las bases de la aplicación:

- crear una cartera,
- añadir una primera operación,
- añadir efectivo,
- entender las pantallas principales,
- hacer una primera copia de seguridad.

[Ver la sección Primeros pasos](getting_started.md)

---

# Cartera y operaciones

Esta sección explica:

- las compras y ventas,
- las cuentas PEA y cuentas de valores,
- los dividendos,
- las comisiones e impuestos,
- las transferencias internas,
- la gestión del efectivo.

[Ver la sección Cartera y operaciones](portfolio.md)

---

# Cotizaciones y mercado

TradeVision puede utilizar varias fuentes de datos para recuperar cotizaciones de mercado.

Esta sección explica:

- las distintas fuentes de precios,
- los mercados abiertos y cerrados,
- las cotizaciones spot,
- los cierres oficiales,
- los datos OHLC,
- las actualizaciones automáticas de precios.

[Ver la sección Cotizaciones y mercado](pricing.md)

---

# Providers y APIs

TradeVision puede funcionar con providers gratuitos o con APIs externas opcionales.

Esta sección cubre:

- Google Finance,
- Yahoo Finance,
- las APIs Pro,
- la configuración de claves API,
- ABCBourse,
- los límites de los providers gratuitos.

[Ver la sección Providers y APIs](providers.md)

---

# Importación / Exportación

TradeVision permite importar y exportar varios tipos de datos.

Esta sección explica:

- la importación CSV,
- los tickers ambiguos,
- los códigos MIC e ISIN,
- las exportaciones PDF,
- las copias de seguridad,
- la restauración de una cartera.

[Ver la sección Importación / Exportación](csv.md)

---

# IA TradeVision

TradeVision AI Pro incluye varias herramientas de apoyo al análisis.

Esta sección presenta:

- los consejos IA,
- las puntuaciones IA,
- las sugerencias de diversificación,
- el news scoring,
- los límites de las herramientas IA.

[Ver la sección IA TradeVision](ai.md)

---

# Mantenimiento

Hay herramientas de mantenimiento disponibles para optimizar o reparar algunos datos.

Esta sección explica:

- el mantenimiento SQLite,
- la reconstrucción de valores,
- la verificación OpenFIGI,
- las herramientas de reparación de la base.

[Ver la sección Mantenimiento](maintenance.md)

---

# Licencia y edición Pro

TradeVision existe en modo Demo y en edición Pro.

Esta sección explica:

- las diferencias entre ediciones,
- la activación de la licencia,
- la caducidad de una licencia,
- el uso en varios equipos.

[Ver la sección Licencia y edición Pro](license.md)

---

# FAQ

Encuentra aquí las respuestas a las preguntas frecuentes y a los problemas más comunes.

[Ver la FAQ](faq.md)
