# Import / Export

TradeVision can import and export different types of portfolio-related data.

This section mainly explains:

- CSV imports,
- symbols and listing venues,
- ambiguous tickers,
- backups,
- exports,
- the most common issues.

---

# Understanding CSV imports

CSV import lets you quickly add:

- transactions,
- histories,
- lists of securities,
- certain portfolio data.

It is often the fastest way to recover a history from a broker or an older tool.

---

# Before importing a CSV

Before a major import, it is strongly recommended to:

- make a backup,
- check the file format,
- import a few test lines,
- check the symbols used,
- avoid duplicates.

> Tip: always start with a small file before importing a complete history.

---

# Types of imported data

Depending on the tools available in your version, TradeVision can import:

- buys,
- sells,
- dividends,
- fees,
- taxes,
- contributions,
- withdrawals,
- internal transfers,
- price histories.

---

# Symbols and tickers

Securities are generally identified by a ticker.

Examples:

- AI,
- MC,
- TTE,
- ASML,
- VWCE.

However, the same ticker may exist on several markets.

Example:

- SAN may exist on several listing venues.

In that case, you may need to specify:

- the ticker suffix,
- the venue,
- the MIC code,
- the ISIN.

---

# Market suffixes

Some providers use suffixes to distinguish listing venues.

Examples:

- `.PA` for Paris,
- `.AS` for Amsterdam,
- `.DE` for Germany,
- `.L` for London.

Depending on the provider used, these suffixes may be important to retrieve prices correctly.

---

# MIC codes

The MIC code identifies a market venue.

Examples:

- XPAR: Euronext Paris,
- XAMS: Amsterdam,
- XETR: Xetra,
- XLON: London.

MIC codes help avoid certain ambiguities during imports.

---

# ISIN

The ISIN is a unique international identifier.

Example:

- FR0000121014,
- IE00B4L5Y983.

The ISIN is often more reliable than a simple ticker.

It can be useful when:

- several securities use the same ticker,
- an ETF exists on several markets,
- some data is ambiguous.

---

# Ambiguous tickers

When a ticker matches several possible securities, TradeVision may display a warning.

Examples:

- same ticker on several markets,
- several currencies,
- several listings of the same ETF.

In that case, you may need to:

- manually choose the right security,
- specify the venue,
- add a suffix,
- use an ISIN.

---

# Unknown securities

A security may be considered unknown if:

- the ticker is incorrect,
- the venue is not recognized,
- the provider does not know this security,
- the CSV file contains an error,
- the ETF has limited coverage.

In some cases, TradeVision may offer tools to help identify it.

---

# Check data after import

After an import, always check:

- quantities,
- prices,
- fees,
- cash,
- accounts used,
- recognized symbols.

An incorrect import may cause:

- inconsistent performance,
- negative cash,
- incorrect positions,
- duplicates.

---

# Import duplicates

Duplicates are one of the most common problems.

They often appear when:

- the same file is imported several times,
- several exports overlap,
- some transactions already exist.

Duplicates can distort:

- performance,
- quantities,
- cash,
- charts.

> Tip: always check your latest transactions after a major import.

---

# Gradual imports

For large histories, it is better to:

- import gradually,
- check results step by step,
- verify symbols before continuing.

This method makes errors easier to correct.

---

# Price history

TradeVision can also use price history imports.

These histories are used in particular to:

- display charts,
- rebuild certain performance calculations,
- feed certain AI tools.

Depending on your configuration, some data may come from:

- ABCBourse,
- providers,
- older local histories,
- manual imports.

---

# ABCBourse import

TradeVision can import certain histories from ABCBourse.

These imports are especially useful to:

- complete daily histories,
- cover certain European ETFs,
- fill in missing data.

When exporting from ABCBourse, it is generally recommended to:

- use ISINs,
- add market venues,
- check the formats used.

---

# PDF export

Depending on your version, TradeVision can generate certain PDF exports.

These exports may contain:

- positions,
- performance,
- transactions,
- certain charts.

PDF exports are mainly used for tracking and archiving.

---

# Backups and backup copies

TradeVision can create local portfolio backups.

A backup lets you:

- roll back after an error,
- secure your data,
- restore an older portfolio state.

Before a large import or maintenance task, always make a backup.

---

# Restore a portfolio

Restoring replaces the current portfolio with a previous backup.

Before restoring:

- check that you have the right file,
- back up the current portfolio,
- check the backup date.

A restore may overwrite recent data.

---

# Frequent problems after import

The most common problems are:

- unrecognized symbols,
- inconsistent cash,
- duplicates,
- wrong accounts,
- currency errors,
- incorrect venues,
- ambiguous securities.

In most cases, the issue comes from:

- the CSV file,
- the symbol used,
- the listing venue,
- a duplicated import.

---

# Tips for successful imports

To reduce errors:

- use precise symbols,
- add suffixes when needed,
- use ISINs where possible,
- check listing venues,
- make regular backups,
- import large histories gradually.

A small check after each import prevents many problems later.

---

# Important to know

TradeVision tries to normalize imported data automatically.

However:

- some tickers may remain ambiguous,
- some venues may be detected incorrectly,
- some providers may use different formats.

Imports must always be checked after processing.
