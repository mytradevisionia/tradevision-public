# TradeVision AI Pro — Hilfe

Willkommen in der Hilfe von TradeVision AI Pro.

TradeVision ist eine lokale Anwendung zur Portfolioverfolgung und Marktanalyse für ETFs, Aktien, PEA-Konten und Wertpapierdepots.

Mit der Anwendung können Sie:

- Ihre Investitionen verfolgen,
- die Performance Ihres Portfolios analysieren,
- Ihre Transaktionen verwalten,
- Marktdaten importieren,
- KI-gestützte Analysewerkzeuge nutzen,
- Ihre Portfolios lokal sichern und wiederherstellen.

Alle Daten bleiben auf Ihrem eigenen Rechner gespeichert.  
TradeVision überträgt Ihr Portfolio nicht automatisch an einen externen Server.

---

# Erste Schritte

Lernen Sie die Grundlagen der Anwendung kennen:

- ein Portfolio erstellen,
- eine erste Transaktion hinzufügen,
- Cash hinzufügen,
- die wichtigsten Bildschirme verstehen,
- eine erste Sicherung erstellen.

[Abschnitt Erste Schritte öffnen](getting_started.md)

---

# Portfolio und Transaktionen

Dieser Abschnitt erklärt:

- Käufe und Verkäufe,
- PEA- und Wertpapierkonten,
- Dividenden,
- Gebühren und Steuern,
- interne Überträge,
- Cash-Verwaltung.

[Abschnitt Portfolio und Transaktionen öffnen](portfolio.md)

---

# Kurse und Markt

TradeVision kann mehrere Datenquellen nutzen, um Marktkurse abzurufen.

Dieser Abschnitt erklärt:

- die verschiedenen Preisquellen,
- geöffnete und geschlossene Märkte,
- Spotkurse,
- offizielle Schlusskurse,
- OHLC-Daten,
- automatische Preisaktualisierungen.

[Abschnitt Kurse und Markt öffnen](pricing.md)

---

# Provider und APIs

TradeVision kann mit kostenlosen Providern oder optionalen externen APIs arbeiten.

Dieser Abschnitt behandelt:

- Google Finance,
- Yahoo Finance,
- Pro-APIs,
- die Einrichtung von API-Schlüsseln,
- ABCBourse,
- die Grenzen kostenloser Provider.

[Abschnitt Provider und APIs öffnen](providers.md)

---

# Import / Export

TradeVision kann verschiedene Arten von Daten importieren und exportieren.

Dieser Abschnitt erklärt:

- den CSV-Import,
- mehrdeutige Ticker,
- MIC- und ISIN-Codes,
- PDF-Exporte,
- Sicherungen,
- die Wiederherstellung eines Portfolios.

[Abschnitt Import / Export öffnen](csv.md)

---

# TradeVision KI

TradeVision AI Pro enthält mehrere Werkzeuge zur Unterstützung der Analyse.

Dieser Abschnitt stellt vor:

- KI-Hinweise,
- KI-Scores,
- Diversifizierungsvorschläge,
- News Scoring,
- die Grenzen der KI-Werkzeuge.

[Abschnitt TradeVision KI öffnen](ai.md)

---

# Wartung

Wartungswerkzeuge stehen zur Verfügung, um bestimmte Daten zu optimieren oder zu reparieren.

Dieser Abschnitt erklärt:

- SQLite-Wartung,
- Rekonstruktion von Wertpapieren,
- OpenFIGI-Prüfung,
- Werkzeuge zur Datenbankreparatur.

[Abschnitt Wartung öffnen](maintenance.md)

---

# Lizenz und Pro-Edition

TradeVision gibt es im Demo-Modus und als Pro-Edition.

Dieser Abschnitt erklärt:

- die Unterschiede zwischen den Editionen,
- die Aktivierung der Lizenz,
- den Ablauf einer Lizenz,
- die Nutzung auf mehreren Rechnern.

[Abschnitt Lizenz und Pro-Edition öffnen](license.md)

---

# FAQ

Hier finden Sie Antworten auf häufige Fragen und typische Probleme.

[FAQ öffnen](faq.md)
