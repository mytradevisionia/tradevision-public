# Provider und APIs

TradeVision nutzt mehrere externe Provider und APIs, um Daten zu den Finanzmärkten abzurufen.

Diese Provider können verwendet werden, um:

- Spotkurse abzurufen,
- offizielle Schlusskurse herunterzuladen,
- Kurshistorien zu aktualisieren,
- bestimmte OHLC-Daten abzurufen,
- bestimmte Wertpapierinformationen zu ergänzen,
- bestimmte Diagramme zu versorgen,
- bestimmte Daten für KI-Werkzeuge bereitzustellen.

Je nach Konfiguration können mehrere Provider automatisch genutzt werden.

---

# Provider verstehen

Ein Provider ist eine externe Quelle, die zum Abrufen von Finanzinformationen verwendet wird.

TradeVision kann mehrere Arten von Daten nutzen:

- Marktkurse,
- tägliche Historien,
- OHLC-Daten,
- Wertpapier-Metadaten,
- Informationen zum Handelsplatz,
- Daten, die für bestimmte KI-Analysen benötigt werden.

Je nach Märkten und Wertpapieren können manche Quellen besser geeignet sein als andere.

---

# Rolle der Provider in TradeVision

Provider spielen in mehreren Bereichen der Anwendung eine wichtige Rolle.

Sie können dienen zum:

- Herunterladen von Marktkursen,
- Abrufen offizieller Schlusskurse,
- Aktualisieren von Historien,
- Versorgen bestimmter Diagramme,
- Abrufen bestimmter OHLC-Daten,
- Ergänzen bestimmter Wertpapierinformationen,
- Versorgen bestimmter KI-Funktionen.

Ohne kompatiblen Provider können einige Daten begrenzt oder nicht verfügbar sein.

---

# Kostenlose Provider

TradeVision kann ohne Pro-Lizenz und ohne API-Schlüssel funktionieren.

In diesem Modus kann die Anwendung je nach verfügbaren Funktionen bestimmte kostenlose Quellen nutzen.

Beispiele:

- Google Finance,
- Yahoo Finance,
- manuelle Importe,
- lokale Historien, die bereits in der Datenbank vorhanden sind.

Diese Quellen ermöglichen oft:

- die wichtigsten ETFs zu verfolgen,
- einfache Kurse abzurufen,
- die Anwendung ohne komplexe Einrichtung zu nutzen.

---

# Grenzen kostenloser Provider

Kostenlose Provider können bestimmte Einschränkungen haben.

Beispiele:

- verzögerte Daten,
- unvollständige Abdeckung,
- schwach abgedeckte Märkte,
- fehlende exotische ETFs,
- temporäre Einschränkungen,
- gelegentliche Nichtverfügbarkeit,
- Änderungen am Datenformat.

Es ist normal, dass manche Wertpapiere mit bestimmten Quellen besser funktionieren als mit anderen.

---

# Externe APIs

TradeVision kann optionale externe APIs verwenden.

Diese APIs können verbessern:

- die Stabilität der Kurse,
- die Verfügbarkeit der Daten,
- die Marktabdeckung,
- die Qualität bestimmter Historien,
- bestimmte erweiterte Funktionen,
- bestimmte von der KI genutzte Daten.

APIs sind in der Regel nicht zwingend erforderlich, um die Anwendung zu nutzen.

---

# Empfohlene APIs für die Pro-Edition

Einige erweiterte Funktionen von TradeVision AI Pro benötigen kompatible Provider.

Für ein vollständigeres Erlebnis und eine bessere Datenstabilität wird die Nutzung einer dedizierten API dringend empfohlen.

Empfohlener Provider:

- EODHD

Kompatible Provider je nach Konfiguration:

- EODHD
- Leeway
- Finnhub
- FMP

Je nach verwendeten Providern können einige Daten enthalten:

- Spotkurse,
- offizielle Schlusskurse,
- tägliche Historien,
- OHLC-Daten,
- bestimmte Wertpapier-Metadaten,
- Daten, die bestimmte KI-Werkzeuge benötigen.

Einige erweiterte Funktionen der Pro-Edition können ohne kompatiblen API-Schlüssel eingeschränkt sein.

---

# API-Schlüssel

Einige APIs benötigen einen Zugriffsschlüssel.

Ein API-Schlüssel ermöglicht einem externen Dienst:

- Ihre Nutzung zu identifizieren,
- bestimmte Grenzen anzuwenden,
- bestimmte Anfragen zu autorisieren.

API-Schlüssel können in den Einstellungen von TradeVision eingetragen werden.

> Wichtig: Einige kostenlose APIs haben tägliche oder monatliche Limits.

---

# Kostenlos oder kostenpflichtig

Je nach genutzten Diensten können API-Schlüssel sein:

- kostenlos mit Limits,
- teilweise kostenlos,
- oder kostenpflichtig.

Kostenlose Versionen ermöglichen oft:

- die Anwendung zu testen,
- ein begrenztes Datenvolumen abzurufen,
- bestimmte wichtige Märkte zu nutzen.

Kostenpflichtige Angebote können verbessern:

- die Anzahl der Anfragen,
- die Stabilität,
- die Marktabdeckung,
- die verfügbaren Historien.

---

# Google Finance

Google Finance kann verwendet werden, um bestimmte einfache Kurse abzurufen.

Diese Quelle ist oft praktisch für:

- gängige ETFs,
- bestimmte internationale Aktien,
- einfache Nachverfolgungen.

Die Abdeckung hängt jedoch vom Markt und den öffentlich zugänglichen Daten ab.

---

# Yahoo Finance

Yahoo Finance wird häufig verwendet für:

- Spotkurse,
- bestimmte Historien,
- viele internationale Märkte.

Je nach Wertpapier kann Yahoo manchmal liefern:

- bessere Ergebnisse,
- andere Daten,
- eine breitere Abdeckung.

Einige Daten können jedoch je nach Zeitraum oder Markt variieren.

---

# Pro-APIs

Je nach Konfiguration kann TradeVision erweiterte APIs verwenden.

Diese APIs können verbessern:

- die Datenqualität,
- die Preisstabilität,
- bestimmte Historien,
- die Abdeckung bestimmter spezialisierter Märkte.

Je nach genutzten Diensten können manche APIs sein:

- kostenlos mit Limits,
- teilweise kostenlos,
- kostenpflichtig,
- an ein externes Abonnement gebunden.

---

# EODHD

Einige TradeVision-Konfigurationen können EODHD nutzen, um abzurufen:

- Spotkurse,
- offizielle Schlusskurse,
- Historien,
- bestimmte OHLC-Daten,
- bestimmte Marktdaten.

Je nach Märkten kann EODHD bieten:

- gute Abdeckung,
- vollständigere Historien,
- nützliche Daten für bestimmte Analysen.

Wie bei jeder externen Quelle können Daten je nach Instrument oder Zeitraum variieren.

---

# OpenFIGI

OpenFIGI wird hauptsächlich genutzt, um bestimmte Wertpapiere zu identifizieren.

Dieser Dienst kann helfen, zu finden:

- Ticker,
- ISINs,
- Handelsplätze,
- bestimmte Metadaten.

OpenFIGI ist besonders nützlich:

- bei CSV-Importen,
- für mehrdeutige Symbole,
- für bestimmte weniger bekannte ETFs oder Aktien.

---

# ABCBourse

TradeVision kann auch Importe von ABCBourse verwenden.

Diese Importe dienen hauptsächlich dazu:

- tägliche Historien abzurufen,
- bestimmte lokale Daten zu ergänzen,
- bestimmte Diagramme zu verbessern,
- bestimmte Historien zu rekonstruieren.

ABCBourse ist besonders nützlich für einige europäische Märkte und einige ETFs.

---

# Provider und KI

Einige KI-Funktionen verwenden indirekt Daten von Providern.

Beispiele:

- Kurshistorien,
- Veränderungen,
- Trends,
- Daten für bestimmte Indikatoren,
- bestimmte OHLC-Daten,
- bestimmte Marktdaten.

Wenn die Daten unvollständig sind, können einige KI-Funktionen eingeschränkt sein.

---

# Die richtigen Provider wählen

Nicht alle Nutzer haben die gleichen Bedürfnisse.

Beispiele:

- einfaches europäisches ETF-Portfolio,
- US-Aktien,
- internationale ETFs,
- spezialisierte Märkte,
- große Historien,
- hauptsächlich lokale Nutzung.

Je nach Portfolio können manche Quellen besser geeignet sein als andere.

---

# Warum mehrere Provider verwendet werden können

TradeVision kann mehrere Provider verwenden, um:

- die Verfügbarkeit zu verbessern,
- bestimmte Fehler zu begrenzen,
- ergänzende Daten abzurufen,
- bestimmte Historien zu verbessern,
- bestimmte Marktdaten zu vergleichen.

Bestimmte Daten können daher aus unterschiedlichen Quellen stammen, je nach:

- Wertpapier,
- Markt,
- Datentyp,
- Verfügbarkeit des Providers.

---

# Mögliche Probleme mit Providern

Externe Provider können gelegentlich Probleme haben.

Beispiele:

- vorübergehend falsche Daten,
- Nichtverfügbarkeit,
- Verlangsamungen,
- API-Änderungen,
- Anfragegrenzen,
- teilweise Abdeckung bestimmter ETFs.

In manchen Fällen kann ein Provider für ein Wertpapier funktionieren, für ein anderes jedoch nicht.

---

# Tipps zur Begrenzung von Problemen

Um die Datenstabilität zu verbessern:

- verwenden Sie genaue Symbole,
- fügen Sie bei Bedarf Marktsuffixe hinzu,
- prüfen Sie Handelsplätze,
- verwenden Sie APIs, die zu Ihren Märkten passen,
- vermeiden Sie unstimmige Importe,
- bewahren Sie regelmäßige Sicherungen auf.

Nach einem großen Import oder einem Providerwechsel können manche Daten einen Moment benötigen, bis sie stabil sind.

---

# Wichtig zu wissen

TradeVision ist für bestimmte Daten auf externe Dienste angewiesen.

Die Anwendung:

- kontrolliert externe Provider nicht,
- garantiert keine dauerhafte Verfügbarkeit der APIs,
- kann durch bestimmte kostenlose Dienste eingeschränkt sein,
- kann je nach verwendeten Quellen unterschiedliche Daten anzeigen.

Provider sollten als Informationsquellen verstanden werden und nicht als garantierte Echtzeit-Trading-Feeds.
