# Erste Schritte

Dieser Abschnitt hilft Ihnen, mit TradeVision IA Pro zu beginnen, ohne in technische Details einzusteigen.

Das Ziel ist einfach: ein Portfolio erstellen oder öffnen, erste Daten hinzufügen, Kurse prüfen und die Arbeit sichern.

---

# Was ist TradeVision?

TradeVision IA Pro ist eine lokale Anwendung zur Portfolioverfolgung und Marktanalyse.

Sie können damit verfolgen:

- Ihre ETFs,
- Ihre Aktien,
- Ihre PEA-Konten,
- Ihre Wertpapierdepots,
- Ihr verfügbares Cash,
- Ihre Performance,
- Ihre Kauf-, Verkaufs-, Gebühren- und Dividendenbuchungen.

TradeVision kann außerdem KI-gestützte Werkzeuge zur Analyseunterstützung anbieten.

Diese Werkzeuge helfen, Ihr Portfolio besser zu verstehen, ersetzen aber nicht Ihre eigene Einschätzung.

> Wichtig: TradeVision erteilt niemals Aufträge in Ihrem Namen.  
> Die Anwendung verbindet sich nicht mit Ihrem Broker, um automatisch zu kaufen oder zu verkaufen.

---

# Portfolio erstellen oder öffnen

In TradeVision entspricht ein Portfolio einer lokalen Datei.

Diese Datei enthält unter anderem:

- Ihre Transaktionen,
- Ihre Positionen,
- Ihr Cash,
- Ihre Kurshistorien,
- Ihre portfoliobezogenen Einstellungen.

Sie können über das Anwendungsmenü ein neues Portfolio erstellen oder ein bestehendes Portfolio öffnen.

Eine Portfolio-Datei kann wie eine normale Datei gesichert, kopiert oder wiederhergestellt werden.

> Tipp: Bewahren Sie Ihre Portfolio-Dateien in einem leicht auffindbaren Ordner auf, zum Beispiel in Ihren Dokumenten.

---

# Eine erste Transaktion hinzufügen

Fügen Sie zum Start eine einfache Transaktion hinzu.

Beispiel:

- Typ: Kauf,
- Konto: PEA oder Wertpapierdepot,
- Wertpapier: ETF oder Aktie,
- Menge: Anzahl der Anteile oder Aktien,
- Preis: Stückpreis,
- Gebühren: mögliche Brokergebühren.

Nach dem Speichern der Transaktion kann TradeVision neu berechnen:

- die gehaltene Menge,
- den Einstandspreis,
- den Wert der Position,
- den Gewinn oder Verlust,
- das Gewicht des Wertpapiers im Portfolio.

> Tipp: Beginnen Sie mit einer oder zwei einfachen Transaktionen, bevor Sie eine große CSV-Datei importieren.

---

# Cash hinzufügen

Cash entspricht dem verfügbaren Geld in Ihrem Portfolio.

Es ist wichtig, diesen Betrag korrekt zu erfassen, besonders wenn Sie Folgendes verfolgen möchten:

- den Gesamtwert des Portfolios,
- Einzahlungen,
- Auszahlungen,
- den nicht investierten Saldo,
- die Gesamtperformance.

Je nach Situation können Sie eine Einzahlung, eine Auszahlung oder einen internen Übertrag erfassen.

Wenn das Cash nicht stimmig erscheint, prüfen Sie zuerst Ihre Einzahlungen, Auszahlungen und Gebührenbuchungen.

---

# Die wichtigsten Bildschirme verstehen

TradeVision ist in mehrere Bildschirme gegliedert.

## Startseite

Die Startseite gibt einen zusammenfassenden Überblick über das Portfolio:

- Gesamtwert,
- Gewinn oder Verlust,
- Tagesentwicklung,
- wichtige Informationen,
- Zusammenfassung der Positionen.

## Transaktionen

Der Bildschirm Transaktionen dient zum Anzeigen, Hinzufügen oder Korrigieren Ihrer Bewegungen:

- Käufe,
- Verkäufe,
- Gebühren,
- Steuern,
- Dividenden,
- Einzahlungen,
- Auszahlungen,
- interne Überträge.

## Portfolio

Der Bildschirm Portfolio zeigt die gehaltenen Wertpapiere und deren Bewertung.

Sie können schnell prüfen:

- die gehaltene Menge,
- den Einstandspreis,
- den aktuellen Kurs,
- den Wert jeder Position,
- das Gewicht jedes Wertpapiers.

## Performance

Der Bildschirm Performance hilft, die Entwicklung des Portfolios im Zeitverlauf zu verfolgen.

Er kann enthalten:

- den Portfoliowert,
- Einzahlungen,
- Cash,
- Gewinne oder Verluste,
- Renditekennzahlen.

## Notizen

Der Bildschirm Notizen dient dazu, persönliche Notizen zu Ihrer Nachverfolgung zu speichern.

Je nach Version kann er auch tabellenartige Funktionen enthalten, um eigene Daten zu verfolgen.

## Einstellungen

Die Einstellungen umfassen unter anderem:

- Kursquellen,
- mögliche API-Schlüssel,
- die Lizenz,
- Wartung,
- Anzeigeoptionen,
- Sicherungswerkzeuge.

---

# Kurse prüfen

Nachdem Sie Ihre Wertpapiere hinzugefügt haben, prüfen Sie, ob die Kurse korrekt geladen werden.

Ein Kurs kann fehlen, wenn:

- der Ticker mehrdeutig ist,
- das Wertpapier noch nicht erkannt wurde,
- der Handelsplatz nicht angegeben ist,
- die Preisquelle dieses Wertpapier nicht abdeckt,
- der Markt geschlossen ist oder die Daten noch nicht verfügbar sind.

Lesen Sie in diesem Fall die Abschnitte:

- [Kurse und Markt](pricing.md)
- [Provider und APIs](providers.md)
- [Import / Export](csv.md)

---

# Portfolio sichern

Eine Sicherung ist ein wichtiger Schritt.

TradeVision kann mit lokalen Dateien arbeiten. Deshalb wird empfohlen, regelmäßig Sicherheitskopien zu erstellen.

Erstellen Sie vor einer wichtigen Aktion, etwa einem großen CSV-Import oder einer Wartung, ein Backup.

Mit einem Backup können Sie zurückgehen, wenn später ein Fehler erkannt wird.

> Tipp: Erstellen Sie immer eine Sicherung, bevor Sie eine große Datei importieren oder eine alte Datenbank wiederherstellen.

---

# Gute Praktiken für den Einstieg

Um Fehler am Anfang zu vermeiden:

- beginnen Sie mit wenigen einfachen Transaktionen,
- prüfen Sie Symbole und Handelsplätze,
- fügen Sie bei Bedarf Anfangs-Cash hinzu,
- kontrollieren Sie die geladenen Kurse,
- erstellen Sie vor großen Importen eine Sicherung,
- importieren Sie Ihre Daten schrittweise.

Es ist besser, eine kleine saubere Datenbank zu validieren, als einen großen unvollständigen Import zu korrigieren.

---

# Wichtig zu wissen

TradeVision ist ein Werkzeug zur Unterstützung von Nachverfolgung und Analyse.

Die Anwendung:

- garantiert keine zukünftige Performance,
- ersetzt keinen Finanzberater,
- erteilt keine Aufträge automatisch,
- hängt von der Qualität der von Ihnen eingegebenen Daten ab,
- kann je nach verwendeten Quellen andere Kurse anzeigen als Ihr Broker.

KI-Werkzeuge sollten als Denkhilfen verstanden werden, niemals als Kauf- oder Verkaufsanweisungen.
