# Primeros pasos

Esta sección te ayuda a empezar con TradeVision AI Pro sin entrar en detalles técnicos.

El objetivo es sencillo: crear o abrir una cartera, añadir tus primeros datos, comprobar las cotizaciones y guardar tu trabajo.

---

# ¿Qué es TradeVision?

TradeVision AI Pro es una aplicación local de seguimiento de cartera y análisis de mercado.

Permite seguir:

- tus ETF,
- tus acciones,
- tus cuentas PEA,
- tus cuentas de valores,
- tu efectivo disponible,
- tu rendimiento,
- tus operaciones de compra, venta, comisiones o dividendos.

TradeVision también puede ofrecer herramientas de apoyo al análisis basadas en IA.

Estas herramientas sirven para entender mejor tu cartera, pero no sustituyen tu propio criterio.

> Importante: TradeVision nunca envía órdenes por ti.  
> La aplicación no se conecta a tu bróker para comprar o vender automáticamente.

---

# Crear o abrir una cartera

En TradeVision, una cartera corresponde a un archivo local.

Este archivo contiene, entre otras cosas:

- tus operaciones,
- tus posiciones,
- tu efectivo,
- tus historiales de precios,
- tus ajustes vinculados a la cartera.

Puedes crear una cartera nueva o abrir una cartera existente desde el menú de la aplicación.

Un archivo de cartera se puede guardar, copiar o restaurar como cualquier archivo clásico.

> Consejo: guarda tus archivos de cartera en una carpeta fácil de encontrar, por ejemplo en Documentos.

---

# Añadir una primera operación

Para empezar, añade una operación sencilla.

Ejemplo:

- tipo: compra,
- cuenta: PEA o cuenta de valores,
- valor: ETF o acción,
- cantidad: número de participaciones o acciones,
- precio: precio unitario,
- comisiones: posibles comisiones de corretaje.

Una vez guardada la operación, TradeVision puede recalcular:

- la cantidad mantenida,
- el precio medio de coste,
- el valor de la línea,
- la plusvalía o minusvalía,
- el peso del valor en la cartera.

> Consejo: empieza con una o dos operaciones simples antes de importar un archivo CSV grande.

---

# Añadir efectivo

El efectivo representa el dinero disponible en tu cartera.

Es importante indicarlo correctamente, sobre todo si quieres seguir:

- el valor total de la cartera,
- las aportaciones,
- los retiros,
- el saldo no invertido,
- el rendimiento global.

Según tu situación, puedes añadir una aportación, un retiro o una transferencia interna.

Si el efectivo parece incoherente, revisa primero tus operaciones de aportación, retiro y comisiones.

---

# Comprender las pantallas principales

TradeVision está organizado en varias pantallas.

## Inicio

La pantalla de inicio ofrece una visión resumida de la cartera:

- valor total,
- plusvalía o minusvalía,
- evolución del día,
- información importante,
- resumen de posiciones.

## Operaciones

La pantalla Operaciones permite consultar, añadir o corregir tus movimientos:

- compras,
- ventas,
- comisiones,
- impuestos,
- dividendos,
- aportaciones,
- retiros,
- transferencias internas.

## Cartera

La pantalla Cartera muestra los valores mantenidos y su valoración.

Permite comprobar rápidamente:

- la cantidad mantenida,
- el precio medio de coste,
- la cotización actual,
- el valor de cada línea,
- el peso de cada valor.

## Rendimiento

La pantalla Rendimiento ayuda a seguir la evolución de la cartera en el tiempo.

Puede incluir:

- el valor de la cartera,
- las aportaciones,
- el efectivo,
- las ganancias o pérdidas,
- los indicadores de rentabilidad.

## Notas

La pantalla Notas permite conservar notas personales relacionadas con tu seguimiento.

Según tu versión, también puede incluir funciones de tipo hoja de cálculo para seguir datos personalizados.

## Ajustes

Los ajustes agrupan, entre otras cosas:

- las fuentes de cotizaciones,
- las posibles claves API,
- la licencia,
- el mantenimiento,
- las opciones de visualización,
- las herramientas de copia de seguridad.

---

# Comprobar las cotizaciones

Después de añadir tus valores, comprueba que las cotizaciones se carguen correctamente.

Puede faltar una cotización si:

- el ticker es ambiguo,
- el valor aún no ha sido reconocido,
- no se ha indicado la plaza de cotización,
- la fuente de precios no cubre ese valor,
- el mercado está cerrado o el dato aún no está disponible.

En ese caso, consulta las secciones:

- [Cotizaciones y mercado](pricing.md)
- [Providers y APIs](providers.md)
- [Importación / Exportación](csv.md)

---

# Guardar tu cartera

La copia de seguridad es un paso esencial.

TradeVision puede trabajar con archivos locales. Por eso se recomienda crear copias de seguridad con regularidad.

Antes de una operación importante, como una gran importación CSV o una tarea de mantenimiento, haz un backup.

Un backup permite volver atrás si se detecta un error después.

> Consejo: haz siempre una copia de seguridad antes de importar un archivo grande o restaurar una base antigua.

---

# Buenas prácticas para empezar bien

Para evitar errores al inicio:

- empieza con algunas operaciones simples,
- comprueba los símbolos y las plazas de cotización,
- añade el efectivo inicial si es necesario,
- controla las cotizaciones recuperadas,
- haz una copia de seguridad antes de grandes importaciones,
- importa tus datos de forma progresiva.

Es mejor validar una base pequeña y limpia que corregir una gran importación incompleta.

---

# Importante saber

TradeVision es una herramienta de ayuda al seguimiento y al análisis.

La aplicación:

- no garantiza rendimientos futuros,
- no sustituye a un asesor financiero,
- no envía órdenes automáticamente,
- depende de la calidad de los datos que introduces,
- puede mostrar cotizaciones distintas de las de tu bróker según las fuentes utilizadas.

Las herramientas IA deben considerarse ayudas para reflexionar, nunca instrucciones de compra o venta.
