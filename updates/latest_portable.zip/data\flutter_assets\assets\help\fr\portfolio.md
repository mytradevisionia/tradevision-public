# Portefeuille et opérations

Cette section explique comment TradeVision gère les opérations, les comptes et le suivi du portefeuille.

Les opérations constituent la base du fonctionnement de l’application.  
Elles permettent de recalculer automatiquement :

- les positions détenues,
- le cash disponible,
- les performances,
- les plus-values et moins-values,
- le prix de revient,
- les graphiques et statistiques.

---

# Comprendre le portefeuille

Un portefeuille regroupe :

- vos titres détenus,
- vos comptes,
- votre cash,
- vos opérations,
- vos historiques de prix.

TradeVision peut gérer plusieurs types de comptes, notamment :

- PEA,
- CTO,
- autres comptes personnalisés selon votre configuration.

Chaque opération est enregistrée dans votre portefeuille local.

---

# Les principaux types d’opérations

TradeVision permet d’enregistrer plusieurs types d’opérations.

## Achat

Une opération d’achat augmente :

- la quantité détenue,
- la valeur investie,
- éventuellement les frais associés.

Les achats sont utilisés pour recalculer :

- le prix de revient unitaire,
- les positions ouvertes,
- les performances.

---

## Vente

Une vente réduit ou ferme une position.

TradeVision peut recalculer automatiquement :

- la plus-value ou moins-value réalisée,
- les quantités restantes,
- les statistiques de performance.

Selon votre configuration, certaines méthodes de calcul peuvent être utilisées pour les ventes.

---

## Dividende

Les dividendes permettent d’ajouter un revenu lié à un titre.

Selon votre saisie, ils peuvent :

- augmenter le cash,
- être associés à un compte spécifique,
- être intégrés dans les performances globales.

---

## Frais et taxes

Les frais permettent de suivre :

- les frais de courtage,
- certaines taxes,
- les coûts liés aux opérations.

Ils peuvent avoir un impact direct sur :

- les performances,
- le cash disponible,
- les calculs de rentabilité.

> Conseil : renseigner correctement les frais améliore la précision des résultats.

---

## Apport

Un apport ajoute du cash dans le portefeuille.

Exemples :

- versement sur PEA,
- dépôt sur CTO,
- ajout manuel de liquidités.

Les apports sont importants pour suivre correctement :

- les performances,
- les rendements,
- les graphiques de valeur.

---

## Retrait

Un retrait réduit le cash disponible du portefeuille.

Exemples :

- retrait bancaire,
- transfert de liquidités,
- sortie d’argent du portefeuille.

---

## Virement interne

Les virements internes permettent de déplacer du cash entre comptes.

Exemple :

- transfert entre CTO et PEA,
- déplacement entre sous-portefeuilles.

Ces opérations évitent de fausser les performances globales.

---

# Comprendre le cash

Le cash représente l’argent disponible non investi.

Le cash peut évoluer à cause :

- des achats,
- des ventes,
- des dividendes,
- des frais,
- des apports,
- des retraits,
- des virements internes.

Un cash négatif peut indiquer :

- un apport oublié,
- des frais non pris en compte,
- une erreur dans une opération,
- un import incomplet.

---

# PEA et CTO

TradeVision peut gérer différents types de comptes.

## PEA

Le PEA est souvent utilisé pour :

- les actions européennes,
- certains ETF éligibles,
- un suivi fiscal spécifique.

Selon les données disponibles, certains écrans peuvent afficher l’éligibilité PEA des titres.

---

## CTO

Le CTO est plus flexible et peut contenir :

- des actions internationales,
- des ETF non éligibles PEA,
- des produits disponibles sur plusieurs marchés.

TradeVision permet de suivre séparément plusieurs comptes si nécessaire.

---

# Prix de revient et performances

TradeVision recalcule automatiquement plusieurs indicateurs à partir des opérations.

Exemples :

- prix de revient unitaire,
- plus-value ou moins-value,
- valeur investie,
- rendement global,
- performances annuelles.

Ces calculs dépendent directement de la qualité des opérations enregistrées.

> Important : si les résultats semblent incohérents, vérifiez d’abord vos opérations et votre cash.

---

# Titres et symboles

Chaque titre peut être identifié par plusieurs informations :

- ticker,
- ISIN,
- place de cotation,
- devise.

Certains symboles peuvent être ambigus lorsqu’ils existent sur plusieurs marchés.

Exemple :

- un même ticker peut exister à Paris, Amsterdam ou Francfort.

Dans ce cas, il peut être nécessaire de préciser :

- la place,
- le code MIC,
- le suffixe du ticker.

Pour plus d’informations, consultez :

- [Cours et marché](pricing.md)
- [Import / Export](csv.md)

---

# Modifier ou corriger une opération

Les opérations peuvent être corrigées directement depuis l’écran Opérations.

Après une modification importante :

- les positions,
- les performances,
- le cash,
- les graphiques

peuvent être recalculés automatiquement.

Si certaines données semblent incorrectes après un import massif, il peut être utile d’utiliser les outils de maintenance.

---

# Conseils pour éviter les erreurs

Pour garder un portefeuille cohérent :

- vérifiez les symboles avant validation,
- renseignez correctement les frais,
- ajoutez les apports de cash réels,
- évitez les doublons d’import,
- faites des sauvegardes régulières,
- importez progressivement les gros historiques.

Une petite erreur dans les opérations peut avoir un impact important sur les performances calculées.

---

# Important à savoir

TradeVision dépend principalement des opérations enregistrées dans votre portefeuille.

Si les données importées sont incomplètes ou incorrectes :

- le cash peut devenir incohérent,
- certaines performances peuvent être faussées,
- les positions peuvent sembler incorrectes.

Avant d’effectuer des modifications importantes :

- faites une sauvegarde,
- vérifiez les imports,
- contrôlez les symboles et les comptes utilisés.
