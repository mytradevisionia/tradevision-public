# TradeVision AI Pro — Help

Welcome to the TradeVision AI Pro help.

TradeVision is a local portfolio tracking and market analysis application designed for ETFs, stocks, PEA accounts and securities accounts.

The application helps you:

- track your investments,
- analyze your portfolio performance,
- manage your transactions,
- import market data,
- use AI-based analysis tools,
- back up and restore your portfolios locally.

All data remains stored on your own computer.  
TradeVision does not automatically send your portfolio to an external server.

---

# Getting started

Learn the basics of the application:

- create a portfolio,
- add a first transaction,
- add cash,
- understand the main screens,
- make a first backup.

[Open the Getting started section](getting_started.md)

---

# Portfolio and transactions

This section explains:

- buys and sells,
- PEA and securities accounts,
- dividends,
- fees and taxes,
- internal transfers,
- cash management.

[Open the Portfolio and transactions section](portfolio.md)

---

# Prices and markets

TradeVision can use several data sources to retrieve market prices.

This section explains:

- the different price sources,
- open and closed markets,
- spot prices,
- official closes,
- OHLC data,
- automatic price updates.

[Open the Prices and markets section](pricing.md)

---

# Providers and APIs

TradeVision can work with free providers or optional external APIs.

This section covers:

- Google Finance,
- Yahoo Finance,
- Pro APIs,
- API key configuration,
- ABCBourse,
- the limits of free providers.

[Open the Providers and APIs section](providers.md)

---

# Import / Export

TradeVision can import and export several types of data.

This section explains:

- CSV import,
- ambiguous tickers,
- MIC and ISIN codes,
- PDF exports,
- backups,
- portfolio restoration.

[Open the Import / Export section](csv.md)

---

# TradeVision AI

TradeVision AI Pro includes several analysis support tools.

This section presents:

- AI suggestions,
- AI scores,
- diversification suggestions,
- news scoring,
- the limits of AI tools.

[Open the TradeVision AI section](ai.md)

---

# Maintenance

Maintenance tools are available to optimize or repair certain data.

This section explains:

- SQLite maintenance,
- security reconstruction,
- OpenFIGI checks,
- database repair tools.

[Open the Maintenance section](maintenance.md)

---

# License and Pro edition

TradeVision is available in Demo mode and in a Pro edition.

This section explains:

- the differences between editions,
- license activation,
- license expiry,
- use on several machines.

[Open the License and Pro edition section](license.md)

---

# FAQ

Find answers to common questions and frequent issues.

[Open the FAQ](faq.md)
